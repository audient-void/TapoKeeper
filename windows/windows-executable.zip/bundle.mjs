#!/usr/bin/env node
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require2() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/axios/lib/helpers/bind.js
var require_bind = __commonJS({
  "node_modules/axios/lib/helpers/bind.js"(exports, module) {
    "use strict";
    module.exports = function bind(fn, thisArg) {
      return function wrap() {
        var args = new Array(arguments.length);
        for (var i = 0; i < args.length; i++) {
          args[i] = arguments[i];
        }
        return fn.apply(thisArg, args);
      };
    };
  }
});

// node_modules/axios/lib/utils.js
var require_utils = __commonJS({
  "node_modules/axios/lib/utils.js"(exports, module) {
    "use strict";
    var bind = require_bind();
    var toString = Object.prototype.toString;
    function isArray(val) {
      return toString.call(val) === "[object Array]";
    }
    function isUndefined(val) {
      return typeof val === "undefined";
    }
    function isBuffer(val) {
      return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor) && typeof val.constructor.isBuffer === "function" && val.constructor.isBuffer(val);
    }
    function isArrayBuffer(val) {
      return toString.call(val) === "[object ArrayBuffer]";
    }
    function isFormData(val) {
      return typeof FormData !== "undefined" && val instanceof FormData;
    }
    function isArrayBufferView(val) {
      var result;
      if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) {
        result = ArrayBuffer.isView(val);
      } else {
        result = val && val.buffer && val.buffer instanceof ArrayBuffer;
      }
      return result;
    }
    function isString(val) {
      return typeof val === "string";
    }
    function isNumber(val) {
      return typeof val === "number";
    }
    function isObject(val) {
      return val !== null && typeof val === "object";
    }
    function isPlainObject(val) {
      if (toString.call(val) !== "[object Object]") {
        return false;
      }
      var prototype = Object.getPrototypeOf(val);
      return prototype === null || prototype === Object.prototype;
    }
    function isDate(val) {
      return toString.call(val) === "[object Date]";
    }
    function isFile(val) {
      return toString.call(val) === "[object File]";
    }
    function isBlob(val) {
      return toString.call(val) === "[object Blob]";
    }
    function isFunction(val) {
      return toString.call(val) === "[object Function]";
    }
    function isStream(val) {
      return isObject(val) && isFunction(val.pipe);
    }
    function isURLSearchParams(val) {
      return typeof URLSearchParams !== "undefined" && val instanceof URLSearchParams;
    }
    function trim(str) {
      return str.trim ? str.trim() : str.replace(/^\s+|\s+$/g, "");
    }
    function isStandardBrowserEnv() {
      if (typeof navigator !== "undefined" && (navigator.product === "ReactNative" || navigator.product === "NativeScript" || navigator.product === "NS")) {
        return false;
      }
      return typeof window !== "undefined" && typeof document !== "undefined";
    }
    function forEach(obj, fn) {
      if (obj === null || typeof obj === "undefined") {
        return;
      }
      if (typeof obj !== "object") {
        obj = [obj];
      }
      if (isArray(obj)) {
        for (var i = 0, l = obj.length; i < l; i++) {
          fn.call(null, obj[i], i, obj);
        }
      } else {
        for (var key in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key)) {
            fn.call(null, obj[key], key, obj);
          }
        }
      }
    }
    function merge() {
      var result = {};
      function assignValue(val, key) {
        if (isPlainObject(result[key]) && isPlainObject(val)) {
          result[key] = merge(result[key], val);
        } else if (isPlainObject(val)) {
          result[key] = merge({}, val);
        } else if (isArray(val)) {
          result[key] = val.slice();
        } else {
          result[key] = val;
        }
      }
      for (var i = 0, l = arguments.length; i < l; i++) {
        forEach(arguments[i], assignValue);
      }
      return result;
    }
    function extend(a, b, thisArg) {
      forEach(b, function assignValue(val, key) {
        if (thisArg && typeof val === "function") {
          a[key] = bind(val, thisArg);
        } else {
          a[key] = val;
        }
      });
      return a;
    }
    function stripBOM(content) {
      if (content.charCodeAt(0) === 65279) {
        content = content.slice(1);
      }
      return content;
    }
    module.exports = {
      isArray,
      isArrayBuffer,
      isBuffer,
      isFormData,
      isArrayBufferView,
      isString,
      isNumber,
      isObject,
      isPlainObject,
      isUndefined,
      isDate,
      isFile,
      isBlob,
      isFunction,
      isStream,
      isURLSearchParams,
      isStandardBrowserEnv,
      forEach,
      merge,
      extend,
      trim,
      stripBOM
    };
  }
});

// node_modules/axios/lib/helpers/buildURL.js
var require_buildURL = __commonJS({
  "node_modules/axios/lib/helpers/buildURL.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    function encode(val) {
      return encodeURIComponent(val).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
    }
    module.exports = function buildURL(url, params, paramsSerializer) {
      if (!params) {
        return url;
      }
      var serializedParams;
      if (paramsSerializer) {
        serializedParams = paramsSerializer(params);
      } else if (utils.isURLSearchParams(params)) {
        serializedParams = params.toString();
      } else {
        var parts = [];
        utils.forEach(params, function serialize(val, key) {
          if (val === null || typeof val === "undefined") {
            return;
          }
          if (utils.isArray(val)) {
            key = key + "[]";
          } else {
            val = [val];
          }
          utils.forEach(val, function parseValue(v) {
            if (utils.isDate(v)) {
              v = v.toISOString();
            } else if (utils.isObject(v)) {
              v = JSON.stringify(v);
            }
            parts.push(encode(key) + "=" + encode(v));
          });
        });
        serializedParams = parts.join("&");
      }
      if (serializedParams) {
        var hashmarkIndex = url.indexOf("#");
        if (hashmarkIndex !== -1) {
          url = url.slice(0, hashmarkIndex);
        }
        url += (url.indexOf("?") === -1 ? "?" : "&") + serializedParams;
      }
      return url;
    };
  }
});

// node_modules/axios/lib/core/InterceptorManager.js
var require_InterceptorManager = __commonJS({
  "node_modules/axios/lib/core/InterceptorManager.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    function InterceptorManager() {
      this.handlers = [];
    }
    InterceptorManager.prototype.use = function use(fulfilled, rejected, options) {
      this.handlers.push({
        fulfilled,
        rejected,
        synchronous: options ? options.synchronous : false,
        runWhen: options ? options.runWhen : null
      });
      return this.handlers.length - 1;
    };
    InterceptorManager.prototype.eject = function eject(id) {
      if (this.handlers[id]) {
        this.handlers[id] = null;
      }
    };
    InterceptorManager.prototype.forEach = function forEach(fn) {
      utils.forEach(this.handlers, function forEachHandler(h) {
        if (h !== null) {
          fn(h);
        }
      });
    };
    module.exports = InterceptorManager;
  }
});

// node_modules/axios/lib/helpers/normalizeHeaderName.js
var require_normalizeHeaderName = __commonJS({
  "node_modules/axios/lib/helpers/normalizeHeaderName.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    module.exports = function normalizeHeaderName(headers, normalizedName) {
      utils.forEach(headers, function processHeader(value, name) {
        if (name !== normalizedName && name.toUpperCase() === normalizedName.toUpperCase()) {
          headers[normalizedName] = value;
          delete headers[name];
        }
      });
    };
  }
});

// node_modules/axios/lib/core/enhanceError.js
var require_enhanceError = __commonJS({
  "node_modules/axios/lib/core/enhanceError.js"(exports, module) {
    "use strict";
    module.exports = function enhanceError(error, config2, code, request, response) {
      error.config = config2;
      if (code) {
        error.code = code;
      }
      error.request = request;
      error.response = response;
      error.isAxiosError = true;
      error.toJSON = function toJSON() {
        return {
          // Standard
          message: this.message,
          name: this.name,
          // Microsoft
          description: this.description,
          number: this.number,
          // Mozilla
          fileName: this.fileName,
          lineNumber: this.lineNumber,
          columnNumber: this.columnNumber,
          stack: this.stack,
          // Axios
          config: this.config,
          code: this.code
        };
      };
      return error;
    };
  }
});

// node_modules/axios/lib/core/createError.js
var require_createError = __commonJS({
  "node_modules/axios/lib/core/createError.js"(exports, module) {
    "use strict";
    var enhanceError = require_enhanceError();
    module.exports = function createError(message, config2, code, request, response) {
      var error = new Error(message);
      return enhanceError(error, config2, code, request, response);
    };
  }
});

// node_modules/axios/lib/core/settle.js
var require_settle = __commonJS({
  "node_modules/axios/lib/core/settle.js"(exports, module) {
    "use strict";
    var createError = require_createError();
    module.exports = function settle(resolve, reject, response) {
      var validateStatus = response.config.validateStatus;
      if (!response.status || !validateStatus || validateStatus(response.status)) {
        resolve(response);
      } else {
        reject(createError(
          "Request failed with status code " + response.status,
          response.config,
          null,
          response.request,
          response
        ));
      }
    };
  }
});

// node_modules/axios/lib/helpers/cookies.js
var require_cookies = __commonJS({
  "node_modules/axios/lib/helpers/cookies.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    module.exports = utils.isStandardBrowserEnv() ? (
      // Standard browser envs support document.cookie
      /* @__PURE__ */ (function standardBrowserEnv() {
        return {
          write: function write(name, value, expires, path, domain, secure) {
            var cookie = [];
            cookie.push(name + "=" + encodeURIComponent(value));
            if (utils.isNumber(expires)) {
              cookie.push("expires=" + new Date(expires).toGMTString());
            }
            if (utils.isString(path)) {
              cookie.push("path=" + path);
            }
            if (utils.isString(domain)) {
              cookie.push("domain=" + domain);
            }
            if (secure === true) {
              cookie.push("secure");
            }
            document.cookie = cookie.join("; ");
          },
          read: function read(name) {
            var match = document.cookie.match(new RegExp("(^|;\\s*)(" + name + ")=([^;]*)"));
            return match ? decodeURIComponent(match[3]) : null;
          },
          remove: function remove(name) {
            this.write(name, "", Date.now() - 864e5);
          }
        };
      })()
    ) : (
      // Non standard browser env (web workers, react-native) lack needed support.
      /* @__PURE__ */ (function nonStandardBrowserEnv() {
        return {
          write: function write() {
          },
          read: function read() {
            return null;
          },
          remove: function remove() {
          }
        };
      })()
    );
  }
});

// node_modules/axios/lib/helpers/isAbsoluteURL.js
var require_isAbsoluteURL = __commonJS({
  "node_modules/axios/lib/helpers/isAbsoluteURL.js"(exports, module) {
    "use strict";
    module.exports = function isAbsoluteURL(url) {
      return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(url);
    };
  }
});

// node_modules/axios/lib/helpers/combineURLs.js
var require_combineURLs = __commonJS({
  "node_modules/axios/lib/helpers/combineURLs.js"(exports, module) {
    "use strict";
    module.exports = function combineURLs(baseURL, relativeURL) {
      return relativeURL ? baseURL.replace(/\/+$/, "") + "/" + relativeURL.replace(/^\/+/, "") : baseURL;
    };
  }
});

// node_modules/axios/lib/core/buildFullPath.js
var require_buildFullPath = __commonJS({
  "node_modules/axios/lib/core/buildFullPath.js"(exports, module) {
    "use strict";
    var isAbsoluteURL = require_isAbsoluteURL();
    var combineURLs = require_combineURLs();
    module.exports = function buildFullPath(baseURL, requestedURL) {
      if (baseURL && !isAbsoluteURL(requestedURL)) {
        return combineURLs(baseURL, requestedURL);
      }
      return requestedURL;
    };
  }
});

// node_modules/axios/lib/helpers/parseHeaders.js
var require_parseHeaders = __commonJS({
  "node_modules/axios/lib/helpers/parseHeaders.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    var ignoreDuplicateOf = [
      "age",
      "authorization",
      "content-length",
      "content-type",
      "etag",
      "expires",
      "from",
      "host",
      "if-modified-since",
      "if-unmodified-since",
      "last-modified",
      "location",
      "max-forwards",
      "proxy-authorization",
      "referer",
      "retry-after",
      "user-agent"
    ];
    module.exports = function parseHeaders(headers) {
      var parsed = {};
      var key;
      var val;
      var i;
      if (!headers) {
        return parsed;
      }
      utils.forEach(headers.split("\n"), function parser(line) {
        i = line.indexOf(":");
        key = utils.trim(line.substr(0, i)).toLowerCase();
        val = utils.trim(line.substr(i + 1));
        if (key) {
          if (parsed[key] && ignoreDuplicateOf.indexOf(key) >= 0) {
            return;
          }
          if (key === "set-cookie") {
            parsed[key] = (parsed[key] ? parsed[key] : []).concat([val]);
          } else {
            parsed[key] = parsed[key] ? parsed[key] + ", " + val : val;
          }
        }
      });
      return parsed;
    };
  }
});

// node_modules/axios/lib/helpers/isURLSameOrigin.js
var require_isURLSameOrigin = __commonJS({
  "node_modules/axios/lib/helpers/isURLSameOrigin.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    module.exports = utils.isStandardBrowserEnv() ? (
      // Standard browser envs have full support of the APIs needed to test
      // whether the request URL is of the same origin as current location.
      (function standardBrowserEnv() {
        var msie = /(msie|trident)/i.test(navigator.userAgent);
        var urlParsingNode = document.createElement("a");
        var originURL;
        function resolveURL(url) {
          var href = url;
          if (msie) {
            urlParsingNode.setAttribute("href", href);
            href = urlParsingNode.href;
          }
          urlParsingNode.setAttribute("href", href);
          return {
            href: urlParsingNode.href,
            protocol: urlParsingNode.protocol ? urlParsingNode.protocol.replace(/:$/, "") : "",
            host: urlParsingNode.host,
            search: urlParsingNode.search ? urlParsingNode.search.replace(/^\?/, "") : "",
            hash: urlParsingNode.hash ? urlParsingNode.hash.replace(/^#/, "") : "",
            hostname: urlParsingNode.hostname,
            port: urlParsingNode.port,
            pathname: urlParsingNode.pathname.charAt(0) === "/" ? urlParsingNode.pathname : "/" + urlParsingNode.pathname
          };
        }
        originURL = resolveURL(window.location.href);
        return function isURLSameOrigin(requestURL) {
          var parsed = utils.isString(requestURL) ? resolveURL(requestURL) : requestURL;
          return parsed.protocol === originURL.protocol && parsed.host === originURL.host;
        };
      })()
    ) : (
      // Non standard browser envs (web workers, react-native) lack needed support.
      /* @__PURE__ */ (function nonStandardBrowserEnv() {
        return function isURLSameOrigin() {
          return true;
        };
      })()
    );
  }
});

// node_modules/axios/lib/adapters/xhr.js
var require_xhr = __commonJS({
  "node_modules/axios/lib/adapters/xhr.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    var settle = require_settle();
    var cookies = require_cookies();
    var buildURL = require_buildURL();
    var buildFullPath = require_buildFullPath();
    var parseHeaders = require_parseHeaders();
    var isURLSameOrigin = require_isURLSameOrigin();
    var createError = require_createError();
    module.exports = function xhrAdapter(config2) {
      return new Promise(function dispatchXhrRequest(resolve, reject) {
        var requestData = config2.data;
        var requestHeaders = config2.headers;
        var responseType = config2.responseType;
        if (utils.isFormData(requestData)) {
          delete requestHeaders["Content-Type"];
        }
        var request = new XMLHttpRequest();
        if (config2.auth) {
          var username = config2.auth.username || "";
          var password = config2.auth.password ? unescape(encodeURIComponent(config2.auth.password)) : "";
          requestHeaders.Authorization = "Basic " + btoa(username + ":" + password);
        }
        var fullPath = buildFullPath(config2.baseURL, config2.url);
        request.open(config2.method.toUpperCase(), buildURL(fullPath, config2.params, config2.paramsSerializer), true);
        request.timeout = config2.timeout;
        function onloadend() {
          if (!request) {
            return;
          }
          var responseHeaders = "getAllResponseHeaders" in request ? parseHeaders(request.getAllResponseHeaders()) : null;
          var responseData = !responseType || responseType === "text" || responseType === "json" ? request.responseText : request.response;
          var response = {
            data: responseData,
            status: request.status,
            statusText: request.statusText,
            headers: responseHeaders,
            config: config2,
            request
          };
          settle(resolve, reject, response);
          request = null;
        }
        if ("onloadend" in request) {
          request.onloadend = onloadend;
        } else {
          request.onreadystatechange = function handleLoad() {
            if (!request || request.readyState !== 4) {
              return;
            }
            if (request.status === 0 && !(request.responseURL && request.responseURL.indexOf("file:") === 0)) {
              return;
            }
            setTimeout(onloadend);
          };
        }
        request.onabort = function handleAbort() {
          if (!request) {
            return;
          }
          reject(createError("Request aborted", config2, "ECONNABORTED", request));
          request = null;
        };
        request.onerror = function handleError() {
          reject(createError("Network Error", config2, null, request));
          request = null;
        };
        request.ontimeout = function handleTimeout() {
          var timeoutErrorMessage = "timeout of " + config2.timeout + "ms exceeded";
          if (config2.timeoutErrorMessage) {
            timeoutErrorMessage = config2.timeoutErrorMessage;
          }
          reject(createError(
            timeoutErrorMessage,
            config2,
            config2.transitional && config2.transitional.clarifyTimeoutError ? "ETIMEDOUT" : "ECONNABORTED",
            request
          ));
          request = null;
        };
        if (utils.isStandardBrowserEnv()) {
          var xsrfValue = (config2.withCredentials || isURLSameOrigin(fullPath)) && config2.xsrfCookieName ? cookies.read(config2.xsrfCookieName) : void 0;
          if (xsrfValue) {
            requestHeaders[config2.xsrfHeaderName] = xsrfValue;
          }
        }
        if ("setRequestHeader" in request) {
          utils.forEach(requestHeaders, function setRequestHeader(val, key) {
            if (typeof requestData === "undefined" && key.toLowerCase() === "content-type") {
              delete requestHeaders[key];
            } else {
              request.setRequestHeader(key, val);
            }
          });
        }
        if (!utils.isUndefined(config2.withCredentials)) {
          request.withCredentials = !!config2.withCredentials;
        }
        if (responseType && responseType !== "json") {
          request.responseType = config2.responseType;
        }
        if (typeof config2.onDownloadProgress === "function") {
          request.addEventListener("progress", config2.onDownloadProgress);
        }
        if (typeof config2.onUploadProgress === "function" && request.upload) {
          request.upload.addEventListener("progress", config2.onUploadProgress);
        }
        if (config2.cancelToken) {
          config2.cancelToken.promise.then(function onCanceled(cancel) {
            if (!request) {
              return;
            }
            request.abort();
            reject(cancel);
            request = null;
          });
        }
        if (!requestData) {
          requestData = null;
        }
        request.send(requestData);
      });
    };
  }
});

// node_modules/ms/index.js
var require_ms = __commonJS({
  "node_modules/ms/index.js"(exports, module) {
    var s = 1e3;
    var m = s * 60;
    var h = m * 60;
    var d = h * 24;
    var w = d * 7;
    var y = d * 365.25;
    module.exports = function(val, options) {
      options = options || {};
      var type = typeof val;
      if (type === "string" && val.length > 0) {
        return parse2(val);
      } else if (type === "number" && isFinite(val)) {
        return options.long ? fmtLong(val) : fmtShort(val);
      }
      throw new Error(
        "val is not a non-empty string or a valid number. val=" + JSON.stringify(val)
      );
    };
    function parse2(str) {
      str = String(str);
      if (str.length > 100) {
        return;
      }
      var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(
        str
      );
      if (!match) {
        return;
      }
      var n = parseFloat(match[1]);
      var type = (match[2] || "ms").toLowerCase();
      switch (type) {
        case "years":
        case "year":
        case "yrs":
        case "yr":
        case "y":
          return n * y;
        case "weeks":
        case "week":
        case "w":
          return n * w;
        case "days":
        case "day":
        case "d":
          return n * d;
        case "hours":
        case "hour":
        case "hrs":
        case "hr":
        case "h":
          return n * h;
        case "minutes":
        case "minute":
        case "mins":
        case "min":
        case "m":
          return n * m;
        case "seconds":
        case "second":
        case "secs":
        case "sec":
        case "s":
          return n * s;
        case "milliseconds":
        case "millisecond":
        case "msecs":
        case "msec":
        case "ms":
          return n;
        default:
          return void 0;
      }
    }
    function fmtShort(ms) {
      var msAbs = Math.abs(ms);
      if (msAbs >= d) {
        return Math.round(ms / d) + "d";
      }
      if (msAbs >= h) {
        return Math.round(ms / h) + "h";
      }
      if (msAbs >= m) {
        return Math.round(ms / m) + "m";
      }
      if (msAbs >= s) {
        return Math.round(ms / s) + "s";
      }
      return ms + "ms";
    }
    function fmtLong(ms) {
      var msAbs = Math.abs(ms);
      if (msAbs >= d) {
        return plural(ms, msAbs, d, "day");
      }
      if (msAbs >= h) {
        return plural(ms, msAbs, h, "hour");
      }
      if (msAbs >= m) {
        return plural(ms, msAbs, m, "minute");
      }
      if (msAbs >= s) {
        return plural(ms, msAbs, s, "second");
      }
      return ms + " ms";
    }
    function plural(ms, msAbs, n, name) {
      var isPlural = msAbs >= n * 1.5;
      return Math.round(ms / n) + " " + name + (isPlural ? "s" : "");
    }
  }
});

// node_modules/debug/src/common.js
var require_common = __commonJS({
  "node_modules/debug/src/common.js"(exports, module) {
    function setup(env) {
      createDebug.debug = createDebug;
      createDebug.default = createDebug;
      createDebug.coerce = coerce;
      createDebug.disable = disable;
      createDebug.enable = enable;
      createDebug.enabled = enabled;
      createDebug.humanize = require_ms();
      createDebug.destroy = destroy;
      Object.keys(env).forEach((key) => {
        createDebug[key] = env[key];
      });
      createDebug.names = [];
      createDebug.skips = [];
      createDebug.formatters = {};
      function selectColor(namespace) {
        let hash = 0;
        for (let i = 0; i < namespace.length; i++) {
          hash = (hash << 5) - hash + namespace.charCodeAt(i);
          hash |= 0;
        }
        return createDebug.colors[Math.abs(hash) % createDebug.colors.length];
      }
      createDebug.selectColor = selectColor;
      function createDebug(namespace) {
        let prevTime;
        let enableOverride = null;
        let namespacesCache;
        let enabledCache;
        function debug(...args) {
          if (!debug.enabled) {
            return;
          }
          const self2 = debug;
          const curr = Number(/* @__PURE__ */ new Date());
          const ms = curr - (prevTime || curr);
          self2.diff = ms;
          self2.prev = prevTime;
          self2.curr = curr;
          prevTime = curr;
          args[0] = createDebug.coerce(args[0]);
          if (typeof args[0] !== "string") {
            args.unshift("%O");
          }
          let index = 0;
          args[0] = args[0].replace(/%([a-zA-Z%])/g, (match, format) => {
            if (match === "%%") {
              return "%";
            }
            index++;
            const formatter = createDebug.formatters[format];
            if (typeof formatter === "function") {
              const val = args[index];
              match = formatter.call(self2, val);
              args.splice(index, 1);
              index--;
            }
            return match;
          });
          createDebug.formatArgs.call(self2, args);
          const logFn = self2.log || createDebug.log;
          logFn.apply(self2, args);
        }
        debug.namespace = namespace;
        debug.useColors = createDebug.useColors();
        debug.color = createDebug.selectColor(namespace);
        debug.extend = extend;
        debug.destroy = createDebug.destroy;
        Object.defineProperty(debug, "enabled", {
          enumerable: true,
          configurable: false,
          get: () => {
            if (enableOverride !== null) {
              return enableOverride;
            }
            if (namespacesCache !== createDebug.namespaces) {
              namespacesCache = createDebug.namespaces;
              enabledCache = createDebug.enabled(namespace);
            }
            return enabledCache;
          },
          set: (v) => {
            enableOverride = v;
          }
        });
        if (typeof createDebug.init === "function") {
          createDebug.init(debug);
        }
        return debug;
      }
      function extend(namespace, delimiter) {
        const newDebug = createDebug(this.namespace + (typeof delimiter === "undefined" ? ":" : delimiter) + namespace);
        newDebug.log = this.log;
        return newDebug;
      }
      function enable(namespaces) {
        createDebug.save(namespaces);
        createDebug.namespaces = namespaces;
        createDebug.names = [];
        createDebug.skips = [];
        const split = (typeof namespaces === "string" ? namespaces : "").trim().replace(/\s+/g, ",").split(",").filter(Boolean);
        for (const ns of split) {
          if (ns[0] === "-") {
            createDebug.skips.push(ns.slice(1));
          } else {
            createDebug.names.push(ns);
          }
        }
      }
      function matchesTemplate(search, template) {
        let searchIndex = 0;
        let templateIndex = 0;
        let starIndex = -1;
        let matchIndex = 0;
        while (searchIndex < search.length) {
          if (templateIndex < template.length && (template[templateIndex] === search[searchIndex] || template[templateIndex] === "*")) {
            if (template[templateIndex] === "*") {
              starIndex = templateIndex;
              matchIndex = searchIndex;
              templateIndex++;
            } else {
              searchIndex++;
              templateIndex++;
            }
          } else if (starIndex !== -1) {
            templateIndex = starIndex + 1;
            matchIndex++;
            searchIndex = matchIndex;
          } else {
            return false;
          }
        }
        while (templateIndex < template.length && template[templateIndex] === "*") {
          templateIndex++;
        }
        return templateIndex === template.length;
      }
      function disable() {
        const namespaces = [
          ...createDebug.names,
          ...createDebug.skips.map((namespace) => "-" + namespace)
        ].join(",");
        createDebug.enable("");
        return namespaces;
      }
      function enabled(name) {
        for (const skip of createDebug.skips) {
          if (matchesTemplate(name, skip)) {
            return false;
          }
        }
        for (const ns of createDebug.names) {
          if (matchesTemplate(name, ns)) {
            return true;
          }
        }
        return false;
      }
      function coerce(val) {
        if (val instanceof Error) {
          return val.stack || val.message;
        }
        return val;
      }
      function destroy() {
        console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
      }
      createDebug.enable(createDebug.load());
      return createDebug;
    }
    module.exports = setup;
  }
});

// node_modules/debug/src/browser.js
var require_browser = __commonJS({
  "node_modules/debug/src/browser.js"(exports, module) {
    exports.formatArgs = formatArgs;
    exports.save = save;
    exports.load = load;
    exports.useColors = useColors;
    exports.storage = localstorage();
    exports.destroy = /* @__PURE__ */ (() => {
      let warned = false;
      return () => {
        if (!warned) {
          warned = true;
          console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
        }
      };
    })();
    exports.colors = [
      "#0000CC",
      "#0000FF",
      "#0033CC",
      "#0033FF",
      "#0066CC",
      "#0066FF",
      "#0099CC",
      "#0099FF",
      "#00CC00",
      "#00CC33",
      "#00CC66",
      "#00CC99",
      "#00CCCC",
      "#00CCFF",
      "#3300CC",
      "#3300FF",
      "#3333CC",
      "#3333FF",
      "#3366CC",
      "#3366FF",
      "#3399CC",
      "#3399FF",
      "#33CC00",
      "#33CC33",
      "#33CC66",
      "#33CC99",
      "#33CCCC",
      "#33CCFF",
      "#6600CC",
      "#6600FF",
      "#6633CC",
      "#6633FF",
      "#66CC00",
      "#66CC33",
      "#9900CC",
      "#9900FF",
      "#9933CC",
      "#9933FF",
      "#99CC00",
      "#99CC33",
      "#CC0000",
      "#CC0033",
      "#CC0066",
      "#CC0099",
      "#CC00CC",
      "#CC00FF",
      "#CC3300",
      "#CC3333",
      "#CC3366",
      "#CC3399",
      "#CC33CC",
      "#CC33FF",
      "#CC6600",
      "#CC6633",
      "#CC9900",
      "#CC9933",
      "#CCCC00",
      "#CCCC33",
      "#FF0000",
      "#FF0033",
      "#FF0066",
      "#FF0099",
      "#FF00CC",
      "#FF00FF",
      "#FF3300",
      "#FF3333",
      "#FF3366",
      "#FF3399",
      "#FF33CC",
      "#FF33FF",
      "#FF6600",
      "#FF6633",
      "#FF9900",
      "#FF9933",
      "#FFCC00",
      "#FFCC33"
    ];
    function useColors() {
      if (typeof window !== "undefined" && window.process && (window.process.type === "renderer" || window.process.__nwjs)) {
        return true;
      }
      if (typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) {
        return false;
      }
      let m;
      return typeof document !== "undefined" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || // Is firebug? http://stackoverflow.com/a/398120/376773
      typeof window !== "undefined" && window.console && (window.console.firebug || window.console.exception && window.console.table) || // Is firefox >= v31?
      // https://developer.mozilla.org/en-US/docs/Tools/Web_Console#Styling_messages
      typeof navigator !== "undefined" && navigator.userAgent && (m = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(m[1], 10) >= 31 || // Double check webkit in userAgent just in case we are in a worker
      typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
    }
    function formatArgs(args) {
      args[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + args[0] + (this.useColors ? "%c " : " ") + "+" + module.exports.humanize(this.diff);
      if (!this.useColors) {
        return;
      }
      const c = "color: " + this.color;
      args.splice(1, 0, c, "color: inherit");
      let index = 0;
      let lastC = 0;
      args[0].replace(/%[a-zA-Z%]/g, (match) => {
        if (match === "%%") {
          return;
        }
        index++;
        if (match === "%c") {
          lastC = index;
        }
      });
      args.splice(lastC, 0, c);
    }
    exports.log = console.debug || console.log || (() => {
    });
    function save(namespaces) {
      try {
        if (namespaces) {
          exports.storage.setItem("debug", namespaces);
        } else {
          exports.storage.removeItem("debug");
        }
      } catch (error) {
      }
    }
    function load() {
      let r;
      try {
        r = exports.storage.getItem("debug") || exports.storage.getItem("DEBUG");
      } catch (error) {
      }
      if (!r && typeof process !== "undefined" && "env" in process) {
        r = process.env.DEBUG;
      }
      return r;
    }
    function localstorage() {
      try {
        return localStorage;
      } catch (error) {
      }
    }
    module.exports = require_common()(exports);
    var { formatters } = module.exports;
    formatters.j = function(v) {
      try {
        return JSON.stringify(v);
      } catch (error) {
        return "[UnexpectedJSONParseError]: " + error.message;
      }
    };
  }
});

// node_modules/has-flag/index.js
var require_has_flag = __commonJS({
  "node_modules/has-flag/index.js"(exports, module) {
    "use strict";
    module.exports = (flag, argv = process.argv) => {
      const prefix = flag.startsWith("-") ? "" : flag.length === 1 ? "-" : "--";
      const position = argv.indexOf(prefix + flag);
      const terminatorPosition = argv.indexOf("--");
      return position !== -1 && (terminatorPosition === -1 || position < terminatorPosition);
    };
  }
});

// node_modules/supports-color/index.js
var require_supports_color = __commonJS({
  "node_modules/supports-color/index.js"(exports, module) {
    "use strict";
    var os = __require("os");
    var tty = __require("tty");
    var hasFlag = require_has_flag();
    var { env } = process;
    var forceColor;
    if (hasFlag("no-color") || hasFlag("no-colors") || hasFlag("color=false") || hasFlag("color=never")) {
      forceColor = 0;
    } else if (hasFlag("color") || hasFlag("colors") || hasFlag("color=true") || hasFlag("color=always")) {
      forceColor = 1;
    }
    if ("FORCE_COLOR" in env) {
      if (env.FORCE_COLOR === "true") {
        forceColor = 1;
      } else if (env.FORCE_COLOR === "false") {
        forceColor = 0;
      } else {
        forceColor = env.FORCE_COLOR.length === 0 ? 1 : Math.min(parseInt(env.FORCE_COLOR, 10), 3);
      }
    }
    function translateLevel(level) {
      if (level === 0) {
        return false;
      }
      return {
        level,
        hasBasic: true,
        has256: level >= 2,
        has16m: level >= 3
      };
    }
    function supportsColor(haveStream, streamIsTTY) {
      if (forceColor === 0) {
        return 0;
      }
      if (hasFlag("color=16m") || hasFlag("color=full") || hasFlag("color=truecolor")) {
        return 3;
      }
      if (hasFlag("color=256")) {
        return 2;
      }
      if (haveStream && !streamIsTTY && forceColor === void 0) {
        return 0;
      }
      const min = forceColor || 0;
      if (env.TERM === "dumb") {
        return min;
      }
      if (process.platform === "win32") {
        const osRelease = os.release().split(".");
        if (Number(osRelease[0]) >= 10 && Number(osRelease[2]) >= 10586) {
          return Number(osRelease[2]) >= 14931 ? 3 : 2;
        }
        return 1;
      }
      if ("CI" in env) {
        if (["TRAVIS", "CIRCLECI", "APPVEYOR", "GITLAB_CI", "GITHUB_ACTIONS", "BUILDKITE"].some((sign) => sign in env) || env.CI_NAME === "codeship") {
          return 1;
        }
        return min;
      }
      if ("TEAMCITY_VERSION" in env) {
        return /^(9\.(0*[1-9]\d*)\.|\d{2,}\.)/.test(env.TEAMCITY_VERSION) ? 1 : 0;
      }
      if (env.COLORTERM === "truecolor") {
        return 3;
      }
      if ("TERM_PROGRAM" in env) {
        const version2 = parseInt((env.TERM_PROGRAM_VERSION || "").split(".")[0], 10);
        switch (env.TERM_PROGRAM) {
          case "iTerm.app":
            return version2 >= 3 ? 3 : 2;
          case "Apple_Terminal":
            return 2;
        }
      }
      if (/-256(color)?$/i.test(env.TERM)) {
        return 2;
      }
      if (/^screen|^xterm|^vt100|^vt220|^rxvt|color|ansi|cygwin|linux/i.test(env.TERM)) {
        return 1;
      }
      if ("COLORTERM" in env) {
        return 1;
      }
      return min;
    }
    function getSupportLevel(stream) {
      const level = supportsColor(stream, stream && stream.isTTY);
      return translateLevel(level);
    }
    module.exports = {
      supportsColor: getSupportLevel,
      stdout: translateLevel(supportsColor(true, tty.isatty(1))),
      stderr: translateLevel(supportsColor(true, tty.isatty(2)))
    };
  }
});

// node_modules/debug/src/node.js
var require_node = __commonJS({
  "node_modules/debug/src/node.js"(exports, module) {
    var tty = __require("tty");
    var util = __require("util");
    exports.init = init;
    exports.log = log;
    exports.formatArgs = formatArgs;
    exports.save = save;
    exports.load = load;
    exports.useColors = useColors;
    exports.destroy = util.deprecate(
      () => {
      },
      "Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."
    );
    exports.colors = [6, 2, 3, 4, 5, 1];
    try {
      const supportsColor = require_supports_color();
      if (supportsColor && (supportsColor.stderr || supportsColor).level >= 2) {
        exports.colors = [
          20,
          21,
          26,
          27,
          32,
          33,
          38,
          39,
          40,
          41,
          42,
          43,
          44,
          45,
          56,
          57,
          62,
          63,
          68,
          69,
          74,
          75,
          76,
          77,
          78,
          79,
          80,
          81,
          92,
          93,
          98,
          99,
          112,
          113,
          128,
          129,
          134,
          135,
          148,
          149,
          160,
          161,
          162,
          163,
          164,
          165,
          166,
          167,
          168,
          169,
          170,
          171,
          172,
          173,
          178,
          179,
          184,
          185,
          196,
          197,
          198,
          199,
          200,
          201,
          202,
          203,
          204,
          205,
          206,
          207,
          208,
          209,
          214,
          215,
          220,
          221
        ];
      }
    } catch (error) {
    }
    exports.inspectOpts = Object.keys(process.env).filter((key) => {
      return /^debug_/i.test(key);
    }).reduce((obj, key) => {
      const prop = key.substring(6).toLowerCase().replace(/_([a-z])/g, (_, k) => {
        return k.toUpperCase();
      });
      let val = process.env[key];
      if (/^(yes|on|true|enabled)$/i.test(val)) {
        val = true;
      } else if (/^(no|off|false|disabled)$/i.test(val)) {
        val = false;
      } else if (val === "null") {
        val = null;
      } else {
        val = Number(val);
      }
      obj[prop] = val;
      return obj;
    }, {});
    function useColors() {
      return "colors" in exports.inspectOpts ? Boolean(exports.inspectOpts.colors) : tty.isatty(process.stderr.fd);
    }
    function formatArgs(args) {
      const { namespace: name, useColors: useColors2 } = this;
      if (useColors2) {
        const c = this.color;
        const colorCode = "\x1B[3" + (c < 8 ? c : "8;5;" + c);
        const prefix = `  ${colorCode};1m${name} \x1B[0m`;
        args[0] = prefix + args[0].split("\n").join("\n" + prefix);
        args.push(colorCode + "m+" + module.exports.humanize(this.diff) + "\x1B[0m");
      } else {
        args[0] = getDate() + name + " " + args[0];
      }
    }
    function getDate() {
      if (exports.inspectOpts.hideDate) {
        return "";
      }
      return (/* @__PURE__ */ new Date()).toISOString() + " ";
    }
    function log(...args) {
      return process.stderr.write(util.formatWithOptions(exports.inspectOpts, ...args) + "\n");
    }
    function save(namespaces) {
      if (namespaces) {
        process.env.DEBUG = namespaces;
      } else {
        delete process.env.DEBUG;
      }
    }
    function load() {
      return process.env.DEBUG;
    }
    function init(debug) {
      debug.inspectOpts = {};
      const keys = Object.keys(exports.inspectOpts);
      for (let i = 0; i < keys.length; i++) {
        debug.inspectOpts[keys[i]] = exports.inspectOpts[keys[i]];
      }
    }
    module.exports = require_common()(exports);
    var { formatters } = module.exports;
    formatters.o = function(v) {
      this.inspectOpts.colors = this.useColors;
      return util.inspect(v, this.inspectOpts).split("\n").map((str) => str.trim()).join(" ");
    };
    formatters.O = function(v) {
      this.inspectOpts.colors = this.useColors;
      return util.inspect(v, this.inspectOpts);
    };
  }
});

// node_modules/debug/src/index.js
var require_src = __commonJS({
  "node_modules/debug/src/index.js"(exports, module) {
    if (typeof process === "undefined" || process.type === "renderer" || process.browser === true || process.__nwjs) {
      module.exports = require_browser();
    } else {
      module.exports = require_node();
    }
  }
});

// node_modules/follow-redirects/debug.js
var require_debug = __commonJS({
  "node_modules/follow-redirects/debug.js"(exports, module) {
    var debug;
    module.exports = function() {
      if (!debug) {
        try {
          debug = require_src()("follow-redirects");
        } catch (error) {
        }
        if (typeof debug !== "function") {
          debug = function() {
          };
        }
      }
      debug.apply(null, arguments);
    };
  }
});

// node_modules/follow-redirects/index.js
var require_follow_redirects = __commonJS({
  "node_modules/follow-redirects/index.js"(exports, module) {
    var url = __require("url");
    var URL2 = url.URL;
    var http = __require("http");
    var https = __require("https");
    var Writable = __require("stream").Writable;
    var assert = __require("assert");
    var debug = require_debug();
    (function detectUnsupportedEnvironment() {
      var looksLikeNode = typeof process !== "undefined";
      var looksLikeBrowser = typeof window !== "undefined" && typeof document !== "undefined";
      var looksLikeV8 = isFunction(Error.captureStackTrace);
      if (!looksLikeNode && (looksLikeBrowser || !looksLikeV8)) {
        console.warn("The follow-redirects package should be excluded from browser builds.");
      }
    })();
    var useNativeURL = false;
    try {
      assert(new URL2(""));
    } catch (error) {
      useNativeURL = error.code === "ERR_INVALID_URL";
    }
    var preservedUrlFields = [
      "auth",
      "host",
      "hostname",
      "href",
      "path",
      "pathname",
      "port",
      "protocol",
      "query",
      "search",
      "hash"
    ];
    var events = ["abort", "aborted", "connect", "error", "socket", "timeout"];
    var eventHandlers = /* @__PURE__ */ Object.create(null);
    events.forEach(function(event) {
      eventHandlers[event] = function(arg1, arg2, arg3) {
        this._redirectable.emit(event, arg1, arg2, arg3);
      };
    });
    var InvalidUrlError = createErrorType(
      "ERR_INVALID_URL",
      "Invalid URL",
      TypeError
    );
    var RedirectionError = createErrorType(
      "ERR_FR_REDIRECTION_FAILURE",
      "Redirected request failed"
    );
    var TooManyRedirectsError = createErrorType(
      "ERR_FR_TOO_MANY_REDIRECTS",
      "Maximum number of redirects exceeded",
      RedirectionError
    );
    var MaxBodyLengthExceededError = createErrorType(
      "ERR_FR_MAX_BODY_LENGTH_EXCEEDED",
      "Request body larger than maxBodyLength limit"
    );
    var WriteAfterEndError = createErrorType(
      "ERR_STREAM_WRITE_AFTER_END",
      "write after end"
    );
    var destroy = Writable.prototype.destroy || noop;
    function RedirectableRequest(options, responseCallback) {
      Writable.call(this);
      this._sanitizeOptions(options);
      this._options = options;
      this._ended = false;
      this._ending = false;
      this._redirectCount = 0;
      this._redirects = [];
      this._requestBodyLength = 0;
      this._requestBodyBuffers = [];
      if (responseCallback) {
        this.on("response", responseCallback);
      }
      var self2 = this;
      this._onNativeResponse = function(response) {
        try {
          self2._processResponse(response);
        } catch (cause) {
          self2.emit("error", cause instanceof RedirectionError ? cause : new RedirectionError({ cause }));
        }
      };
      this._performRequest();
    }
    RedirectableRequest.prototype = Object.create(Writable.prototype);
    RedirectableRequest.prototype.abort = function() {
      destroyRequest(this._currentRequest);
      this._currentRequest.abort();
      this.emit("abort");
    };
    RedirectableRequest.prototype.destroy = function(error) {
      destroyRequest(this._currentRequest, error);
      destroy.call(this, error);
      return this;
    };
    RedirectableRequest.prototype.write = function(data, encoding, callback) {
      if (this._ending) {
        throw new WriteAfterEndError();
      }
      if (!isString(data) && !isBuffer(data)) {
        throw new TypeError("data should be a string, Buffer or Uint8Array");
      }
      if (isFunction(encoding)) {
        callback = encoding;
        encoding = null;
      }
      if (data.length === 0) {
        if (callback) {
          callback();
        }
        return;
      }
      if (this._requestBodyLength + data.length <= this._options.maxBodyLength) {
        this._requestBodyLength += data.length;
        this._requestBodyBuffers.push({ data, encoding });
        this._currentRequest.write(data, encoding, callback);
      } else {
        this.emit("error", new MaxBodyLengthExceededError());
        this.abort();
      }
    };
    RedirectableRequest.prototype.end = function(data, encoding, callback) {
      if (isFunction(data)) {
        callback = data;
        data = encoding = null;
      } else if (isFunction(encoding)) {
        callback = encoding;
        encoding = null;
      }
      if (!data) {
        this._ended = this._ending = true;
        this._currentRequest.end(null, null, callback);
      } else {
        var self2 = this;
        var currentRequest = this._currentRequest;
        this.write(data, encoding, function() {
          self2._ended = true;
          currentRequest.end(null, null, callback);
        });
        this._ending = true;
      }
    };
    RedirectableRequest.prototype.setHeader = function(name, value) {
      this._options.headers[name] = value;
      this._currentRequest.setHeader(name, value);
    };
    RedirectableRequest.prototype.removeHeader = function(name) {
      delete this._options.headers[name];
      this._currentRequest.removeHeader(name);
    };
    RedirectableRequest.prototype.setTimeout = function(msecs, callback) {
      var self2 = this;
      function destroyOnTimeout(socket) {
        socket.setTimeout(msecs);
        socket.removeListener("timeout", socket.destroy);
        socket.addListener("timeout", socket.destroy);
      }
      function startTimer(socket) {
        if (self2._timeout) {
          clearTimeout(self2._timeout);
        }
        self2._timeout = setTimeout(function() {
          self2.emit("timeout");
          clearTimer();
        }, msecs);
        destroyOnTimeout(socket);
      }
      function clearTimer() {
        if (self2._timeout) {
          clearTimeout(self2._timeout);
          self2._timeout = null;
        }
        self2.removeListener("abort", clearTimer);
        self2.removeListener("error", clearTimer);
        self2.removeListener("response", clearTimer);
        self2.removeListener("close", clearTimer);
        if (callback) {
          self2.removeListener("timeout", callback);
        }
        if (!self2.socket) {
          self2._currentRequest.removeListener("socket", startTimer);
        }
      }
      if (callback) {
        this.on("timeout", callback);
      }
      if (this.socket) {
        startTimer(this.socket);
      } else {
        this._currentRequest.once("socket", startTimer);
      }
      this.on("socket", destroyOnTimeout);
      this.on("abort", clearTimer);
      this.on("error", clearTimer);
      this.on("response", clearTimer);
      this.on("close", clearTimer);
      return this;
    };
    [
      "flushHeaders",
      "getHeader",
      "setNoDelay",
      "setSocketKeepAlive"
    ].forEach(function(method) {
      RedirectableRequest.prototype[method] = function(a, b) {
        return this._currentRequest[method](a, b);
      };
    });
    ["aborted", "connection", "socket"].forEach(function(property) {
      Object.defineProperty(RedirectableRequest.prototype, property, {
        get: function() {
          return this._currentRequest[property];
        }
      });
    });
    RedirectableRequest.prototype._sanitizeOptions = function(options) {
      if (!options.headers) {
        options.headers = {};
      }
      if (options.host) {
        if (!options.hostname) {
          options.hostname = options.host;
        }
        delete options.host;
      }
      if (!options.pathname && options.path) {
        var searchPos = options.path.indexOf("?");
        if (searchPos < 0) {
          options.pathname = options.path;
        } else {
          options.pathname = options.path.substring(0, searchPos);
          options.search = options.path.substring(searchPos);
        }
      }
    };
    RedirectableRequest.prototype._performRequest = function() {
      var protocol = this._options.protocol;
      var nativeProtocol = this._options.nativeProtocols[protocol];
      if (!nativeProtocol) {
        throw new TypeError("Unsupported protocol " + protocol);
      }
      if (this._options.agents) {
        var scheme = protocol.slice(0, -1);
        this._options.agent = this._options.agents[scheme];
      }
      var request = this._currentRequest = nativeProtocol.request(this._options, this._onNativeResponse);
      request._redirectable = this;
      for (var event of events) {
        request.on(event, eventHandlers[event]);
      }
      this._currentUrl = /^\//.test(this._options.path) ? url.format(this._options) : (
        // When making a request to a proxy, […]
        // a client MUST send the target URI in absolute-form […].
        this._options.path
      );
      if (this._isRedirect) {
        var i = 0;
        var self2 = this;
        var buffers = this._requestBodyBuffers;
        (function writeNext(error) {
          if (request === self2._currentRequest) {
            if (error) {
              self2.emit("error", error);
            } else if (i < buffers.length) {
              var buffer = buffers[i++];
              if (!request.finished) {
                request.write(buffer.data, buffer.encoding, writeNext);
              }
            } else if (self2._ended) {
              request.end();
            }
          }
        })();
      }
    };
    RedirectableRequest.prototype._processResponse = function(response) {
      var statusCode = response.statusCode;
      if (this._options.trackRedirects) {
        this._redirects.push({
          url: this._currentUrl,
          headers: response.headers,
          statusCode
        });
      }
      var location = response.headers.location;
      if (!location || this._options.followRedirects === false || statusCode < 300 || statusCode >= 400) {
        response.responseUrl = this._currentUrl;
        response.redirects = this._redirects;
        this.emit("response", response);
        this._requestBodyBuffers = [];
        return;
      }
      destroyRequest(this._currentRequest);
      response.destroy();
      if (++this._redirectCount > this._options.maxRedirects) {
        throw new TooManyRedirectsError();
      }
      var requestHeaders;
      var beforeRedirect = this._options.beforeRedirect;
      if (beforeRedirect) {
        requestHeaders = Object.assign({
          // The Host header was set by nativeProtocol.request
          Host: response.req.getHeader("host")
        }, this._options.headers);
      }
      var method = this._options.method;
      if ((statusCode === 301 || statusCode === 302) && this._options.method === "POST" || // RFC7231§6.4.4: The 303 (See Other) status code indicates that
      // the server is redirecting the user agent to a different resource […]
      // A user agent can perform a retrieval request targeting that URI
      // (a GET or HEAD request if using HTTP) […]
      statusCode === 303 && !/^(?:GET|HEAD)$/.test(this._options.method)) {
        this._options.method = "GET";
        this._requestBodyBuffers = [];
        removeMatchingHeaders(/^content-/i, this._options.headers);
      }
      var currentHostHeader = removeMatchingHeaders(/^host$/i, this._options.headers);
      var currentUrlParts = parseUrl(this._currentUrl);
      var currentHost = currentHostHeader || currentUrlParts.host;
      var currentUrl = /^\w+:/.test(location) ? this._currentUrl : url.format(Object.assign(currentUrlParts, { host: currentHost }));
      var redirectUrl = resolveUrl(location, currentUrl);
      debug("redirecting to", redirectUrl.href);
      this._isRedirect = true;
      spreadUrlObject(redirectUrl, this._options);
      if (redirectUrl.protocol !== currentUrlParts.protocol && redirectUrl.protocol !== "https:" || redirectUrl.host !== currentHost && !isSubdomain(redirectUrl.host, currentHost)) {
        removeMatchingHeaders(/^(?:(?:proxy-)?authorization|cookie)$/i, this._options.headers);
      }
      if (isFunction(beforeRedirect)) {
        var responseDetails = {
          headers: response.headers,
          statusCode
        };
        var requestDetails = {
          url: currentUrl,
          method,
          headers: requestHeaders
        };
        beforeRedirect(this._options, responseDetails, requestDetails);
        this._sanitizeOptions(this._options);
      }
      this._performRequest();
    };
    function wrap(protocols) {
      var exports2 = {
        maxRedirects: 21,
        maxBodyLength: 10 * 1024 * 1024
      };
      var nativeProtocols = {};
      Object.keys(protocols).forEach(function(scheme) {
        var protocol = scheme + ":";
        var nativeProtocol = nativeProtocols[protocol] = protocols[scheme];
        var wrappedProtocol = exports2[scheme] = Object.create(nativeProtocol);
        function request(input, options, callback) {
          if (isURL(input)) {
            input = spreadUrlObject(input);
          } else if (isString(input)) {
            input = spreadUrlObject(parseUrl(input));
          } else {
            callback = options;
            options = validateUrl(input);
            input = { protocol };
          }
          if (isFunction(options)) {
            callback = options;
            options = null;
          }
          options = Object.assign({
            maxRedirects: exports2.maxRedirects,
            maxBodyLength: exports2.maxBodyLength
          }, input, options);
          options.nativeProtocols = nativeProtocols;
          if (!isString(options.host) && !isString(options.hostname)) {
            options.hostname = "::1";
          }
          assert.equal(options.protocol, protocol, "protocol mismatch");
          debug("options", options);
          return new RedirectableRequest(options, callback);
        }
        function get(input, options, callback) {
          var wrappedRequest = wrappedProtocol.request(input, options, callback);
          wrappedRequest.end();
          return wrappedRequest;
        }
        Object.defineProperties(wrappedProtocol, {
          request: { value: request, configurable: true, enumerable: true, writable: true },
          get: { value: get, configurable: true, enumerable: true, writable: true }
        });
      });
      return exports2;
    }
    function noop() {
    }
    function parseUrl(input) {
      var parsed;
      if (useNativeURL) {
        parsed = new URL2(input);
      } else {
        parsed = validateUrl(url.parse(input));
        if (!isString(parsed.protocol)) {
          throw new InvalidUrlError({ input });
        }
      }
      return parsed;
    }
    function resolveUrl(relative, base) {
      return useNativeURL ? new URL2(relative, base) : parseUrl(url.resolve(base, relative));
    }
    function validateUrl(input) {
      if (/^\[/.test(input.hostname) && !/^\[[:0-9a-f]+\]$/i.test(input.hostname)) {
        throw new InvalidUrlError({ input: input.href || input });
      }
      if (/^\[/.test(input.host) && !/^\[[:0-9a-f]+\](:\d+)?$/i.test(input.host)) {
        throw new InvalidUrlError({ input: input.href || input });
      }
      return input;
    }
    function spreadUrlObject(urlObject, target) {
      var spread = target || {};
      for (var key of preservedUrlFields) {
        spread[key] = urlObject[key];
      }
      if (spread.hostname.startsWith("[")) {
        spread.hostname = spread.hostname.slice(1, -1);
      }
      if (spread.port !== "") {
        spread.port = Number(spread.port);
      }
      spread.path = spread.search ? spread.pathname + spread.search : spread.pathname;
      return spread;
    }
    function removeMatchingHeaders(regex, headers) {
      var lastValue;
      for (var header in headers) {
        if (regex.test(header)) {
          lastValue = headers[header];
          delete headers[header];
        }
      }
      return lastValue === null || typeof lastValue === "undefined" ? void 0 : String(lastValue).trim();
    }
    function createErrorType(code, message, baseClass) {
      function CustomError(properties) {
        if (isFunction(Error.captureStackTrace)) {
          Error.captureStackTrace(this, this.constructor);
        }
        Object.assign(this, properties || {});
        this.code = code;
        this.message = this.cause ? message + ": " + this.cause.message : message;
      }
      CustomError.prototype = new (baseClass || Error)();
      Object.defineProperties(CustomError.prototype, {
        constructor: {
          value: CustomError,
          enumerable: false
        },
        name: {
          value: "Error [" + code + "]",
          enumerable: false
        }
      });
      return CustomError;
    }
    function destroyRequest(request, error) {
      for (var event of events) {
        request.removeListener(event, eventHandlers[event]);
      }
      request.on("error", noop);
      request.destroy(error);
    }
    function isSubdomain(subdomain, domain) {
      assert(isString(subdomain) && isString(domain));
      var dot = subdomain.length - domain.length - 1;
      return dot > 0 && subdomain[dot] === "." && subdomain.endsWith(domain);
    }
    function isString(value) {
      return typeof value === "string" || value instanceof String;
    }
    function isFunction(value) {
      return typeof value === "function";
    }
    function isBuffer(value) {
      return typeof value === "object" && "length" in value;
    }
    function isURL(value) {
      return URL2 && value instanceof URL2;
    }
    module.exports = wrap({ http, https });
    module.exports.wrap = wrap;
  }
});

// node_modules/axios/package.json
var require_package = __commonJS({
  "node_modules/axios/package.json"(exports, module) {
    module.exports = {
      name: "axios",
      version: "0.21.4",
      description: "Promise based HTTP client for the browser and node.js",
      main: "index.js",
      scripts: {
        test: "grunt test",
        start: "node ./sandbox/server.js",
        build: "NODE_ENV=production grunt build",
        preversion: "npm test",
        version: "npm run build && grunt version && git add -A dist && git add CHANGELOG.md bower.json package.json",
        postversion: "git push && git push --tags",
        examples: "node ./examples/server.js",
        coveralls: "cat coverage/lcov.info | ./node_modules/coveralls/bin/coveralls.js",
        fix: "eslint --fix lib/**/*.js"
      },
      repository: {
        type: "git",
        url: "https://github.com/axios/axios.git"
      },
      keywords: [
        "xhr",
        "http",
        "ajax",
        "promise",
        "node"
      ],
      author: "Matt Zabriskie",
      license: "MIT",
      bugs: {
        url: "https://github.com/axios/axios/issues"
      },
      homepage: "https://axios-http.com",
      devDependencies: {
        coveralls: "^3.0.0",
        "es6-promise": "^4.2.4",
        grunt: "^1.3.0",
        "grunt-banner": "^0.6.0",
        "grunt-cli": "^1.2.0",
        "grunt-contrib-clean": "^1.1.0",
        "grunt-contrib-watch": "^1.0.0",
        "grunt-eslint": "^23.0.0",
        "grunt-karma": "^4.0.0",
        "grunt-mocha-test": "^0.13.3",
        "grunt-ts": "^6.0.0-beta.19",
        "grunt-webpack": "^4.0.2",
        "istanbul-instrumenter-loader": "^1.0.0",
        "jasmine-core": "^2.4.1",
        karma: "^6.3.2",
        "karma-chrome-launcher": "^3.1.0",
        "karma-firefox-launcher": "^2.1.0",
        "karma-jasmine": "^1.1.1",
        "karma-jasmine-ajax": "^0.1.13",
        "karma-safari-launcher": "^1.0.0",
        "karma-sauce-launcher": "^4.3.6",
        "karma-sinon": "^1.0.5",
        "karma-sourcemap-loader": "^0.3.8",
        "karma-webpack": "^4.0.2",
        "load-grunt-tasks": "^3.5.2",
        minimist: "^1.2.0",
        mocha: "^8.2.1",
        sinon: "^4.5.0",
        "terser-webpack-plugin": "^4.2.3",
        typescript: "^4.0.5",
        "url-search-params": "^0.10.0",
        webpack: "^4.44.2",
        "webpack-dev-server": "^3.11.0"
      },
      browser: {
        "./lib/adapters/http.js": "./lib/adapters/xhr.js"
      },
      jsdelivr: "dist/axios.min.js",
      unpkg: "dist/axios.min.js",
      typings: "./index.d.ts",
      dependencies: {
        "follow-redirects": "^1.14.0"
      },
      bundlesize: [
        {
          path: "./dist/axios.min.js",
          threshold: "5kB"
        }
      ]
    };
  }
});

// node_modules/axios/lib/adapters/http.js
var require_http = __commonJS({
  "node_modules/axios/lib/adapters/http.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    var settle = require_settle();
    var buildFullPath = require_buildFullPath();
    var buildURL = require_buildURL();
    var http = __require("http");
    var https = __require("https");
    var httpFollow = require_follow_redirects().http;
    var httpsFollow = require_follow_redirects().https;
    var url = __require("url");
    var zlib = __require("zlib");
    var pkg2 = require_package();
    var createError = require_createError();
    var enhanceError = require_enhanceError();
    var isHttps = /https:?/;
    function setProxy(options, proxy, location) {
      options.hostname = proxy.host;
      options.host = proxy.host;
      options.port = proxy.port;
      options.path = location;
      if (proxy.auth) {
        var base64 = Buffer.from(proxy.auth.username + ":" + proxy.auth.password, "utf8").toString("base64");
        options.headers["Proxy-Authorization"] = "Basic " + base64;
      }
      options.beforeRedirect = function beforeRedirect(redirection) {
        redirection.headers.host = redirection.host;
        setProxy(redirection, proxy, redirection.href);
      };
    }
    module.exports = function httpAdapter(config2) {
      return new Promise(function dispatchHttpRequest(resolvePromise, rejectPromise) {
        var resolve = function resolve2(value) {
          resolvePromise(value);
        };
        var reject = function reject2(value) {
          rejectPromise(value);
        };
        var data = config2.data;
        var headers = config2.headers;
        if ("User-Agent" in headers || "user-agent" in headers) {
          if (!headers["User-Agent"] && !headers["user-agent"]) {
            delete headers["User-Agent"];
            delete headers["user-agent"];
          }
        } else {
          headers["User-Agent"] = "axios/" + pkg2.version;
        }
        if (data && !utils.isStream(data)) {
          if (Buffer.isBuffer(data)) {
          } else if (utils.isArrayBuffer(data)) {
            data = Buffer.from(new Uint8Array(data));
          } else if (utils.isString(data)) {
            data = Buffer.from(data, "utf-8");
          } else {
            return reject(createError(
              "Data after transformation must be a string, an ArrayBuffer, a Buffer, or a Stream",
              config2
            ));
          }
          headers["Content-Length"] = data.length;
        }
        var auth = void 0;
        if (config2.auth) {
          var username = config2.auth.username || "";
          var password = config2.auth.password || "";
          auth = username + ":" + password;
        }
        var fullPath = buildFullPath(config2.baseURL, config2.url);
        var parsed = url.parse(fullPath);
        var protocol = parsed.protocol || "http:";
        if (!auth && parsed.auth) {
          var urlAuth = parsed.auth.split(":");
          var urlUsername = urlAuth[0] || "";
          var urlPassword = urlAuth[1] || "";
          auth = urlUsername + ":" + urlPassword;
        }
        if (auth) {
          delete headers.Authorization;
        }
        var isHttpsRequest = isHttps.test(protocol);
        var agent = isHttpsRequest ? config2.httpsAgent : config2.httpAgent;
        var options = {
          path: buildURL(parsed.path, config2.params, config2.paramsSerializer).replace(/^\?/, ""),
          method: config2.method.toUpperCase(),
          headers,
          agent,
          agents: { http: config2.httpAgent, https: config2.httpsAgent },
          auth
        };
        if (config2.socketPath) {
          options.socketPath = config2.socketPath;
        } else {
          options.hostname = parsed.hostname;
          options.port = parsed.port;
        }
        var proxy = config2.proxy;
        if (!proxy && proxy !== false) {
          var proxyEnv = protocol.slice(0, -1) + "_proxy";
          var proxyUrl = process.env[proxyEnv] || process.env[proxyEnv.toUpperCase()];
          if (proxyUrl) {
            var parsedProxyUrl = url.parse(proxyUrl);
            var noProxyEnv = process.env.no_proxy || process.env.NO_PROXY;
            var shouldProxy = true;
            if (noProxyEnv) {
              var noProxy = noProxyEnv.split(",").map(function trim(s) {
                return s.trim();
              });
              shouldProxy = !noProxy.some(function proxyMatch(proxyElement) {
                if (!proxyElement) {
                  return false;
                }
                if (proxyElement === "*") {
                  return true;
                }
                if (proxyElement[0] === "." && parsed.hostname.substr(parsed.hostname.length - proxyElement.length) === proxyElement) {
                  return true;
                }
                return parsed.hostname === proxyElement;
              });
            }
            if (shouldProxy) {
              proxy = {
                host: parsedProxyUrl.hostname,
                port: parsedProxyUrl.port,
                protocol: parsedProxyUrl.protocol
              };
              if (parsedProxyUrl.auth) {
                var proxyUrlAuth = parsedProxyUrl.auth.split(":");
                proxy.auth = {
                  username: proxyUrlAuth[0],
                  password: proxyUrlAuth[1]
                };
              }
            }
          }
        }
        if (proxy) {
          options.headers.host = parsed.hostname + (parsed.port ? ":" + parsed.port : "");
          setProxy(options, proxy, protocol + "//" + parsed.hostname + (parsed.port ? ":" + parsed.port : "") + options.path);
        }
        var transport;
        var isHttpsProxy = isHttpsRequest && (proxy ? isHttps.test(proxy.protocol) : true);
        if (config2.transport) {
          transport = config2.transport;
        } else if (config2.maxRedirects === 0) {
          transport = isHttpsProxy ? https : http;
        } else {
          if (config2.maxRedirects) {
            options.maxRedirects = config2.maxRedirects;
          }
          transport = isHttpsProxy ? httpsFollow : httpFollow;
        }
        if (config2.maxBodyLength > -1) {
          options.maxBodyLength = config2.maxBodyLength;
        }
        var req = transport.request(options, function handleResponse(res) {
          if (req.aborted) return;
          var stream = res;
          var lastRequest = res.req || req;
          if (res.statusCode !== 204 && lastRequest.method !== "HEAD" && config2.decompress !== false) {
            switch (res.headers["content-encoding"]) {
              /*eslint default-case:0*/
              case "gzip":
              case "compress":
              case "deflate":
                stream = stream.pipe(zlib.createUnzip());
                delete res.headers["content-encoding"];
                break;
            }
          }
          var response = {
            status: res.statusCode,
            statusText: res.statusMessage,
            headers: res.headers,
            config: config2,
            request: lastRequest
          };
          if (config2.responseType === "stream") {
            response.data = stream;
            settle(resolve, reject, response);
          } else {
            var responseBuffer = [];
            var totalResponseBytes = 0;
            stream.on("data", function handleStreamData(chunk) {
              responseBuffer.push(chunk);
              totalResponseBytes += chunk.length;
              if (config2.maxContentLength > -1 && totalResponseBytes > config2.maxContentLength) {
                stream.destroy();
                reject(createError(
                  "maxContentLength size of " + config2.maxContentLength + " exceeded",
                  config2,
                  null,
                  lastRequest
                ));
              }
            });
            stream.on("error", function handleStreamError(err) {
              if (req.aborted) return;
              reject(enhanceError(err, config2, null, lastRequest));
            });
            stream.on("end", function handleStreamEnd() {
              var responseData = Buffer.concat(responseBuffer);
              if (config2.responseType !== "arraybuffer") {
                responseData = responseData.toString(config2.responseEncoding);
                if (!config2.responseEncoding || config2.responseEncoding === "utf8") {
                  responseData = utils.stripBOM(responseData);
                }
              }
              response.data = responseData;
              settle(resolve, reject, response);
            });
          }
        });
        req.on("error", function handleRequestError(err) {
          if (req.aborted && err.code !== "ERR_FR_TOO_MANY_REDIRECTS") return;
          reject(enhanceError(err, config2, null, req));
        });
        if (config2.timeout) {
          var timeout = parseInt(config2.timeout, 10);
          if (isNaN(timeout)) {
            reject(createError(
              "error trying to parse `config.timeout` to int",
              config2,
              "ERR_PARSE_TIMEOUT",
              req
            ));
            return;
          }
          req.setTimeout(timeout, function handleRequestTimeout() {
            req.abort();
            reject(createError(
              "timeout of " + timeout + "ms exceeded",
              config2,
              config2.transitional && config2.transitional.clarifyTimeoutError ? "ETIMEDOUT" : "ECONNABORTED",
              req
            ));
          });
        }
        if (config2.cancelToken) {
          config2.cancelToken.promise.then(function onCanceled(cancel) {
            if (req.aborted) return;
            req.abort();
            reject(cancel);
          });
        }
        if (utils.isStream(data)) {
          data.on("error", function handleStreamError(err) {
            reject(enhanceError(err, config2, null, req));
          }).pipe(req);
        } else {
          req.end(data);
        }
      });
    };
  }
});

// node_modules/axios/lib/defaults.js
var require_defaults = __commonJS({
  "node_modules/axios/lib/defaults.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    var normalizeHeaderName = require_normalizeHeaderName();
    var enhanceError = require_enhanceError();
    var DEFAULT_CONTENT_TYPE = {
      "Content-Type": "application/x-www-form-urlencoded"
    };
    function setContentTypeIfUnset(headers, value) {
      if (!utils.isUndefined(headers) && utils.isUndefined(headers["Content-Type"])) {
        headers["Content-Type"] = value;
      }
    }
    function getDefaultAdapter() {
      var adapter;
      if (typeof XMLHttpRequest !== "undefined") {
        adapter = require_xhr();
      } else if (typeof process !== "undefined" && Object.prototype.toString.call(process) === "[object process]") {
        adapter = require_http();
      }
      return adapter;
    }
    function stringifySafely(rawValue, parser, encoder) {
      if (utils.isString(rawValue)) {
        try {
          (parser || JSON.parse)(rawValue);
          return utils.trim(rawValue);
        } catch (e) {
          if (e.name !== "SyntaxError") {
            throw e;
          }
        }
      }
      return (encoder || JSON.stringify)(rawValue);
    }
    var defaults = {
      transitional: {
        silentJSONParsing: true,
        forcedJSONParsing: true,
        clarifyTimeoutError: false
      },
      adapter: getDefaultAdapter(),
      transformRequest: [function transformRequest(data, headers) {
        normalizeHeaderName(headers, "Accept");
        normalizeHeaderName(headers, "Content-Type");
        if (utils.isFormData(data) || utils.isArrayBuffer(data) || utils.isBuffer(data) || utils.isStream(data) || utils.isFile(data) || utils.isBlob(data)) {
          return data;
        }
        if (utils.isArrayBufferView(data)) {
          return data.buffer;
        }
        if (utils.isURLSearchParams(data)) {
          setContentTypeIfUnset(headers, "application/x-www-form-urlencoded;charset=utf-8");
          return data.toString();
        }
        if (utils.isObject(data) || headers && headers["Content-Type"] === "application/json") {
          setContentTypeIfUnset(headers, "application/json");
          return stringifySafely(data);
        }
        return data;
      }],
      transformResponse: [function transformResponse(data) {
        var transitional = this.transitional;
        var silentJSONParsing = transitional && transitional.silentJSONParsing;
        var forcedJSONParsing = transitional && transitional.forcedJSONParsing;
        var strictJSONParsing = !silentJSONParsing && this.responseType === "json";
        if (strictJSONParsing || forcedJSONParsing && utils.isString(data) && data.length) {
          try {
            return JSON.parse(data);
          } catch (e) {
            if (strictJSONParsing) {
              if (e.name === "SyntaxError") {
                throw enhanceError(e, this, "E_JSON_PARSE");
              }
              throw e;
            }
          }
        }
        return data;
      }],
      /**
       * A timeout in milliseconds to abort a request. If set to 0 (default) a
       * timeout is not created.
       */
      timeout: 0,
      xsrfCookieName: "XSRF-TOKEN",
      xsrfHeaderName: "X-XSRF-TOKEN",
      maxContentLength: -1,
      maxBodyLength: -1,
      validateStatus: function validateStatus(status) {
        return status >= 200 && status < 300;
      }
    };
    defaults.headers = {
      common: {
        "Accept": "application/json, text/plain, */*"
      }
    };
    utils.forEach(["delete", "get", "head"], function forEachMethodNoData(method) {
      defaults.headers[method] = {};
    });
    utils.forEach(["post", "put", "patch"], function forEachMethodWithData(method) {
      defaults.headers[method] = utils.merge(DEFAULT_CONTENT_TYPE);
    });
    module.exports = defaults;
  }
});

// node_modules/axios/lib/core/transformData.js
var require_transformData = __commonJS({
  "node_modules/axios/lib/core/transformData.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    var defaults = require_defaults();
    module.exports = function transformData(data, headers, fns) {
      var context = this || defaults;
      utils.forEach(fns, function transform(fn) {
        data = fn.call(context, data, headers);
      });
      return data;
    };
  }
});

// node_modules/axios/lib/cancel/isCancel.js
var require_isCancel = __commonJS({
  "node_modules/axios/lib/cancel/isCancel.js"(exports, module) {
    "use strict";
    module.exports = function isCancel(value) {
      return !!(value && value.__CANCEL__);
    };
  }
});

// node_modules/axios/lib/core/dispatchRequest.js
var require_dispatchRequest = __commonJS({
  "node_modules/axios/lib/core/dispatchRequest.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    var transformData = require_transformData();
    var isCancel = require_isCancel();
    var defaults = require_defaults();
    function throwIfCancellationRequested(config2) {
      if (config2.cancelToken) {
        config2.cancelToken.throwIfRequested();
      }
    }
    module.exports = function dispatchRequest(config2) {
      throwIfCancellationRequested(config2);
      config2.headers = config2.headers || {};
      config2.data = transformData.call(
        config2,
        config2.data,
        config2.headers,
        config2.transformRequest
      );
      config2.headers = utils.merge(
        config2.headers.common || {},
        config2.headers[config2.method] || {},
        config2.headers
      );
      utils.forEach(
        ["delete", "get", "head", "post", "put", "patch", "common"],
        function cleanHeaderConfig(method) {
          delete config2.headers[method];
        }
      );
      var adapter = config2.adapter || defaults.adapter;
      return adapter(config2).then(function onAdapterResolution(response) {
        throwIfCancellationRequested(config2);
        response.data = transformData.call(
          config2,
          response.data,
          response.headers,
          config2.transformResponse
        );
        return response;
      }, function onAdapterRejection(reason) {
        if (!isCancel(reason)) {
          throwIfCancellationRequested(config2);
          if (reason && reason.response) {
            reason.response.data = transformData.call(
              config2,
              reason.response.data,
              reason.response.headers,
              config2.transformResponse
            );
          }
        }
        return Promise.reject(reason);
      });
    };
  }
});

// node_modules/axios/lib/core/mergeConfig.js
var require_mergeConfig = __commonJS({
  "node_modules/axios/lib/core/mergeConfig.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    module.exports = function mergeConfig(config1, config2) {
      config2 = config2 || {};
      var config3 = {};
      var valueFromConfig2Keys = ["url", "method", "data"];
      var mergeDeepPropertiesKeys = ["headers", "auth", "proxy", "params"];
      var defaultToConfig2Keys = [
        "baseURL",
        "transformRequest",
        "transformResponse",
        "paramsSerializer",
        "timeout",
        "timeoutMessage",
        "withCredentials",
        "adapter",
        "responseType",
        "xsrfCookieName",
        "xsrfHeaderName",
        "onUploadProgress",
        "onDownloadProgress",
        "decompress",
        "maxContentLength",
        "maxBodyLength",
        "maxRedirects",
        "transport",
        "httpAgent",
        "httpsAgent",
        "cancelToken",
        "socketPath",
        "responseEncoding"
      ];
      var directMergeKeys = ["validateStatus"];
      function getMergedValue(target, source) {
        if (utils.isPlainObject(target) && utils.isPlainObject(source)) {
          return utils.merge(target, source);
        } else if (utils.isPlainObject(source)) {
          return utils.merge({}, source);
        } else if (utils.isArray(source)) {
          return source.slice();
        }
        return source;
      }
      function mergeDeepProperties(prop) {
        if (!utils.isUndefined(config2[prop])) {
          config3[prop] = getMergedValue(config1[prop], config2[prop]);
        } else if (!utils.isUndefined(config1[prop])) {
          config3[prop] = getMergedValue(void 0, config1[prop]);
        }
      }
      utils.forEach(valueFromConfig2Keys, function valueFromConfig2(prop) {
        if (!utils.isUndefined(config2[prop])) {
          config3[prop] = getMergedValue(void 0, config2[prop]);
        }
      });
      utils.forEach(mergeDeepPropertiesKeys, mergeDeepProperties);
      utils.forEach(defaultToConfig2Keys, function defaultToConfig2(prop) {
        if (!utils.isUndefined(config2[prop])) {
          config3[prop] = getMergedValue(void 0, config2[prop]);
        } else if (!utils.isUndefined(config1[prop])) {
          config3[prop] = getMergedValue(void 0, config1[prop]);
        }
      });
      utils.forEach(directMergeKeys, function merge(prop) {
        if (prop in config2) {
          config3[prop] = getMergedValue(config1[prop], config2[prop]);
        } else if (prop in config1) {
          config3[prop] = getMergedValue(void 0, config1[prop]);
        }
      });
      var axiosKeys = valueFromConfig2Keys.concat(mergeDeepPropertiesKeys).concat(defaultToConfig2Keys).concat(directMergeKeys);
      var otherKeys = Object.keys(config1).concat(Object.keys(config2)).filter(function filterAxiosKeys(key) {
        return axiosKeys.indexOf(key) === -1;
      });
      utils.forEach(otherKeys, mergeDeepProperties);
      return config3;
    };
  }
});

// node_modules/axios/lib/helpers/validator.js
var require_validator = __commonJS({
  "node_modules/axios/lib/helpers/validator.js"(exports, module) {
    "use strict";
    var pkg2 = require_package();
    var validators = {};
    ["object", "boolean", "number", "function", "string", "symbol"].forEach(function(type, i) {
      validators[type] = function validator(thing) {
        return typeof thing === type || "a" + (i < 1 ? "n " : " ") + type;
      };
    });
    var deprecatedWarnings = {};
    var currentVerArr = pkg2.version.split(".");
    function isOlderVersion(version2, thanVersion) {
      var pkgVersionArr = thanVersion ? thanVersion.split(".") : currentVerArr;
      var destVer = version2.split(".");
      for (var i = 0; i < 3; i++) {
        if (pkgVersionArr[i] > destVer[i]) {
          return true;
        } else if (pkgVersionArr[i] < destVer[i]) {
          return false;
        }
      }
      return false;
    }
    validators.transitional = function transitional(validator, version2, message) {
      var isDeprecated = version2 && isOlderVersion(version2);
      function formatMessage(opt, desc) {
        return "[Axios v" + pkg2.version + "] Transitional option '" + opt + "'" + desc + (message ? ". " + message : "");
      }
      return function(value, opt, opts) {
        if (validator === false) {
          throw new Error(formatMessage(opt, " has been removed in " + version2));
        }
        if (isDeprecated && !deprecatedWarnings[opt]) {
          deprecatedWarnings[opt] = true;
          console.warn(
            formatMessage(
              opt,
              " has been deprecated since v" + version2 + " and will be removed in the near future"
            )
          );
        }
        return validator ? validator(value, opt, opts) : true;
      };
    };
    function assertOptions(options, schema, allowUnknown) {
      if (typeof options !== "object") {
        throw new TypeError("options must be an object");
      }
      var keys = Object.keys(options);
      var i = keys.length;
      while (i-- > 0) {
        var opt = keys[i];
        var validator = schema[opt];
        if (validator) {
          var value = options[opt];
          var result = value === void 0 || validator(value, opt, options);
          if (result !== true) {
            throw new TypeError("option " + opt + " must be " + result);
          }
          continue;
        }
        if (allowUnknown !== true) {
          throw Error("Unknown option " + opt);
        }
      }
    }
    module.exports = {
      isOlderVersion,
      assertOptions,
      validators
    };
  }
});

// node_modules/axios/lib/core/Axios.js
var require_Axios = __commonJS({
  "node_modules/axios/lib/core/Axios.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    var buildURL = require_buildURL();
    var InterceptorManager = require_InterceptorManager();
    var dispatchRequest = require_dispatchRequest();
    var mergeConfig = require_mergeConfig();
    var validator = require_validator();
    var validators = validator.validators;
    function Axios(instanceConfig) {
      this.defaults = instanceConfig;
      this.interceptors = {
        request: new InterceptorManager(),
        response: new InterceptorManager()
      };
    }
    Axios.prototype.request = function request(config2) {
      if (typeof config2 === "string") {
        config2 = arguments[1] || {};
        config2.url = arguments[0];
      } else {
        config2 = config2 || {};
      }
      config2 = mergeConfig(this.defaults, config2);
      if (config2.method) {
        config2.method = config2.method.toLowerCase();
      } else if (this.defaults.method) {
        config2.method = this.defaults.method.toLowerCase();
      } else {
        config2.method = "get";
      }
      var transitional = config2.transitional;
      if (transitional !== void 0) {
        validator.assertOptions(transitional, {
          silentJSONParsing: validators.transitional(validators.boolean, "1.0.0"),
          forcedJSONParsing: validators.transitional(validators.boolean, "1.0.0"),
          clarifyTimeoutError: validators.transitional(validators.boolean, "1.0.0")
        }, false);
      }
      var requestInterceptorChain = [];
      var synchronousRequestInterceptors = true;
      this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
        if (typeof interceptor.runWhen === "function" && interceptor.runWhen(config2) === false) {
          return;
        }
        synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;
        requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
      });
      var responseInterceptorChain = [];
      this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
        responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
      });
      var promise;
      if (!synchronousRequestInterceptors) {
        var chain = [dispatchRequest, void 0];
        Array.prototype.unshift.apply(chain, requestInterceptorChain);
        chain = chain.concat(responseInterceptorChain);
        promise = Promise.resolve(config2);
        while (chain.length) {
          promise = promise.then(chain.shift(), chain.shift());
        }
        return promise;
      }
      var newConfig = config2;
      while (requestInterceptorChain.length) {
        var onFulfilled = requestInterceptorChain.shift();
        var onRejected = requestInterceptorChain.shift();
        try {
          newConfig = onFulfilled(newConfig);
        } catch (error) {
          onRejected(error);
          break;
        }
      }
      try {
        promise = dispatchRequest(newConfig);
      } catch (error) {
        return Promise.reject(error);
      }
      while (responseInterceptorChain.length) {
        promise = promise.then(responseInterceptorChain.shift(), responseInterceptorChain.shift());
      }
      return promise;
    };
    Axios.prototype.getUri = function getUri(config2) {
      config2 = mergeConfig(this.defaults, config2);
      return buildURL(config2.url, config2.params, config2.paramsSerializer).replace(/^\?/, "");
    };
    utils.forEach(["delete", "get", "head", "options"], function forEachMethodNoData(method) {
      Axios.prototype[method] = function(url, config2) {
        return this.request(mergeConfig(config2 || {}, {
          method,
          url,
          data: (config2 || {}).data
        }));
      };
    });
    utils.forEach(["post", "put", "patch"], function forEachMethodWithData(method) {
      Axios.prototype[method] = function(url, data, config2) {
        return this.request(mergeConfig(config2 || {}, {
          method,
          url,
          data
        }));
      };
    });
    module.exports = Axios;
  }
});

// node_modules/axios/lib/cancel/Cancel.js
var require_Cancel = __commonJS({
  "node_modules/axios/lib/cancel/Cancel.js"(exports, module) {
    "use strict";
    function Cancel(message) {
      this.message = message;
    }
    Cancel.prototype.toString = function toString() {
      return "Cancel" + (this.message ? ": " + this.message : "");
    };
    Cancel.prototype.__CANCEL__ = true;
    module.exports = Cancel;
  }
});

// node_modules/axios/lib/cancel/CancelToken.js
var require_CancelToken = __commonJS({
  "node_modules/axios/lib/cancel/CancelToken.js"(exports, module) {
    "use strict";
    var Cancel = require_Cancel();
    function CancelToken(executor) {
      if (typeof executor !== "function") {
        throw new TypeError("executor must be a function.");
      }
      var resolvePromise;
      this.promise = new Promise(function promiseExecutor(resolve) {
        resolvePromise = resolve;
      });
      var token = this;
      executor(function cancel(message) {
        if (token.reason) {
          return;
        }
        token.reason = new Cancel(message);
        resolvePromise(token.reason);
      });
    }
    CancelToken.prototype.throwIfRequested = function throwIfRequested() {
      if (this.reason) {
        throw this.reason;
      }
    };
    CancelToken.source = function source() {
      var cancel;
      var token = new CancelToken(function executor(c) {
        cancel = c;
      });
      return {
        token,
        cancel
      };
    };
    module.exports = CancelToken;
  }
});

// node_modules/axios/lib/helpers/spread.js
var require_spread = __commonJS({
  "node_modules/axios/lib/helpers/spread.js"(exports, module) {
    "use strict";
    module.exports = function spread(callback) {
      return function wrap(arr) {
        return callback.apply(null, arr);
      };
    };
  }
});

// node_modules/axios/lib/helpers/isAxiosError.js
var require_isAxiosError = __commonJS({
  "node_modules/axios/lib/helpers/isAxiosError.js"(exports, module) {
    "use strict";
    module.exports = function isAxiosError(payload) {
      return typeof payload === "object" && payload.isAxiosError === true;
    };
  }
});

// node_modules/axios/lib/axios.js
var require_axios = __commonJS({
  "node_modules/axios/lib/axios.js"(exports, module) {
    "use strict";
    var utils = require_utils();
    var bind = require_bind();
    var Axios = require_Axios();
    var mergeConfig = require_mergeConfig();
    var defaults = require_defaults();
    function createInstance(defaultConfig) {
      var context = new Axios(defaultConfig);
      var instance = bind(Axios.prototype.request, context);
      utils.extend(instance, Axios.prototype, context);
      utils.extend(instance, context);
      return instance;
    }
    var axios = createInstance(defaults);
    axios.Axios = Axios;
    axios.create = function create(instanceConfig) {
      return createInstance(mergeConfig(axios.defaults, instanceConfig));
    };
    axios.Cancel = require_Cancel();
    axios.CancelToken = require_CancelToken();
    axios.isCancel = require_isCancel();
    axios.all = function all(promises) {
      return Promise.all(promises);
    };
    axios.spread = require_spread();
    axios.isAxiosError = require_isAxiosError();
    module.exports = axios;
    module.exports.default = axios;
  }
});

// node_modules/axios/index.js
var require_axios2 = __commonJS({
  "node_modules/axios/index.js"(exports, module) {
    module.exports = require_axios();
  }
});

// node_modules/uuid/dist/esm-node/rng.js
import crypto from "crypto";
function rng() {
  if (poolPtr > rnds8Pool.length - 16) {
    crypto.randomFillSync(rnds8Pool);
    poolPtr = 0;
  }
  return rnds8Pool.slice(poolPtr, poolPtr += 16);
}
var rnds8Pool, poolPtr;
var init_rng = __esm({
  "node_modules/uuid/dist/esm-node/rng.js"() {
    rnds8Pool = new Uint8Array(256);
    poolPtr = rnds8Pool.length;
  }
});

// node_modules/uuid/dist/esm-node/regex.js
var regex_default;
var init_regex = __esm({
  "node_modules/uuid/dist/esm-node/regex.js"() {
    regex_default = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
  }
});

// node_modules/uuid/dist/esm-node/validate.js
function validate(uuid) {
  return typeof uuid === "string" && regex_default.test(uuid);
}
var validate_default;
var init_validate = __esm({
  "node_modules/uuid/dist/esm-node/validate.js"() {
    init_regex();
    validate_default = validate;
  }
});

// node_modules/uuid/dist/esm-node/stringify.js
function stringify(arr, offset = 0) {
  const uuid = (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
  if (!validate_default(uuid)) {
    throw TypeError("Stringified UUID is invalid");
  }
  return uuid;
}
var byteToHex, stringify_default;
var init_stringify = __esm({
  "node_modules/uuid/dist/esm-node/stringify.js"() {
    init_validate();
    byteToHex = [];
    for (let i = 0; i < 256; ++i) {
      byteToHex.push((i + 256).toString(16).substr(1));
    }
    stringify_default = stringify;
  }
});

// node_modules/uuid/dist/esm-node/v1.js
function v1(options, buf, offset) {
  let i = buf && offset || 0;
  const b = buf || new Array(16);
  options = options || {};
  let node = options.node || _nodeId;
  let clockseq = options.clockseq !== void 0 ? options.clockseq : _clockseq;
  if (node == null || clockseq == null) {
    const seedBytes = options.random || (options.rng || rng)();
    if (node == null) {
      node = _nodeId = [seedBytes[0] | 1, seedBytes[1], seedBytes[2], seedBytes[3], seedBytes[4], seedBytes[5]];
    }
    if (clockseq == null) {
      clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 16383;
    }
  }
  let msecs = options.msecs !== void 0 ? options.msecs : Date.now();
  let nsecs = options.nsecs !== void 0 ? options.nsecs : _lastNSecs + 1;
  const dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 1e4;
  if (dt < 0 && options.clockseq === void 0) {
    clockseq = clockseq + 1 & 16383;
  }
  if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === void 0) {
    nsecs = 0;
  }
  if (nsecs >= 1e4) {
    throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
  }
  _lastMSecs = msecs;
  _lastNSecs = nsecs;
  _clockseq = clockseq;
  msecs += 122192928e5;
  const tl = ((msecs & 268435455) * 1e4 + nsecs) % 4294967296;
  b[i++] = tl >>> 24 & 255;
  b[i++] = tl >>> 16 & 255;
  b[i++] = tl >>> 8 & 255;
  b[i++] = tl & 255;
  const tmh = msecs / 4294967296 * 1e4 & 268435455;
  b[i++] = tmh >>> 8 & 255;
  b[i++] = tmh & 255;
  b[i++] = tmh >>> 24 & 15 | 16;
  b[i++] = tmh >>> 16 & 255;
  b[i++] = clockseq >>> 8 | 128;
  b[i++] = clockseq & 255;
  for (let n = 0; n < 6; ++n) {
    b[i + n] = node[n];
  }
  return buf || stringify_default(b);
}
var _nodeId, _clockseq, _lastMSecs, _lastNSecs, v1_default;
var init_v1 = __esm({
  "node_modules/uuid/dist/esm-node/v1.js"() {
    init_rng();
    init_stringify();
    _lastMSecs = 0;
    _lastNSecs = 0;
    v1_default = v1;
  }
});

// node_modules/uuid/dist/esm-node/parse.js
function parse(uuid) {
  if (!validate_default(uuid)) {
    throw TypeError("Invalid UUID");
  }
  let v;
  const arr = new Uint8Array(16);
  arr[0] = (v = parseInt(uuid.slice(0, 8), 16)) >>> 24;
  arr[1] = v >>> 16 & 255;
  arr[2] = v >>> 8 & 255;
  arr[3] = v & 255;
  arr[4] = (v = parseInt(uuid.slice(9, 13), 16)) >>> 8;
  arr[5] = v & 255;
  arr[6] = (v = parseInt(uuid.slice(14, 18), 16)) >>> 8;
  arr[7] = v & 255;
  arr[8] = (v = parseInt(uuid.slice(19, 23), 16)) >>> 8;
  arr[9] = v & 255;
  arr[10] = (v = parseInt(uuid.slice(24, 36), 16)) / 1099511627776 & 255;
  arr[11] = v / 4294967296 & 255;
  arr[12] = v >>> 24 & 255;
  arr[13] = v >>> 16 & 255;
  arr[14] = v >>> 8 & 255;
  arr[15] = v & 255;
  return arr;
}
var parse_default;
var init_parse = __esm({
  "node_modules/uuid/dist/esm-node/parse.js"() {
    init_validate();
    parse_default = parse;
  }
});

// node_modules/uuid/dist/esm-node/v35.js
function stringToBytes(str) {
  str = unescape(encodeURIComponent(str));
  const bytes = [];
  for (let i = 0; i < str.length; ++i) {
    bytes.push(str.charCodeAt(i));
  }
  return bytes;
}
function v35_default(name, version2, hashfunc) {
  function generateUUID(value, namespace, buf, offset) {
    if (typeof value === "string") {
      value = stringToBytes(value);
    }
    if (typeof namespace === "string") {
      namespace = parse_default(namespace);
    }
    if (namespace.length !== 16) {
      throw TypeError("Namespace must be array-like (16 iterable integer values, 0-255)");
    }
    let bytes = new Uint8Array(16 + value.length);
    bytes.set(namespace);
    bytes.set(value, namespace.length);
    bytes = hashfunc(bytes);
    bytes[6] = bytes[6] & 15 | version2;
    bytes[8] = bytes[8] & 63 | 128;
    if (buf) {
      offset = offset || 0;
      for (let i = 0; i < 16; ++i) {
        buf[offset + i] = bytes[i];
      }
      return buf;
    }
    return stringify_default(bytes);
  }
  try {
    generateUUID.name = name;
  } catch (err) {
  }
  generateUUID.DNS = DNS;
  generateUUID.URL = URL;
  return generateUUID;
}
var DNS, URL;
var init_v35 = __esm({
  "node_modules/uuid/dist/esm-node/v35.js"() {
    init_stringify();
    init_parse();
    DNS = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
    URL = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
  }
});

// node_modules/uuid/dist/esm-node/md5.js
import crypto2 from "crypto";
function md5(bytes) {
  if (Array.isArray(bytes)) {
    bytes = Buffer.from(bytes);
  } else if (typeof bytes === "string") {
    bytes = Buffer.from(bytes, "utf8");
  }
  return crypto2.createHash("md5").update(bytes).digest();
}
var md5_default;
var init_md5 = __esm({
  "node_modules/uuid/dist/esm-node/md5.js"() {
    md5_default = md5;
  }
});

// node_modules/uuid/dist/esm-node/v3.js
var v3, v3_default;
var init_v3 = __esm({
  "node_modules/uuid/dist/esm-node/v3.js"() {
    init_v35();
    init_md5();
    v3 = v35_default("v3", 48, md5_default);
    v3_default = v3;
  }
});

// node_modules/uuid/dist/esm-node/v4.js
function v4(options, buf, offset) {
  options = options || {};
  const rnds = options.random || (options.rng || rng)();
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return stringify_default(rnds);
}
var v4_default;
var init_v4 = __esm({
  "node_modules/uuid/dist/esm-node/v4.js"() {
    init_rng();
    init_stringify();
    v4_default = v4;
  }
});

// node_modules/uuid/dist/esm-node/sha1.js
import crypto3 from "crypto";
function sha1(bytes) {
  if (Array.isArray(bytes)) {
    bytes = Buffer.from(bytes);
  } else if (typeof bytes === "string") {
    bytes = Buffer.from(bytes, "utf8");
  }
  return crypto3.createHash("sha1").update(bytes).digest();
}
var sha1_default;
var init_sha1 = __esm({
  "node_modules/uuid/dist/esm-node/sha1.js"() {
    sha1_default = sha1;
  }
});

// node_modules/uuid/dist/esm-node/v5.js
var v5, v5_default;
var init_v5 = __esm({
  "node_modules/uuid/dist/esm-node/v5.js"() {
    init_v35();
    init_sha1();
    v5 = v35_default("v5", 80, sha1_default);
    v5_default = v5;
  }
});

// node_modules/uuid/dist/esm-node/nil.js
var nil_default;
var init_nil = __esm({
  "node_modules/uuid/dist/esm-node/nil.js"() {
    nil_default = "00000000-0000-0000-0000-000000000000";
  }
});

// node_modules/uuid/dist/esm-node/version.js
function version(uuid) {
  if (!validate_default(uuid)) {
    throw TypeError("Invalid UUID");
  }
  return parseInt(uuid.substr(14, 1), 16);
}
var version_default;
var init_version = __esm({
  "node_modules/uuid/dist/esm-node/version.js"() {
    init_validate();
    version_default = version;
  }
});

// node_modules/uuid/dist/esm-node/index.js
var esm_node_exports = {};
__export(esm_node_exports, {
  NIL: () => nil_default,
  parse: () => parse_default,
  stringify: () => stringify_default,
  v1: () => v1_default,
  v3: () => v3_default,
  v4: () => v4_default,
  v5: () => v5_default,
  validate: () => validate_default,
  version: () => version_default
});
var init_esm_node = __esm({
  "node_modules/uuid/dist/esm-node/index.js"() {
    init_v1();
    init_v3();
    init_v4();
    init_v5();
    init_nil();
    init_version();
    init_validate();
    init_stringify();
    init_parse();
  }
});

// node_modules/assert-plus/assert.js
var require_assert = __commonJS({
  "node_modules/assert-plus/assert.js"(exports, module) {
    var assert = __require("assert");
    var Stream = __require("stream").Stream;
    var util = __require("util");
    var UUID_REGEXP = /^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$/;
    function _capitalize(str) {
      return str.charAt(0).toUpperCase() + str.slice(1);
    }
    function _toss(name, expected, oper, arg, actual) {
      throw new assert.AssertionError({
        message: util.format("%s (%s) is required", name, expected),
        actual: actual === void 0 ? typeof arg : actual(arg),
        expected,
        operator: oper || "===",
        stackStartFunction: _toss.caller
      });
    }
    function _getClass(arg) {
      return Object.prototype.toString.call(arg).slice(8, -1);
    }
    function noop() {
    }
    var types = {
      bool: {
        check: function(arg) {
          return typeof arg === "boolean";
        }
      },
      func: {
        check: function(arg) {
          return typeof arg === "function";
        }
      },
      string: {
        check: function(arg) {
          return typeof arg === "string";
        }
      },
      object: {
        check: function(arg) {
          return typeof arg === "object" && arg !== null;
        }
      },
      number: {
        check: function(arg) {
          return typeof arg === "number" && !isNaN(arg);
        }
      },
      finite: {
        check: function(arg) {
          return typeof arg === "number" && !isNaN(arg) && isFinite(arg);
        }
      },
      buffer: {
        check: function(arg) {
          return Buffer.isBuffer(arg);
        },
        operator: "Buffer.isBuffer"
      },
      array: {
        check: function(arg) {
          return Array.isArray(arg);
        },
        operator: "Array.isArray"
      },
      stream: {
        check: function(arg) {
          return arg instanceof Stream;
        },
        operator: "instanceof",
        actual: _getClass
      },
      date: {
        check: function(arg) {
          return arg instanceof Date;
        },
        operator: "instanceof",
        actual: _getClass
      },
      regexp: {
        check: function(arg) {
          return arg instanceof RegExp;
        },
        operator: "instanceof",
        actual: _getClass
      },
      uuid: {
        check: function(arg) {
          return typeof arg === "string" && UUID_REGEXP.test(arg);
        },
        operator: "isUUID"
      }
    };
    function _setExports(ndebug) {
      var keys = Object.keys(types);
      var out;
      if (process.env.NODE_NDEBUG) {
        out = noop;
      } else {
        out = function(arg, msg) {
          if (!arg) {
            _toss(msg, "true", arg);
          }
        };
      }
      keys.forEach(function(k) {
        if (ndebug) {
          out[k] = noop;
          return;
        }
        var type = types[k];
        out[k] = function(arg, msg) {
          if (!type.check(arg)) {
            _toss(msg, k, type.operator, arg, type.actual);
          }
        };
      });
      keys.forEach(function(k) {
        var name = "optional" + _capitalize(k);
        if (ndebug) {
          out[name] = noop;
          return;
        }
        var type = types[k];
        out[name] = function(arg, msg) {
          if (arg === void 0 || arg === null) {
            return;
          }
          if (!type.check(arg)) {
            _toss(msg, k, type.operator, arg, type.actual);
          }
        };
      });
      keys.forEach(function(k) {
        var name = "arrayOf" + _capitalize(k);
        if (ndebug) {
          out[name] = noop;
          return;
        }
        var type = types[k];
        var expected = "[" + k + "]";
        out[name] = function(arg, msg) {
          if (!Array.isArray(arg)) {
            _toss(msg, expected, type.operator, arg, type.actual);
          }
          var i;
          for (i = 0; i < arg.length; i++) {
            if (!type.check(arg[i])) {
              _toss(msg, expected, type.operator, arg, type.actual);
            }
          }
        };
      });
      keys.forEach(function(k) {
        var name = "optionalArrayOf" + _capitalize(k);
        if (ndebug) {
          out[name] = noop;
          return;
        }
        var type = types[k];
        var expected = "[" + k + "]";
        out[name] = function(arg, msg) {
          if (arg === void 0 || arg === null) {
            return;
          }
          if (!Array.isArray(arg)) {
            _toss(msg, expected, type.operator, arg, type.actual);
          }
          var i;
          for (i = 0; i < arg.length; i++) {
            if (!type.check(arg[i])) {
              _toss(msg, expected, type.operator, arg, type.actual);
            }
          }
        };
      });
      Object.keys(assert).forEach(function(k) {
        if (k === "AssertionError") {
          out[k] = assert[k];
          return;
        }
        if (ndebug) {
          out[k] = noop;
          return;
        }
        out[k] = assert[k];
      });
      out._setExports = _setExports;
      return out;
    }
    module.exports = _setExports(process.env.NODE_NDEBUG);
  }
});

// node_modules/extsprintf/lib/extsprintf.js
var require_extsprintf = __commonJS({
  "node_modules/extsprintf/lib/extsprintf.js"(exports) {
    var mod_assert = __require("assert");
    var mod_util = __require("util");
    exports.sprintf = jsSprintf;
    exports.printf = jsPrintf;
    exports.fprintf = jsFprintf;
    function jsSprintf(fmt) {
      var regex = [
        "([^%]*)",
        /* normal text */
        "%",
        /* start of format */
        "(['\\-+ #0]*?)",
        /* flags (optional) */
        "([1-9]\\d*)?",
        /* width (optional) */
        "(\\.([1-9]\\d*))?",
        /* precision (optional) */
        "[lhjztL]*?",
        /* length mods (ignored) */
        "([diouxXfFeEgGaAcCsSp%jr])"
        /* conversion */
      ].join("");
      var re = new RegExp(regex);
      var args = Array.prototype.slice.call(arguments, 1);
      var flags, width, precision, conversion;
      var left, pad, sign, arg, match;
      var ret = "";
      var argn = 1;
      mod_assert.equal("string", typeof fmt);
      while ((match = re.exec(fmt)) !== null) {
        ret += match[1];
        fmt = fmt.substring(match[0].length);
        flags = match[2] || "";
        width = match[3] || 0;
        precision = match[4] || "";
        conversion = match[6];
        left = false;
        sign = false;
        pad = " ";
        if (conversion == "%") {
          ret += "%";
          continue;
        }
        if (args.length === 0)
          throw new Error("too few args to sprintf");
        arg = args.shift();
        argn++;
        if (flags.match(/[\' #]/))
          throw new Error(
            "unsupported flags: " + flags
          );
        if (precision.length > 0)
          throw new Error(
            "non-zero precision not supported"
          );
        if (flags.match(/-/))
          left = true;
        if (flags.match(/0/))
          pad = "0";
        if (flags.match(/\+/))
          sign = true;
        switch (conversion) {
          case "s":
            if (arg === void 0 || arg === null)
              throw new Error("argument " + argn + ": attempted to print undefined or null as a string");
            ret += doPad(pad, width, left, arg.toString());
            break;
          case "d":
            arg = Math.floor(arg);
          /*jsl:fallthru*/
          case "f":
            sign = sign && arg > 0 ? "+" : "";
            ret += sign + doPad(
              pad,
              width,
              left,
              arg.toString()
            );
            break;
          case "x":
            ret += doPad(pad, width, left, arg.toString(16));
            break;
          case "j":
            if (width === 0)
              width = 10;
            ret += mod_util.inspect(arg, false, width);
            break;
          case "r":
            ret += dumpException(arg);
            break;
          default:
            throw new Error("unsupported conversion: " + conversion);
        }
      }
      ret += fmt;
      return ret;
    }
    function jsPrintf() {
      var args = Array.prototype.slice.call(arguments);
      args.unshift(process.stdout);
      jsFprintf.apply(null, args);
    }
    function jsFprintf(stream) {
      var args = Array.prototype.slice.call(arguments, 1);
      return stream.write(jsSprintf.apply(this, args));
    }
    function doPad(chr, width, left, str) {
      var ret = str;
      while (ret.length < width) {
        if (left)
          ret += chr;
        else
          ret = chr + ret;
      }
      return ret;
    }
    function dumpException(ex) {
      var ret;
      if (!(ex instanceof Error))
        throw new Error(jsSprintf("invalid type for %%r: %j", ex));
      ret = "EXCEPTION: " + ex.constructor.name + ": " + ex.stack;
      if (ex.cause && typeof ex.cause === "function") {
        var cex = ex.cause();
        if (cex) {
          ret += "\nCaused by: " + dumpException(cex);
        }
      }
      return ret;
    }
  }
});

// node_modules/core-util-is/lib/util.js
var require_util = __commonJS({
  "node_modules/core-util-is/lib/util.js"(exports) {
    function isArray(arg) {
      if (Array.isArray) {
        return Array.isArray(arg);
      }
      return objectToString(arg) === "[object Array]";
    }
    exports.isArray = isArray;
    function isBoolean(arg) {
      return typeof arg === "boolean";
    }
    exports.isBoolean = isBoolean;
    function isNull(arg) {
      return arg === null;
    }
    exports.isNull = isNull;
    function isNullOrUndefined(arg) {
      return arg == null;
    }
    exports.isNullOrUndefined = isNullOrUndefined;
    function isNumber(arg) {
      return typeof arg === "number";
    }
    exports.isNumber = isNumber;
    function isString(arg) {
      return typeof arg === "string";
    }
    exports.isString = isString;
    function isSymbol(arg) {
      return typeof arg === "symbol";
    }
    exports.isSymbol = isSymbol;
    function isUndefined(arg) {
      return arg === void 0;
    }
    exports.isUndefined = isUndefined;
    function isRegExp(re) {
      return objectToString(re) === "[object RegExp]";
    }
    exports.isRegExp = isRegExp;
    function isObject(arg) {
      return typeof arg === "object" && arg !== null;
    }
    exports.isObject = isObject;
    function isDate(d) {
      return objectToString(d) === "[object Date]";
    }
    exports.isDate = isDate;
    function isError(e) {
      return objectToString(e) === "[object Error]" || e instanceof Error;
    }
    exports.isError = isError;
    function isFunction(arg) {
      return typeof arg === "function";
    }
    exports.isFunction = isFunction;
    function isPrimitive(arg) {
      return arg === null || typeof arg === "boolean" || typeof arg === "number" || typeof arg === "string" || typeof arg === "symbol" || // ES6 symbol
      typeof arg === "undefined";
    }
    exports.isPrimitive = isPrimitive;
    exports.isBuffer = Buffer.isBuffer;
    function objectToString(o) {
      return Object.prototype.toString.call(o);
    }
  }
});

// node_modules/verror/lib/verror.js
var require_verror = __commonJS({
  "node_modules/verror/lib/verror.js"(exports, module) {
    var mod_assertplus = require_assert();
    var mod_util = __require("util");
    var mod_extsprintf = require_extsprintf();
    var mod_isError = require_util().isError;
    var sprintf = mod_extsprintf.sprintf;
    module.exports = VError;
    VError.VError = VError;
    VError.SError = SError;
    VError.WError = WError;
    VError.MultiError = MultiError;
    function parseConstructorArguments(args) {
      var argv, options, sprintf_args, shortmessage, k;
      mod_assertplus.object(args, "args");
      mod_assertplus.bool(args.strict, "args.strict");
      mod_assertplus.array(args.argv, "args.argv");
      argv = args.argv;
      if (argv.length === 0) {
        options = {};
        sprintf_args = [];
      } else if (mod_isError(argv[0])) {
        options = { "cause": argv[0] };
        sprintf_args = argv.slice(1);
      } else if (typeof argv[0] === "object") {
        options = {};
        for (k in argv[0]) {
          options[k] = argv[0][k];
        }
        sprintf_args = argv.slice(1);
      } else {
        mod_assertplus.string(
          argv[0],
          "first argument to VError, SError, or WError constructor must be a string, object, or Error"
        );
        options = {};
        sprintf_args = argv;
      }
      mod_assertplus.object(options);
      if (!options.strict && !args.strict) {
        sprintf_args = sprintf_args.map(function(a) {
          return a === null ? "null" : a === void 0 ? "undefined" : a;
        });
      }
      if (sprintf_args.length === 0) {
        shortmessage = "";
      } else {
        shortmessage = sprintf.apply(null, sprintf_args);
      }
      return {
        "options": options,
        "shortmessage": shortmessage
      };
    }
    function VError() {
      var args, obj, parsed, cause, ctor, message, k;
      args = Array.prototype.slice.call(arguments, 0);
      if (!(this instanceof VError)) {
        obj = Object.create(VError.prototype);
        VError.apply(obj, arguments);
        return obj;
      }
      parsed = parseConstructorArguments({
        "argv": args,
        "strict": false
      });
      if (parsed.options.name) {
        mod_assertplus.string(
          parsed.options.name,
          `error's "name" must be a string`
        );
        this.name = parsed.options.name;
      }
      this.jse_shortmsg = parsed.shortmessage;
      message = parsed.shortmessage;
      cause = parsed.options.cause;
      if (cause) {
        mod_assertplus.ok(mod_isError(cause), "cause is not an Error");
        this.jse_cause = cause;
        if (!parsed.options.skipCauseMessage) {
          message += ": " + cause.message;
        }
      }
      this.jse_info = {};
      if (parsed.options.info) {
        for (k in parsed.options.info) {
          this.jse_info[k] = parsed.options.info[k];
        }
      }
      this.message = message;
      Error.call(this, message);
      if (Error.captureStackTrace) {
        ctor = parsed.options.constructorOpt || this.constructor;
        Error.captureStackTrace(this, ctor);
      }
      return this;
    }
    mod_util.inherits(VError, Error);
    VError.prototype.name = "VError";
    VError.prototype.toString = function ve_toString() {
      var str = this.hasOwnProperty("name") && this.name || this.constructor.name || this.constructor.prototype.name;
      if (this.message)
        str += ": " + this.message;
      return str;
    };
    VError.prototype.cause = function ve_cause() {
      var cause = VError.cause(this);
      return cause === null ? void 0 : cause;
    };
    VError.cause = function(err) {
      mod_assertplus.ok(mod_isError(err), "err must be an Error");
      return mod_isError(err.jse_cause) ? err.jse_cause : null;
    };
    VError.info = function(err) {
      var rv, cause, k;
      mod_assertplus.ok(mod_isError(err), "err must be an Error");
      cause = VError.cause(err);
      if (cause !== null) {
        rv = VError.info(cause);
      } else {
        rv = {};
      }
      if (typeof err.jse_info == "object" && err.jse_info !== null) {
        for (k in err.jse_info) {
          rv[k] = err.jse_info[k];
        }
      }
      return rv;
    };
    VError.findCauseByName = function(err, name) {
      var cause;
      mod_assertplus.ok(mod_isError(err), "err must be an Error");
      mod_assertplus.string(name, "name");
      mod_assertplus.ok(name.length > 0, "name cannot be empty");
      for (cause = err; cause !== null; cause = VError.cause(cause)) {
        mod_assertplus.ok(mod_isError(cause));
        if (cause.name == name) {
          return cause;
        }
      }
      return null;
    };
    VError.hasCauseWithName = function(err, name) {
      return VError.findCauseByName(err, name) !== null;
    };
    VError.fullStack = function(err) {
      mod_assertplus.ok(mod_isError(err), "err must be an Error");
      var cause = VError.cause(err);
      if (cause) {
        return err.stack + "\ncaused by: " + VError.fullStack(cause);
      }
      return err.stack;
    };
    VError.errorFromList = function(errors) {
      mod_assertplus.arrayOfObject(errors, "errors");
      if (errors.length === 0) {
        return null;
      }
      errors.forEach(function(e) {
        mod_assertplus.ok(mod_isError(e));
      });
      if (errors.length == 1) {
        return errors[0];
      }
      return new MultiError(errors);
    };
    VError.errorForEach = function(err, func) {
      mod_assertplus.ok(mod_isError(err), "err must be an Error");
      mod_assertplus.func(func, "func");
      if (err instanceof MultiError) {
        err.errors().forEach(function iterError(e) {
          func(e);
        });
      } else {
        func(err);
      }
    };
    function SError() {
      var args, obj, parsed, options;
      args = Array.prototype.slice.call(arguments, 0);
      if (!(this instanceof SError)) {
        obj = Object.create(SError.prototype);
        SError.apply(obj, arguments);
        return obj;
      }
      parsed = parseConstructorArguments({
        "argv": args,
        "strict": true
      });
      options = parsed.options;
      VError.call(this, options, "%s", parsed.shortmessage);
      return this;
    }
    mod_util.inherits(SError, VError);
    function MultiError(errors) {
      mod_assertplus.array(errors, "list of errors");
      mod_assertplus.ok(errors.length > 0, "must be at least one error");
      this.ase_errors = errors;
      VError.call(this, {
        "cause": errors[0]
      }, "first of %d error%s", errors.length, errors.length == 1 ? "" : "s");
    }
    mod_util.inherits(MultiError, VError);
    MultiError.prototype.name = "MultiError";
    MultiError.prototype.errors = function me_errors() {
      return this.ase_errors.slice(0);
    };
    function WError() {
      var args, obj, parsed, options;
      args = Array.prototype.slice.call(arguments, 0);
      if (!(this instanceof WError)) {
        obj = Object.create(WError.prototype);
        WError.apply(obj, args);
        return obj;
      }
      parsed = parseConstructorArguments({
        "argv": args,
        "strict": false
      });
      options = parsed.options;
      options["skipCauseMessage"] = true;
      VError.call(this, options, "%s", parsed.shortmessage);
      return this;
    }
    mod_util.inherits(WError, VError);
    WError.prototype.name = "WError";
    WError.prototype.toString = function we_toString() {
      var str = this.hasOwnProperty("name") && this.name || this.constructor.name || this.constructor.prototype.name;
      if (this.message)
        str += ": " + this.message;
      if (this.jse_cause && this.jse_cause.message)
        str += "; caused by " + this.jse_cause.toString();
      return str;
    };
    WError.prototype.cause = function we_cause(c) {
      if (mod_isError(c))
        this.jse_cause = c;
      return this.jse_cause;
    };
  }
});

// node_modules/json-schema/lib/validate.js
var require_validate = __commonJS({
  "node_modules/json-schema/lib/validate.js"(exports, module) {
    (function(root, factory) {
      if (typeof define === "function" && define.amd) {
        define([], function() {
          return factory();
        });
      } else if (typeof module === "object" && module.exports) {
        module.exports = factory();
      } else {
        root.jsonSchema = factory();
      }
    })(exports, function() {
      var exports2 = validate2;
      exports2.Integer = { type: "integer" };
      var primitiveConstructors = {
        String,
        Boolean,
        Number,
        Object,
        Array,
        Date
      };
      exports2.validate = validate2;
      function validate2(instance, schema) {
        return validate2(instance, schema, { changing: false });
      }
      ;
      exports2.checkPropertyChange = function(value, schema, property) {
        return validate2(value, schema, { changing: property || "property" });
      };
      var validate2 = exports2._validate = function(instance, schema, options) {
        if (!options) options = {};
        var _changing = options.changing;
        function getType(schema2) {
          return schema2.type || primitiveConstructors[schema2.name] == schema2 && schema2.name.toLowerCase();
        }
        var errors = [];
        function checkProp(value, schema2, path, i) {
          var l;
          path += path ? typeof i == "number" ? "[" + i + "]" : typeof i == "undefined" ? "" : "." + i : i;
          function addError(message) {
            errors.push({ property: path, message });
          }
          if ((typeof schema2 != "object" || schema2 instanceof Array) && (path || typeof schema2 != "function") && !(schema2 && getType(schema2))) {
            if (typeof schema2 == "function") {
              if (!(value instanceof schema2)) {
                addError("is not an instance of the class/constructor " + schema2.name);
              }
            } else if (schema2) {
              addError("Invalid schema/property definition " + schema2);
            }
            return null;
          }
          if (_changing && schema2.readonly) {
            addError("is a readonly field, it can not be changed");
          }
          if (schema2["extends"]) {
            checkProp(value, schema2["extends"], path, i);
          }
          function checkType(type, value2) {
            if (type) {
              if (typeof type == "string" && type != "any" && (type == "null" ? value2 !== null : typeof value2 != type) && !(value2 instanceof Array && type == "array") && !(value2 instanceof Date && type == "date") && !(type == "integer" && value2 % 1 === 0)) {
                return [{ property: path, message: value2 + " - " + typeof value2 + " value found, but a " + type + " is required" }];
              }
              if (type instanceof Array) {
                var unionErrors = [];
                for (var j2 = 0; j2 < type.length; j2++) {
                  if (!(unionErrors = checkType(type[j2], value2)).length) {
                    break;
                  }
                }
                if (unionErrors.length) {
                  return unionErrors;
                }
              } else if (typeof type == "object") {
                var priorErrors = errors;
                errors = [];
                checkProp(value2, type, path);
                var theseErrors = errors;
                errors = priorErrors;
                return theseErrors;
              }
            }
            return [];
          }
          if (value === void 0) {
            if (schema2.required) {
              addError("is missing and it is required");
            }
          } else {
            errors = errors.concat(checkType(getType(schema2), value));
            if (schema2.disallow && !checkType(schema2.disallow, value).length) {
              addError(" disallowed value was matched");
            }
            if (value !== null) {
              if (value instanceof Array) {
                if (schema2.items) {
                  var itemsIsArray = schema2.items instanceof Array;
                  var propDef = schema2.items;
                  for (i = 0, l = value.length; i < l; i += 1) {
                    if (itemsIsArray)
                      propDef = schema2.items[i];
                    if (options.coerce)
                      value[i] = options.coerce(value[i], propDef);
                    errors.concat(checkProp(value[i], propDef, path, i));
                  }
                }
                if (schema2.minItems && value.length < schema2.minItems) {
                  addError("There must be a minimum of " + schema2.minItems + " in the array");
                }
                if (schema2.maxItems && value.length > schema2.maxItems) {
                  addError("There must be a maximum of " + schema2.maxItems + " in the array");
                }
              } else if (schema2.properties || schema2.additionalProperties) {
                errors.concat(checkObj(value, schema2.properties, path, schema2.additionalProperties));
              }
              if (schema2.pattern && typeof value == "string" && !value.match(schema2.pattern)) {
                addError("does not match the regex pattern " + schema2.pattern);
              }
              if (schema2.maxLength && typeof value == "string" && value.length > schema2.maxLength) {
                addError("may only be " + schema2.maxLength + " characters long");
              }
              if (schema2.minLength && typeof value == "string" && value.length < schema2.minLength) {
                addError("must be at least " + schema2.minLength + " characters long");
              }
              if (typeof schema2.minimum !== "undefined" && typeof value == typeof schema2.minimum && schema2.minimum > value) {
                addError("must have a minimum value of " + schema2.minimum);
              }
              if (typeof schema2.maximum !== "undefined" && typeof value == typeof schema2.maximum && schema2.maximum < value) {
                addError("must have a maximum value of " + schema2.maximum);
              }
              if (schema2["enum"]) {
                var enumer = schema2["enum"];
                l = enumer.length;
                var found;
                for (var j = 0; j < l; j++) {
                  if (enumer[j] === value) {
                    found = 1;
                    break;
                  }
                }
                if (!found) {
                  addError("does not have a value in the enumeration " + enumer.join(", "));
                }
              }
              if (typeof schema2.maxDecimal == "number" && value.toString().match(new RegExp("\\.[0-9]{" + (schema2.maxDecimal + 1) + ",}"))) {
                addError("may only have " + schema2.maxDecimal + " digits of decimal places");
              }
            }
          }
          return null;
        }
        function checkObj(instance2, objTypeDef, path, additionalProp) {
          if (typeof objTypeDef == "object") {
            if (typeof instance2 != "object" || instance2 instanceof Array) {
              errors.push({ property: path, message: "an object is required" });
            }
            for (var i in objTypeDef) {
              if (objTypeDef.hasOwnProperty(i) && i != "__proto__" && i != "constructor") {
                var value = instance2.hasOwnProperty(i) ? instance2[i] : void 0;
                if (value === void 0 && options.existingOnly) continue;
                var propDef = objTypeDef[i];
                if (value === void 0 && propDef["default"]) {
                  value = instance2[i] = propDef["default"];
                }
                if (options.coerce && i in instance2) {
                  value = instance2[i] = options.coerce(value, propDef);
                }
                checkProp(value, propDef, path, i);
              }
            }
          }
          for (i in instance2) {
            if (instance2.hasOwnProperty(i) && !(i.charAt(0) == "_" && i.charAt(1) == "_") && objTypeDef && !objTypeDef[i] && additionalProp === false) {
              if (options.filter) {
                delete instance2[i];
                continue;
              } else {
                errors.push({ property: path, message: "The property " + i + " is not defined in the schema and the schema does not allow additional properties" });
              }
            }
            var requires = objTypeDef && objTypeDef[i] && objTypeDef[i].requires;
            if (requires && !(requires in instance2)) {
              errors.push({ property: path, message: "the presence of the property " + i + " requires that " + requires + " also be present" });
            }
            value = instance2[i];
            if (additionalProp && (!(objTypeDef && typeof objTypeDef == "object") || !(i in objTypeDef))) {
              if (options.coerce) {
                value = instance2[i] = options.coerce(value, additionalProp);
              }
              checkProp(value, additionalProp, path, i);
            }
            if (!_changing && value && value.$schema) {
              errors = errors.concat(checkProp(value, value.$schema, path, i));
            }
          }
          return errors;
        }
        if (schema) {
          checkProp(instance, schema, "", _changing || "");
        }
        if (!_changing && instance && instance.$schema) {
          checkProp(instance, instance.$schema, "", "");
        }
        return { valid: !errors.length, errors };
      };
      exports2.mustBeValid = function(result) {
        if (!result.valid) {
          throw new TypeError(result.errors.map(function(error) {
            return "for property " + error.property + ": " + error.message;
          }).join(", \n"));
        }
      };
      return exports2;
    });
  }
});

// node_modules/jsprim/lib/jsprim.js
var require_jsprim = __commonJS({
  "node_modules/jsprim/lib/jsprim.js"(exports) {
    var mod_assert = require_assert();
    var mod_util = __require("util");
    var mod_extsprintf = require_extsprintf();
    var mod_verror = require_verror();
    var mod_jsonschema = require_validate();
    exports.deepCopy = deepCopy;
    exports.deepEqual = deepEqual;
    exports.isEmpty = isEmpty;
    exports.hasKey = hasKey;
    exports.forEachKey = forEachKey;
    exports.pluck = pluck;
    exports.flattenObject = flattenObject;
    exports.flattenIter = flattenIter;
    exports.validateJsonObject = validateJsonObjectJS;
    exports.validateJsonObjectJS = validateJsonObjectJS;
    exports.randElt = randElt;
    exports.extraProperties = extraProperties;
    exports.mergeObjects = mergeObjects;
    exports.startsWith = startsWith;
    exports.endsWith = endsWith;
    exports.parseInteger = parseInteger;
    exports.iso8601 = iso8601;
    exports.rfc1123 = rfc1123;
    exports.parseDateTime = parseDateTime;
    exports.hrtimediff = hrtimeDiff;
    exports.hrtimeDiff = hrtimeDiff;
    exports.hrtimeAccum = hrtimeAccum;
    exports.hrtimeAdd = hrtimeAdd;
    exports.hrtimeNanosec = hrtimeNanosec;
    exports.hrtimeMicrosec = hrtimeMicrosec;
    exports.hrtimeMillisec = hrtimeMillisec;
    function deepCopy(obj) {
      var ret, key;
      var marker = "__deepCopy";
      if (obj && obj[marker])
        throw new Error("attempted deep copy of cyclic object");
      if (obj && obj.constructor == Object) {
        ret = {};
        obj[marker] = true;
        for (key in obj) {
          if (key == marker)
            continue;
          ret[key] = deepCopy(obj[key]);
        }
        delete obj[marker];
        return ret;
      }
      if (obj && obj.constructor == Array) {
        ret = [];
        obj[marker] = true;
        for (key = 0; key < obj.length; key++)
          ret.push(deepCopy(obj[key]));
        delete obj[marker];
        return ret;
      }
      return obj;
    }
    function deepEqual(obj1, obj2) {
      if (typeof obj1 != typeof obj2)
        return false;
      if (obj1 === null || obj2 === null || typeof obj1 != "object")
        return obj1 === obj2;
      if (obj1.constructor != obj2.constructor)
        return false;
      var k;
      for (k in obj1) {
        if (!obj2.hasOwnProperty(k))
          return false;
        if (!deepEqual(obj1[k], obj2[k]))
          return false;
      }
      for (k in obj2) {
        if (!obj1.hasOwnProperty(k))
          return false;
      }
      return true;
    }
    function isEmpty(obj) {
      var key;
      for (key in obj)
        return false;
      return true;
    }
    function hasKey(obj, key) {
      mod_assert.equal(typeof key, "string");
      return Object.prototype.hasOwnProperty.call(obj, key);
    }
    function forEachKey(obj, callback) {
      for (var key in obj) {
        if (hasKey(obj, key)) {
          callback(key, obj[key]);
        }
      }
    }
    function pluck(obj, key) {
      mod_assert.equal(typeof key, "string");
      return pluckv(obj, key);
    }
    function pluckv(obj, key) {
      if (obj === null || typeof obj !== "object")
        return void 0;
      if (obj.hasOwnProperty(key))
        return obj[key];
      var i = key.indexOf(".");
      if (i == -1)
        return void 0;
      var key1 = key.substr(0, i);
      if (!obj.hasOwnProperty(key1))
        return void 0;
      return pluckv(obj[key1], key.substr(i + 1));
    }
    function flattenIter(data, depth, callback) {
      doFlattenIter(data, depth, [], callback);
    }
    function doFlattenIter(data, depth, accum, callback) {
      var each;
      var key;
      if (depth === 0) {
        each = accum.slice(0);
        each.push(data);
        callback(each);
        return;
      }
      mod_assert.ok(data !== null);
      mod_assert.equal(typeof data, "object");
      mod_assert.equal(typeof depth, "number");
      mod_assert.ok(depth >= 0);
      for (key in data) {
        each = accum.slice(0);
        each.push(key);
        doFlattenIter(data[key], depth - 1, each, callback);
      }
    }
    function flattenObject(data, depth) {
      if (depth === 0)
        return [data];
      mod_assert.ok(data !== null);
      mod_assert.equal(typeof data, "object");
      mod_assert.equal(typeof depth, "number");
      mod_assert.ok(depth >= 0);
      var rv = [];
      var key;
      for (key in data) {
        flattenObject(data[key], depth - 1).forEach(function(p) {
          rv.push([key].concat(p));
        });
      }
      return rv;
    }
    function startsWith(str, prefix) {
      return str.substr(0, prefix.length) == prefix;
    }
    function endsWith(str, suffix) {
      return str.substr(
        str.length - suffix.length,
        suffix.length
      ) == suffix;
    }
    function iso8601(d) {
      if (typeof d == "number")
        d = new Date(d);
      mod_assert.ok(d.constructor === Date);
      return mod_extsprintf.sprintf(
        "%4d-%02d-%02dT%02d:%02d:%02d.%03dZ",
        d.getUTCFullYear(),
        d.getUTCMonth() + 1,
        d.getUTCDate(),
        d.getUTCHours(),
        d.getUTCMinutes(),
        d.getUTCSeconds(),
        d.getUTCMilliseconds()
      );
    }
    var RFC1123_MONTHS = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec"
    ];
    var RFC1123_DAYS = [
      "Sun",
      "Mon",
      "Tue",
      "Wed",
      "Thu",
      "Fri",
      "Sat"
    ];
    function rfc1123(date) {
      return mod_extsprintf.sprintf(
        "%s, %02d %s %04d %02d:%02d:%02d GMT",
        RFC1123_DAYS[date.getUTCDay()],
        date.getUTCDate(),
        RFC1123_MONTHS[date.getUTCMonth()],
        date.getUTCFullYear(),
        date.getUTCHours(),
        date.getUTCMinutes(),
        date.getUTCSeconds()
      );
    }
    function parseDateTime(str) {
      var numeric = +str;
      if (!isNaN(numeric)) {
        return new Date(numeric);
      } else {
        return new Date(str);
      }
    }
    var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || 9007199254740991;
    var MIN_SAFE_INTEGER = Number.MIN_SAFE_INTEGER || -9007199254740991;
    var PI_DEFAULTS = {
      base: 10,
      allowSign: true,
      allowPrefix: false,
      allowTrailing: false,
      allowImprecise: false,
      trimWhitespace: false,
      leadingZeroIsOctal: false
    };
    var CP_0 = 48;
    var CP_9 = 57;
    var CP_A = 65;
    var CP_B = 66;
    var CP_O = 79;
    var CP_T = 84;
    var CP_X = 88;
    var CP_Z = 90;
    var CP_a = 97;
    var CP_b = 98;
    var CP_o = 111;
    var CP_t = 116;
    var CP_x = 120;
    var CP_z = 122;
    var PI_CONV_DEC = 48;
    var PI_CONV_UC = 55;
    var PI_CONV_LC = 87;
    function parseInteger(str, uopts) {
      mod_assert.string(str, "str");
      mod_assert.optionalObject(uopts, "options");
      var baseOverride = false;
      var options = PI_DEFAULTS;
      if (uopts) {
        baseOverride = hasKey(uopts, "base");
        options = mergeObjects(options, uopts);
        mod_assert.number(options.base, "options.base");
        mod_assert.ok(options.base >= 2, "options.base >= 2");
        mod_assert.ok(options.base <= 36, "options.base <= 36");
        mod_assert.bool(options.allowSign, "options.allowSign");
        mod_assert.bool(options.allowPrefix, "options.allowPrefix");
        mod_assert.bool(
          options.allowTrailing,
          "options.allowTrailing"
        );
        mod_assert.bool(
          options.allowImprecise,
          "options.allowImprecise"
        );
        mod_assert.bool(
          options.trimWhitespace,
          "options.trimWhitespace"
        );
        mod_assert.bool(
          options.leadingZeroIsOctal,
          "options.leadingZeroIsOctal"
        );
        if (options.leadingZeroIsOctal) {
          mod_assert.ok(
            !baseOverride,
            '"base" and "leadingZeroIsOctal" are mutually exclusive'
          );
        }
      }
      var c;
      var pbase = -1;
      var base = options.base;
      var start;
      var mult = 1;
      var value = 0;
      var idx = 0;
      var len = str.length;
      if (options.trimWhitespace) {
        while (idx < len && isSpace(str.charCodeAt(idx))) {
          ++idx;
        }
      }
      if (options.allowSign) {
        if (str[idx] === "-") {
          idx += 1;
          mult = -1;
        } else if (str[idx] === "+") {
          idx += 1;
        }
      }
      if (str[idx] === "0") {
        if (options.allowPrefix) {
          pbase = prefixToBase(str.charCodeAt(idx + 1));
          if (pbase !== -1 && (!baseOverride || pbase === base)) {
            base = pbase;
            idx += 2;
          }
        }
        if (pbase === -1 && options.leadingZeroIsOctal) {
          base = 8;
        }
      }
      for (start = idx; idx < len; ++idx) {
        c = translateDigit(str.charCodeAt(idx));
        if (c !== -1 && c < base) {
          value *= base;
          value += c;
        } else {
          break;
        }
      }
      if (start === idx) {
        return new Error("invalid number: " + JSON.stringify(str));
      }
      if (options.trimWhitespace) {
        while (idx < len && isSpace(str.charCodeAt(idx))) {
          ++idx;
        }
      }
      if (idx < len && !options.allowTrailing) {
        return new Error("trailing characters after number: " + JSON.stringify(str.slice(idx)));
      }
      if (value === 0) {
        return 0;
      }
      var result = value * mult;
      if (!options.allowImprecise && (value > MAX_SAFE_INTEGER || result < MIN_SAFE_INTEGER)) {
        return new Error("number is outside of the supported range: " + JSON.stringify(str.slice(start, idx)));
      }
      return result;
    }
    function translateDigit(d) {
      if (d >= CP_0 && d <= CP_9) {
        return d - PI_CONV_DEC;
      } else if (d >= CP_A && d <= CP_Z) {
        return d - PI_CONV_UC;
      } else if (d >= CP_a && d <= CP_z) {
        return d - PI_CONV_LC;
      } else {
        return -1;
      }
    }
    function isSpace(c) {
      return c === 32 || c >= 9 && c <= 13 || c === 160 || c === 5760 || c === 6158 || c >= 8192 && c <= 8202 || c === 8232 || c === 8233 || c === 8239 || c === 8287 || c === 12288 || c === 65279;
    }
    function prefixToBase(c) {
      if (c === CP_b || c === CP_B) {
        return 2;
      } else if (c === CP_o || c === CP_O) {
        return 8;
      } else if (c === CP_t || c === CP_T) {
        return 10;
      } else if (c === CP_x || c === CP_X) {
        return 16;
      } else {
        return -1;
      }
    }
    function validateJsonObjectJS(schema, input) {
      var report = mod_jsonschema.validate(input, schema);
      if (report.errors.length === 0)
        return null;
      var error = report.errors[0];
      var propname = error["property"];
      var reason = error["message"].toLowerCase();
      var i, j;
      if ((i = reason.indexOf("the property ")) != -1 && (j = reason.indexOf(" is not defined in the schema and the schema does not allow additional properties")) != -1) {
        i += "the property ".length;
        if (propname === "")
          propname = reason.substr(i, j - i);
        else
          propname = propname + "." + reason.substr(i, j - i);
        reason = "unsupported property";
      }
      var rv = new mod_verror.VError('property "%s": %s', propname, reason);
      rv.jsv_details = error;
      return rv;
    }
    function randElt(arr) {
      mod_assert.ok(
        Array.isArray(arr) && arr.length > 0,
        "randElt argument must be a non-empty array"
      );
      return arr[Math.floor(Math.random() * arr.length)];
    }
    function assertHrtime(a) {
      mod_assert.ok(
        a[0] >= 0 && a[1] >= 0,
        "negative numbers not allowed in hrtimes"
      );
      mod_assert.ok(a[1] < 1e9, "nanoseconds column overflow");
    }
    function hrtimeDiff(a, b) {
      assertHrtime(a);
      assertHrtime(b);
      mod_assert.ok(
        a[0] > b[0] || a[0] == b[0] && a[1] >= b[1],
        "negative differences not allowed"
      );
      var rv = [a[0] - b[0], 0];
      if (a[1] >= b[1]) {
        rv[1] = a[1] - b[1];
      } else {
        rv[0]--;
        rv[1] = 1e9 - (b[1] - a[1]);
      }
      return rv;
    }
    function hrtimeNanosec(a) {
      assertHrtime(a);
      return Math.floor(a[0] * 1e9 + a[1]);
    }
    function hrtimeMicrosec(a) {
      assertHrtime(a);
      return Math.floor(a[0] * 1e6 + a[1] / 1e3);
    }
    function hrtimeMillisec(a) {
      assertHrtime(a);
      return Math.floor(a[0] * 1e3 + a[1] / 1e6);
    }
    function hrtimeAccum(a, b) {
      assertHrtime(a);
      assertHrtime(b);
      a[1] += b[1];
      if (a[1] >= 1e9) {
        a[0]++;
        a[1] -= 1e9;
      }
      a[0] += b[0];
      return a;
    }
    function hrtimeAdd(a, b) {
      assertHrtime(a);
      var rv = [a[0], a[1]];
      return hrtimeAccum(rv, b);
    }
    function extraProperties(obj, allowed) {
      mod_assert.ok(
        typeof obj === "object" && obj !== null,
        "obj argument must be a non-null object"
      );
      mod_assert.ok(
        Array.isArray(allowed),
        "allowed argument must be an array of strings"
      );
      for (var i = 0; i < allowed.length; i++) {
        mod_assert.ok(
          typeof allowed[i] === "string",
          "allowed argument must be an array of strings"
        );
      }
      return Object.keys(obj).filter(function(key) {
        return allowed.indexOf(key) === -1;
      });
    }
    function mergeObjects(provided, overrides, defaults) {
      var rv, k;
      rv = {};
      if (defaults) {
        for (k in defaults)
          rv[k] = defaults[k];
      }
      if (provided) {
        for (k in provided)
          rv[k] = provided[k];
      }
      if (overrides) {
        for (k in overrides)
          rv[k] = overrides[k];
      }
      return rv;
    }
  }
});

// node_modules/macaddr/lib/macaddr.js
var require_macaddr = __commonJS({
  "node_modules/macaddr/lib/macaddr.js"(exports, module) {
    "use strict";
    var assert = require_assert();
    var mod_jsprim = require_jsprim();
    var HEX_RE = /^[a-f0-9]$/;
    function isxdigit(c) {
      return HEX_RE.test(c);
    }
    function toHexString(octet) {
      return octet.toString(16);
    }
    var strDefaults = {
      zeroPad: true,
      // Pad with zeros when an octet would print as 1 char
      separator: ":",
      octetFormatter: toHexString
    };
    function getStrOpt(opts, name) {
      if (opts && opts.hasOwnProperty(name)) {
        return opts[name];
      } else {
        return strDefaults[name];
      }
    }
    function MAC(value) {
      assert.number(value, "value");
      this._value = value;
    }
    MAC.prototype.toString = function toString(opts) {
      assert.optionalObject(opts, "opts");
      var zeroPad = getStrOpt(opts, "zeroPad");
      var separator = getStrOpt(opts, "separator");
      var formatter = getStrOpt(opts, "octetFormatter");
      var result = "";
      var fields = [
        /*
         * JavaScript converts numbers to 32-bit integers when doing bitwise
         * arithmetic, so we have to handle the first two parts of the number
         * differently.
         */
        this._value / 1099511627776 & 255,
        this._value / 4294967296 & 255,
        this._value >>> 24 & 255,
        this._value >>> 16 & 255,
        this._value >>> 8 & 255,
        this._value & 255
      ];
      var octet;
      for (var i = 0; i < fields.length; i++) {
        if (i !== 0) {
          result += separator;
        }
        octet = formatter.call(null, fields[i]);
        if (zeroPad && octet.length === 1) {
          result += "0";
        }
        result += octet;
      }
      return result;
    };
    MAC.prototype.toLong = function toLong() {
      return this._value;
    };
    MAC.prototype.compare = function compare(other) {
      assert.ok(other instanceof MAC, "other is a MAC object");
      if (this._value < other._value) {
        return -1;
      } else if (this._value > other._value) {
        return 1;
      } else {
        return 0;
      }
    };
    function parseString(input) {
      assert.string(input);
      input = input.toLowerCase();
      var pos = 0;
      var value = 0;
      var octet = "";
      var sep = null;
      var chr, tmp;
      function issep(s) {
        if (sep !== null) {
          return s === sep;
        }
        if (s === ":" || s === "-") {
          sep = s;
          return true;
        }
        return false;
      }
      function process2() {
        if (octet.length === 0) {
          throw new Error("expected to find a hexadecimal number before " + JSON.stringify(sep));
        } else if (octet.length > 2) {
          throw new Error(
            "too many hexadecimal digits in " + JSON.stringify(octet)
          );
        } else if (pos < 6) {
          tmp = mod_jsprim.parseInteger(octet, { base: 16 });
          if (tmp instanceof Error) {
            throw tmp;
          }
          value *= 256;
          value += tmp;
          pos += 1;
          octet = "";
        } else {
          throw new Error("too many octets in MAC address");
        }
      }
      for (var i = 0; i < input.length; i++) {
        chr = input[i];
        if (issep(chr)) {
          process2();
        } else if (isxdigit(chr)) {
          octet += chr;
        } else {
          throw new Error("unrecognized character " + JSON.stringify(chr));
        }
      }
      if (issep(chr)) {
        throw new Error("trailing " + JSON.stringify(sep) + " in MAC address");
      }
      if (pos === 0) {
        if (octet.length !== 12) {
          throw new Error("MAC address is too short");
        }
        value = mod_jsprim.parseInteger(octet, { base: 16 });
        if (value instanceof Error) {
          throw value;
        }
      } else {
        process2();
        if (pos !== 6) {
          throw new Error("too few octets in MAC address");
        }
      }
      return new MAC(value);
    }
    function parseLong(input) {
      assert.number(input);
      if (input !== Math.floor(input)) {
        throw new Error("Value must be an integer");
      }
      if (input < 0 || input > 281474976710655) {
        throw new Error("Value must be 48-bit");
      }
      return new MAC(input);
    }
    function macaddrParse(input) {
      var type = typeof input;
      switch (type) {
        case "string":
          return parseString(input);
        case "number":
          return parseLong(input);
        default:
          throw new Error("expected string or integer, but got " + type);
      }
    }
    module.exports = {
      parse: macaddrParse
    };
  }
});

// node_modules/@network-utils/arp-lookup/dist/index.js
var require_dist = __commonJS({
  "node_modules/@network-utils/arp-lookup/dist/index.js"(exports) {
    "use strict";
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getType = exports.isType = exports.fromPrefix = exports.toIP = exports.toMAC = exports.getTable = exports.isPrefix = exports.isMAC = void 0;
    var child_process_1 = __require("child_process");
    var net_1 = __require("net");
    var normalize = (mac) => mac.replace(/-/g, ":").toLowerCase();
    var fixMAC = (mac) => normalize(mac).split(":").map((part) => part.length === 1 ? "0" + part : part).join(":");
    var isMAC = (mac) => /^([0-9A-F]{2}[:-]){5}([0-9A-F]{2})$/i.test(mac);
    exports.isMAC = isMAC;
    var isPrefix = (prefix) => /^([0-9A-F]{2}[:-]){2}([0-9A-F]{2})$/i.test(prefix);
    exports.isPrefix = isPrefix;
    function getTable() {
      return new Promise((resolve, reject) => {
        const isWindows = process.platform.substring(0, 3) === "win";
        const command = isWindows ? "arp -a" : "arp -an";
        (0, child_process_1.exec)(command, (err, rawArpData) => {
          if (err) {
            reject(err);
            return;
          }
          const rows = rawArpData.split("\n");
          const table = [];
          for (const row of rows) {
            let ip;
            let mac;
            let type;
            if (isWindows) {
              ;
              [ip, mac, type] = row.trim().replace(/\s+/g, " ").split(" ");
            } else {
              const match = /.*\((.*?)\) \w+ (.{0,17}) (?:\[ether]|on)/g.exec(row);
              if (match && match.length === 3) {
                ip = match[1];
                mac = fixMAC(match[2]);
                type = "unknown";
              } else {
                continue;
              }
            }
            if (!(0, net_1.isIP)(ip) || !(0, exports.isMAC)(mac))
              continue;
            table.push({
              ip,
              mac: normalize(mac),
              type
            });
          }
          resolve(table);
        });
      });
    }
    exports.getTable = getTable;
    function toMAC(ip) {
      return __awaiter(this, void 0, void 0, function* () {
        if (!(0, net_1.isIP)(ip))
          throw Error("Invalid IP");
        const arpTable = yield getTable();
        const match = arpTable.find((row) => row.ip === ip);
        return match ? match.mac : null;
      });
    }
    exports.toMAC = toMAC;
    function toIP(mac) {
      return __awaiter(this, void 0, void 0, function* () {
        if (!(0, exports.isMAC)(mac))
          throw Error("Invalid MAC");
        mac = normalize(mac);
        const arpTable = yield getTable();
        const match = arpTable.find((row) => row.mac === mac);
        return match ? match.ip : null;
      });
    }
    exports.toIP = toIP;
    function fromPrefix(prefix) {
      return __awaiter(this, void 0, void 0, function* () {
        if (!(0, exports.isPrefix)(prefix))
          throw Error("Invalid Prefix");
        const table = yield getTable();
        return table.filter((row) => row.mac.startsWith(prefix));
      });
    }
    exports.fromPrefix = fromPrefix;
    function isType(type, address) {
      return __awaiter(this, void 0, void 0, function* () {
        if (process.platform === "darwin" && type !== "unknown" && process.env.NODE_ENV !== "production")
          console.warn('[arp-lookup] `isType` will always return `false` for types other than "unknown" on darwin systems');
        return type === (yield getType(address));
      });
    }
    exports.isType = isType;
    function getType(address) {
      var _a, _b;
      return __awaiter(this, void 0, void 0, function* () {
        if (!(0, net_1.isIP)(address) && !(0, exports.isMAC)(address))
          throw Error("Invalid address");
        if (process.platform === "darwin" && process.env.NODE_ENV !== "production")
          console.warn('[arp-lookup] `getType` will always return "unknown" on darwin systems');
        if ((0, exports.isMAC)(address))
          address = normalize(address);
        const recordedType = (_b = (_a = (yield getTable()).find((row) => row.ip === address || row.mac === address)) === null || _a === void 0 ? void 0 : _a.type) !== null && _b !== void 0 ? _b : "undefined";
        return recordedType;
      });
    }
    exports.getType = getType;
    exports.default = {
      fromPrefix,
      getTable,
      getType,
      isType,
      isIP: net_1.isIP,
      isMAC: exports.isMAC,
      isPrefix: exports.isPrefix,
      toIP,
      toMAC
    };
  }
});

// node_modules/ip/lib/ip.js
var require_ip = __commonJS({
  "node_modules/ip/lib/ip.js"(exports) {
    var ip = exports;
    var { Buffer: Buffer2 } = __require("buffer");
    var os = __require("os");
    ip.toBuffer = function(ip2, buff, offset) {
      offset = ~~offset;
      var result;
      if (this.isV4Format(ip2)) {
        result = buff || new Buffer2(offset + 4);
        ip2.split(/\./g).map((byte) => {
          result[offset++] = parseInt(byte, 10) & 255;
        });
      } else if (this.isV6Format(ip2)) {
        var sections = ip2.split(":", 8);
        var i;
        for (i = 0; i < sections.length; i++) {
          var isv4 = this.isV4Format(sections[i]);
          var v4Buffer;
          if (isv4) {
            v4Buffer = this.toBuffer(sections[i]);
            sections[i] = v4Buffer.slice(0, 2).toString("hex");
          }
          if (v4Buffer && ++i < 8) {
            sections.splice(i, 0, v4Buffer.slice(2, 4).toString("hex"));
          }
        }
        if (sections[0] === "") {
          while (sections.length < 8) sections.unshift("0");
        } else if (sections[sections.length - 1] === "") {
          while (sections.length < 8) sections.push("0");
        } else if (sections.length < 8) {
          for (i = 0; i < sections.length && sections[i] !== ""; i++) ;
          var argv = [i, 1];
          for (i = 9 - sections.length; i > 0; i--) {
            argv.push("0");
          }
          sections.splice.apply(sections, argv);
        }
        result = buff || new Buffer2(offset + 16);
        for (i = 0; i < sections.length; i++) {
          var word = parseInt(sections[i], 16);
          result[offset++] = word >> 8 & 255;
          result[offset++] = word & 255;
        }
      }
      if (!result) {
        throw Error(`Invalid ip address: ${ip2}`);
      }
      return result;
    };
    ip.toString = function(buff, offset, length) {
      offset = ~~offset;
      length = length || buff.length - offset;
      var result = [];
      var i;
      if (length === 4) {
        for (i = 0; i < length; i++) {
          result.push(buff[offset + i]);
        }
        result = result.join(".");
      } else if (length === 16) {
        for (i = 0; i < length; i += 2) {
          result.push(buff.readUInt16BE(offset + i).toString(16));
        }
        result = result.join(":");
        result = result.replace(/(^|:)0(:0)*:0(:|$)/, "$1::$3");
        result = result.replace(/:{3,4}/, "::");
      }
      return result;
    };
    var ipv4Regex = /^(\d{1,3}\.){3,3}\d{1,3}$/;
    var ipv6Regex = /^(::)?(((\d{1,3}\.){3}(\d{1,3}){1})?([0-9a-f]){0,4}:{0,2}){1,8}(::)?$/i;
    ip.isV4Format = function(ip2) {
      return ipv4Regex.test(ip2);
    };
    ip.isV6Format = function(ip2) {
      return ipv6Regex.test(ip2);
    };
    function _normalizeFamily(family) {
      if (family === 4) {
        return "ipv4";
      }
      if (family === 6) {
        return "ipv6";
      }
      return family ? family.toLowerCase() : "ipv4";
    }
    ip.fromPrefixLen = function(prefixlen, family) {
      if (prefixlen > 32) {
        family = "ipv6";
      } else {
        family = _normalizeFamily(family);
      }
      var len = 4;
      if (family === "ipv6") {
        len = 16;
      }
      var buff = new Buffer2(len);
      for (var i = 0, n = buff.length; i < n; ++i) {
        var bits = 8;
        if (prefixlen < 8) {
          bits = prefixlen;
        }
        prefixlen -= bits;
        buff[i] = ~(255 >> bits) & 255;
      }
      return ip.toString(buff);
    };
    ip.mask = function(addr, mask) {
      addr = ip.toBuffer(addr);
      mask = ip.toBuffer(mask);
      var result = new Buffer2(Math.max(addr.length, mask.length));
      var i;
      if (addr.length === mask.length) {
        for (i = 0; i < addr.length; i++) {
          result[i] = addr[i] & mask[i];
        }
      } else if (mask.length === 4) {
        for (i = 0; i < mask.length; i++) {
          result[i] = addr[addr.length - 4 + i] & mask[i];
        }
      } else {
        for (i = 0; i < result.length - 6; i++) {
          result[i] = 0;
        }
        result[10] = 255;
        result[11] = 255;
        for (i = 0; i < addr.length; i++) {
          result[i + 12] = addr[i] & mask[i + 12];
        }
        i += 12;
      }
      for (; i < result.length; i++) {
        result[i] = 0;
      }
      return ip.toString(result);
    };
    ip.cidr = function(cidrString) {
      var cidrParts = cidrString.split("/");
      var addr = cidrParts[0];
      if (cidrParts.length !== 2) {
        throw new Error(`invalid CIDR subnet: ${addr}`);
      }
      var mask = ip.fromPrefixLen(parseInt(cidrParts[1], 10));
      return ip.mask(addr, mask);
    };
    ip.subnet = function(addr, mask) {
      var networkAddress = ip.toLong(ip.mask(addr, mask));
      var maskBuffer = ip.toBuffer(mask);
      var maskLength = 0;
      for (var i = 0; i < maskBuffer.length; i++) {
        if (maskBuffer[i] === 255) {
          maskLength += 8;
        } else {
          var octet = maskBuffer[i] & 255;
          while (octet) {
            octet = octet << 1 & 255;
            maskLength++;
          }
        }
      }
      var numberOfAddresses = Math.pow(2, 32 - maskLength);
      return {
        networkAddress: ip.fromLong(networkAddress),
        firstAddress: numberOfAddresses <= 2 ? ip.fromLong(networkAddress) : ip.fromLong(networkAddress + 1),
        lastAddress: numberOfAddresses <= 2 ? ip.fromLong(networkAddress + numberOfAddresses - 1) : ip.fromLong(networkAddress + numberOfAddresses - 2),
        broadcastAddress: ip.fromLong(networkAddress + numberOfAddresses - 1),
        subnetMask: mask,
        subnetMaskLength: maskLength,
        numHosts: numberOfAddresses <= 2 ? numberOfAddresses : numberOfAddresses - 2,
        length: numberOfAddresses,
        contains(other) {
          return networkAddress === ip.toLong(ip.mask(other, mask));
        }
      };
    };
    ip.cidrSubnet = function(cidrString) {
      var cidrParts = cidrString.split("/");
      var addr = cidrParts[0];
      if (cidrParts.length !== 2) {
        throw new Error(`invalid CIDR subnet: ${addr}`);
      }
      var mask = ip.fromPrefixLen(parseInt(cidrParts[1], 10));
      return ip.subnet(addr, mask);
    };
    ip.not = function(addr) {
      var buff = ip.toBuffer(addr);
      for (var i = 0; i < buff.length; i++) {
        buff[i] = 255 ^ buff[i];
      }
      return ip.toString(buff);
    };
    ip.or = function(a, b) {
      var i;
      a = ip.toBuffer(a);
      b = ip.toBuffer(b);
      if (a.length === b.length) {
        for (i = 0; i < a.length; ++i) {
          a[i] |= b[i];
        }
        return ip.toString(a);
      }
      var buff = a;
      var other = b;
      if (b.length > a.length) {
        buff = b;
        other = a;
      }
      var offset = buff.length - other.length;
      for (i = offset; i < buff.length; ++i) {
        buff[i] |= other[i - offset];
      }
      return ip.toString(buff);
    };
    ip.isEqual = function(a, b) {
      var i;
      a = ip.toBuffer(a);
      b = ip.toBuffer(b);
      if (a.length === b.length) {
        for (i = 0; i < a.length; i++) {
          if (a[i] !== b[i]) return false;
        }
        return true;
      }
      if (b.length === 4) {
        var t = b;
        b = a;
        a = t;
      }
      for (i = 0; i < 10; i++) {
        if (b[i] !== 0) return false;
      }
      var word = b.readUInt16BE(10);
      if (word !== 0 && word !== 65535) return false;
      for (i = 0; i < 4; i++) {
        if (a[i] !== b[i + 12]) return false;
      }
      return true;
    };
    ip.isPrivate = function(addr) {
      if (ip.isLoopback(addr)) {
        return true;
      }
      if (!ip.isV6Format(addr)) {
        const ipl = ip.normalizeToLong(addr);
        if (ipl < 0) {
          throw new Error("invalid ipv4 address");
        }
        addr = ip.fromLong(ipl);
      }
      return /^(::f{4}:)?10\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})$/i.test(addr) || /^(::f{4}:)?192\.168\.([0-9]{1,3})\.([0-9]{1,3})$/i.test(addr) || /^(::f{4}:)?172\.(1[6-9]|2\d|30|31)\.([0-9]{1,3})\.([0-9]{1,3})$/i.test(addr) || /^(::f{4}:)?169\.254\.([0-9]{1,3})\.([0-9]{1,3})$/i.test(addr) || /^f[cd][0-9a-f]{2}:/i.test(addr) || /^fe80:/i.test(addr) || /^::1$/.test(addr) || /^::$/.test(addr);
    };
    ip.isPublic = function(addr) {
      return !ip.isPrivate(addr);
    };
    ip.isLoopback = function(addr) {
      if (!/\./.test(addr) && !/:/.test(addr)) {
        addr = ip.fromLong(Number(addr));
      }
      return /^(::f{4}:)?127\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})/.test(addr) || /^0177\./.test(addr) || /^0x7f\./i.test(addr) || /^fe80::1$/i.test(addr) || /^::1$/.test(addr) || /^::$/.test(addr);
    };
    ip.loopback = function(family) {
      family = _normalizeFamily(family);
      if (family !== "ipv4" && family !== "ipv6") {
        throw new Error("family must be ipv4 or ipv6");
      }
      return family === "ipv4" ? "127.0.0.1" : "fe80::1";
    };
    ip.address = function(name, family) {
      var interfaces = os.networkInterfaces();
      family = _normalizeFamily(family);
      if (name && name !== "private" && name !== "public") {
        var res = interfaces[name].filter((details) => {
          var itemFamily = _normalizeFamily(details.family);
          return itemFamily === family;
        });
        if (res.length === 0) {
          return void 0;
        }
        return res[0].address;
      }
      var all = Object.keys(interfaces).map((nic) => {
        var addresses = interfaces[nic].filter((details) => {
          details.family = _normalizeFamily(details.family);
          if (details.family !== family || ip.isLoopback(details.address)) {
            return false;
          }
          if (!name) {
            return true;
          }
          return name === "public" ? ip.isPrivate(details.address) : ip.isPublic(details.address);
        });
        return addresses.length ? addresses[0].address : void 0;
      }).filter(Boolean);
      return !all.length ? ip.loopback(family) : all[0];
    };
    ip.toLong = function(ip2) {
      var ipl = 0;
      ip2.split(".").forEach((octet) => {
        ipl <<= 8;
        ipl += parseInt(octet);
      });
      return ipl >>> 0;
    };
    ip.fromLong = function(ipl) {
      return `${ipl >>> 24}.${ipl >> 16 & 255}.${ipl >> 8 & 255}.${ipl & 255}`;
    };
    ip.normalizeToLong = function(addr) {
      const parts = addr.split(".").map((part) => {
        if (part.startsWith("0x") || part.startsWith("0X")) {
          return parseInt(part, 16);
        } else if (part.startsWith("0") && part !== "0" && /^[0-7]+$/.test(part)) {
          return parseInt(part, 8);
        } else if (/^[1-9]\d*$/.test(part) || part === "0") {
          return parseInt(part, 10);
        } else {
          return NaN;
        }
      });
      if (parts.some(isNaN)) return -1;
      let val = 0;
      const n = parts.length;
      switch (n) {
        case 1:
          val = parts[0];
          break;
        case 2:
          if (parts[0] > 255 || parts[1] > 16777215) return -1;
          val = parts[0] << 24 | parts[1] & 16777215;
          break;
        case 3:
          if (parts[0] > 255 || parts[1] > 255 || parts[2] > 65535) return -1;
          val = parts[0] << 24 | parts[1] << 16 | parts[2] & 65535;
          break;
        case 4:
          if (parts.some((part) => part > 255)) return -1;
          val = parts[0] << 24 | parts[1] << 16 | parts[2] << 8 | parts[3];
          break;
        default:
          return -1;
      }
      return val >>> 0;
    };
  }
});

// node_modules/any-promise/loader.js
var require_loader = __commonJS({
  "node_modules/any-promise/loader.js"(exports, module) {
    "use strict";
    var REGISTRATION_KEY = "@@any-promise/REGISTRATION";
    var registered = null;
    module.exports = function(root, loadImplementation) {
      return function register(implementation, opts) {
        implementation = implementation || null;
        opts = opts || {};
        var registerGlobal = opts.global !== false;
        if (registered === null && registerGlobal) {
          registered = root[REGISTRATION_KEY] || null;
        }
        if (registered !== null && implementation !== null && registered.implementation !== implementation) {
          throw new Error('any-promise already defined as "' + registered.implementation + '".  You can only register an implementation before the first  call to require("any-promise") and an implementation cannot be changed');
        }
        if (registered === null) {
          if (implementation !== null && typeof opts.Promise !== "undefined") {
            registered = {
              Promise: opts.Promise,
              implementation
            };
          } else {
            registered = loadImplementation(implementation);
          }
          if (registerGlobal) {
            root[REGISTRATION_KEY] = registered;
          }
        }
        return registered;
      };
    };
  }
});

// node_modules/any-promise/register.js
var require_register = __commonJS({
  "node_modules/any-promise/register.js"(exports, module) {
    "use strict";
    module.exports = require_loader()(global, loadImplementation);
    function loadImplementation(implementation) {
      var impl = null;
      if (shouldPreferGlobalPromise(implementation)) {
        impl = {
          Promise: global.Promise,
          implementation: "global.Promise"
        };
      } else if (implementation) {
        var lib = __require(implementation);
        impl = {
          Promise: lib.Promise || lib,
          implementation
        };
      } else {
        impl = tryAutoDetect();
      }
      if (impl === null) {
        throw new Error('Cannot find any-promise implementation nor global.Promise. You must install polyfill or call require("any-promise/register") with your preferred implementation, e.g. require("any-promise/register/bluebird") on application load prior to any require("any-promise").');
      }
      return impl;
    }
    function shouldPreferGlobalPromise(implementation) {
      if (implementation) {
        return implementation === "global.Promise";
      } else if (typeof global.Promise !== "undefined") {
        var version2 = /v(\d+)\.(\d+)\.(\d+)/.exec(process.version);
        return !(version2 && +version2[1] == 0 && +version2[2] < 12);
      }
      return false;
    }
    function tryAutoDetect() {
      var libs = [
        "es6-promise",
        "promise",
        "native-promise-only",
        "bluebird",
        "rsvp",
        "when",
        "q",
        "pinkie",
        "lie",
        "vow"
      ];
      var i = 0, len = libs.length;
      for (; i < len; i++) {
        try {
          return loadImplementation(libs[i]);
        } catch (e) {
        }
      }
      return null;
    }
  }
});

// node_modules/any-promise/index.js
var require_any_promise = __commonJS({
  "node_modules/any-promise/index.js"(exports, module) {
    module.exports = require_register()().Promise;
  }
});

// node_modules/thenify/index.js
var require_thenify = __commonJS({
  "node_modules/thenify/index.js"(exports, module) {
    var Promise2 = require_any_promise();
    var assert = __require("assert");
    module.exports = thenify;
    function thenify(fn, options) {
      assert(typeof fn === "function");
      return createWrapper(fn, options);
    }
    thenify.withCallback = function(fn, options) {
      assert(typeof fn === "function");
      options = options || {};
      options.withCallback = true;
      return createWrapper(fn, options);
    };
    function createCallback(resolve, reject, multiArgs) {
      if (multiArgs === void 0) multiArgs = true;
      return function(err, value) {
        if (err) return reject(err);
        var length = arguments.length;
        if (length <= 2 || !multiArgs) return resolve(value);
        if (Array.isArray(multiArgs)) {
          var values = {};
          for (var i = 1; i < length; i++) values[multiArgs[i - 1]] = arguments[i];
          return resolve(values);
        }
        var values = new Array(length - 1);
        for (var i = 1; i < length; ++i) values[i - 1] = arguments[i];
        resolve(values);
      };
    }
    function createWrapper(fn, options) {
      options = options || {};
      var name = fn.name;
      name = (name || "").replace(/\s|bound(?!$)/g, "");
      var newFn = function() {
        var self2 = this;
        var len = arguments.length;
        if (options.withCallback) {
          var lastType = typeof arguments[len - 1];
          if (lastType === "function") return fn.apply(self2, arguments);
        }
        var args = new Array(len + 1);
        for (var i = 0; i < len; ++i) args[i] = arguments[i];
        var lastIndex = i;
        return new Promise2(function(resolve, reject) {
          args[lastIndex] = createCallback(resolve, reject, options.multiArgs);
          fn.apply(self2, args);
        });
      };
      Object.defineProperty(newFn, "name", { value: name });
      return newFn;
    }
  }
});

// node_modules/thenify-all/index.js
var require_thenify_all = __commonJS({
  "node_modules/thenify-all/index.js"(exports, module) {
    var thenify = require_thenify();
    module.exports = thenifyAll;
    thenifyAll.withCallback = withCallback;
    thenifyAll.thenify = thenify;
    function thenifyAll(source, destination, methods) {
      return promisifyAll(source, destination, methods, thenify);
    }
    function withCallback(source, destination, methods) {
      return promisifyAll(source, destination, methods, thenify.withCallback);
    }
    function promisifyAll(source, destination, methods, promisify) {
      if (!destination) {
        destination = {};
        methods = Object.keys(source);
      }
      if (Array.isArray(destination)) {
        methods = destination;
        destination = {};
      }
      if (!methods) {
        methods = Object.keys(source);
      }
      if (typeof source === "function") destination = promisify(source);
      methods.forEach(function(name) {
        if (typeof source[name] === "function") destination[name] = promisify(source[name]);
      });
      Object.keys(source).forEach(function(name) {
        if (deprecated(source, name)) return;
        if (destination[name]) return;
        destination[name] = source[name];
      });
      return destination;
    }
    function deprecated(source, name) {
      var desc = Object.getOwnPropertyDescriptor(source, name);
      if (!desc || !desc.get) return false;
      if (desc.get.name === "deprecated") return true;
      return false;
    }
  }
});

// node_modules/mz/child_process.js
var require_child_process = __commonJS({
  "node_modules/mz/child_process.js"(exports) {
    require_thenify_all().withCallback(
      __require("child_process"),
      exports,
      [
        "exec",
        "execFile"
      ]
    );
  }
});

// node_modules/jsbn/index.js
var require_jsbn = __commonJS({
  "node_modules/jsbn/index.js"(exports, module) {
    (function() {
      var dbits;
      var canary = 244837814094590;
      var j_lm = (canary & 16777215) == 15715070;
      function BigInteger(a, b, c) {
        if (a != null)
          if ("number" == typeof a) this.fromNumber(a, b, c);
          else if (b == null && "string" != typeof a) this.fromString(a, 256);
          else this.fromString(a, b);
      }
      function nbi() {
        return new BigInteger(null);
      }
      function am1(i, x, w, j, c, n) {
        while (--n >= 0) {
          var v = x * this[i++] + w[j] + c;
          c = Math.floor(v / 67108864);
          w[j++] = v & 67108863;
        }
        return c;
      }
      function am2(i, x, w, j, c, n) {
        var xl = x & 32767, xh = x >> 15;
        while (--n >= 0) {
          var l = this[i] & 32767;
          var h = this[i++] >> 15;
          var m = xh * l + h * xl;
          l = xl * l + ((m & 32767) << 15) + w[j] + (c & 1073741823);
          c = (l >>> 30) + (m >>> 15) + xh * h + (c >>> 30);
          w[j++] = l & 1073741823;
        }
        return c;
      }
      function am3(i, x, w, j, c, n) {
        var xl = x & 16383, xh = x >> 14;
        while (--n >= 0) {
          var l = this[i] & 16383;
          var h = this[i++] >> 14;
          var m = xh * l + h * xl;
          l = xl * l + ((m & 16383) << 14) + w[j] + c;
          c = (l >> 28) + (m >> 14) + xh * h;
          w[j++] = l & 268435455;
        }
        return c;
      }
      var inBrowser = typeof navigator !== "undefined";
      if (inBrowser && j_lm && navigator.appName == "Microsoft Internet Explorer") {
        BigInteger.prototype.am = am2;
        dbits = 30;
      } else if (inBrowser && j_lm && navigator.appName != "Netscape") {
        BigInteger.prototype.am = am1;
        dbits = 26;
      } else {
        BigInteger.prototype.am = am3;
        dbits = 28;
      }
      BigInteger.prototype.DB = dbits;
      BigInteger.prototype.DM = (1 << dbits) - 1;
      BigInteger.prototype.DV = 1 << dbits;
      var BI_FP = 52;
      BigInteger.prototype.FV = Math.pow(2, BI_FP);
      BigInteger.prototype.F1 = BI_FP - dbits;
      BigInteger.prototype.F2 = 2 * dbits - BI_FP;
      var BI_RM = "0123456789abcdefghijklmnopqrstuvwxyz";
      var BI_RC = new Array();
      var rr, vv;
      rr = "0".charCodeAt(0);
      for (vv = 0; vv <= 9; ++vv) BI_RC[rr++] = vv;
      rr = "a".charCodeAt(0);
      for (vv = 10; vv < 36; ++vv) BI_RC[rr++] = vv;
      rr = "A".charCodeAt(0);
      for (vv = 10; vv < 36; ++vv) BI_RC[rr++] = vv;
      function int2char(n) {
        return BI_RM.charAt(n);
      }
      function intAt(s, i) {
        var c = BI_RC[s.charCodeAt(i)];
        return c == null ? -1 : c;
      }
      function bnpCopyTo(r) {
        for (var i = this.t - 1; i >= 0; --i) r[i] = this[i];
        r.t = this.t;
        r.s = this.s;
      }
      function bnpFromInt(x) {
        this.t = 1;
        this.s = x < 0 ? -1 : 0;
        if (x > 0) this[0] = x;
        else if (x < -1) this[0] = x + this.DV;
        else this.t = 0;
      }
      function nbv(i) {
        var r = nbi();
        r.fromInt(i);
        return r;
      }
      function bnpFromString(s, b) {
        var k;
        if (b == 16) k = 4;
        else if (b == 8) k = 3;
        else if (b == 256) k = 8;
        else if (b == 2) k = 1;
        else if (b == 32) k = 5;
        else if (b == 4) k = 2;
        else {
          this.fromRadix(s, b);
          return;
        }
        this.t = 0;
        this.s = 0;
        var i = s.length, mi = false, sh = 0;
        while (--i >= 0) {
          var x = k == 8 ? s[i] & 255 : intAt(s, i);
          if (x < 0) {
            if (s.charAt(i) == "-") mi = true;
            continue;
          }
          mi = false;
          if (sh == 0)
            this[this.t++] = x;
          else if (sh + k > this.DB) {
            this[this.t - 1] |= (x & (1 << this.DB - sh) - 1) << sh;
            this[this.t++] = x >> this.DB - sh;
          } else
            this[this.t - 1] |= x << sh;
          sh += k;
          if (sh >= this.DB) sh -= this.DB;
        }
        if (k == 8 && (s[0] & 128) != 0) {
          this.s = -1;
          if (sh > 0) this[this.t - 1] |= (1 << this.DB - sh) - 1 << sh;
        }
        this.clamp();
        if (mi) BigInteger.ZERO.subTo(this, this);
      }
      function bnpClamp() {
        var c = this.s & this.DM;
        while (this.t > 0 && this[this.t - 1] == c) --this.t;
      }
      function bnToString(b) {
        if (this.s < 0) return "-" + this.negate().toString(b);
        var k;
        if (b == 16) k = 4;
        else if (b == 8) k = 3;
        else if (b == 2) k = 1;
        else if (b == 32) k = 5;
        else if (b == 4) k = 2;
        else return this.toRadix(b);
        var km = (1 << k) - 1, d, m = false, r = "", i = this.t;
        var p = this.DB - i * this.DB % k;
        if (i-- > 0) {
          if (p < this.DB && (d = this[i] >> p) > 0) {
            m = true;
            r = int2char(d);
          }
          while (i >= 0) {
            if (p < k) {
              d = (this[i] & (1 << p) - 1) << k - p;
              d |= this[--i] >> (p += this.DB - k);
            } else {
              d = this[i] >> (p -= k) & km;
              if (p <= 0) {
                p += this.DB;
                --i;
              }
            }
            if (d > 0) m = true;
            if (m) r += int2char(d);
          }
        }
        return m ? r : "0";
      }
      function bnNegate() {
        var r = nbi();
        BigInteger.ZERO.subTo(this, r);
        return r;
      }
      function bnAbs() {
        return this.s < 0 ? this.negate() : this;
      }
      function bnCompareTo(a) {
        var r = this.s - a.s;
        if (r != 0) return r;
        var i = this.t;
        r = i - a.t;
        if (r != 0) return this.s < 0 ? -r : r;
        while (--i >= 0) if ((r = this[i] - a[i]) != 0) return r;
        return 0;
      }
      function nbits(x) {
        var r = 1, t2;
        if ((t2 = x >>> 16) != 0) {
          x = t2;
          r += 16;
        }
        if ((t2 = x >> 8) != 0) {
          x = t2;
          r += 8;
        }
        if ((t2 = x >> 4) != 0) {
          x = t2;
          r += 4;
        }
        if ((t2 = x >> 2) != 0) {
          x = t2;
          r += 2;
        }
        if ((t2 = x >> 1) != 0) {
          x = t2;
          r += 1;
        }
        return r;
      }
      function bnBitLength() {
        if (this.t <= 0) return 0;
        return this.DB * (this.t - 1) + nbits(this[this.t - 1] ^ this.s & this.DM);
      }
      function bnpDLShiftTo(n, r) {
        var i;
        for (i = this.t - 1; i >= 0; --i) r[i + n] = this[i];
        for (i = n - 1; i >= 0; --i) r[i] = 0;
        r.t = this.t + n;
        r.s = this.s;
      }
      function bnpDRShiftTo(n, r) {
        for (var i = n; i < this.t; ++i) r[i - n] = this[i];
        r.t = Math.max(this.t - n, 0);
        r.s = this.s;
      }
      function bnpLShiftTo(n, r) {
        var bs = n % this.DB;
        var cbs = this.DB - bs;
        var bm = (1 << cbs) - 1;
        var ds = Math.floor(n / this.DB), c = this.s << bs & this.DM, i;
        for (i = this.t - 1; i >= 0; --i) {
          r[i + ds + 1] = this[i] >> cbs | c;
          c = (this[i] & bm) << bs;
        }
        for (i = ds - 1; i >= 0; --i) r[i] = 0;
        r[ds] = c;
        r.t = this.t + ds + 1;
        r.s = this.s;
        r.clamp();
      }
      function bnpRShiftTo(n, r) {
        r.s = this.s;
        var ds = Math.floor(n / this.DB);
        if (ds >= this.t) {
          r.t = 0;
          return;
        }
        var bs = n % this.DB;
        var cbs = this.DB - bs;
        var bm = (1 << bs) - 1;
        r[0] = this[ds] >> bs;
        for (var i = ds + 1; i < this.t; ++i) {
          r[i - ds - 1] |= (this[i] & bm) << cbs;
          r[i - ds] = this[i] >> bs;
        }
        if (bs > 0) r[this.t - ds - 1] |= (this.s & bm) << cbs;
        r.t = this.t - ds;
        r.clamp();
      }
      function bnpSubTo(a, r) {
        var i = 0, c = 0, m = Math.min(a.t, this.t);
        while (i < m) {
          c += this[i] - a[i];
          r[i++] = c & this.DM;
          c >>= this.DB;
        }
        if (a.t < this.t) {
          c -= a.s;
          while (i < this.t) {
            c += this[i];
            r[i++] = c & this.DM;
            c >>= this.DB;
          }
          c += this.s;
        } else {
          c += this.s;
          while (i < a.t) {
            c -= a[i];
            r[i++] = c & this.DM;
            c >>= this.DB;
          }
          c -= a.s;
        }
        r.s = c < 0 ? -1 : 0;
        if (c < -1) r[i++] = this.DV + c;
        else if (c > 0) r[i++] = c;
        r.t = i;
        r.clamp();
      }
      function bnpMultiplyTo(a, r) {
        var x = this.abs(), y = a.abs();
        var i = x.t;
        r.t = i + y.t;
        while (--i >= 0) r[i] = 0;
        for (i = 0; i < y.t; ++i) r[i + x.t] = x.am(0, y[i], r, i, 0, x.t);
        r.s = 0;
        r.clamp();
        if (this.s != a.s) BigInteger.ZERO.subTo(r, r);
      }
      function bnpSquareTo(r) {
        var x = this.abs();
        var i = r.t = 2 * x.t;
        while (--i >= 0) r[i] = 0;
        for (i = 0; i < x.t - 1; ++i) {
          var c = x.am(i, x[i], r, 2 * i, 0, 1);
          if ((r[i + x.t] += x.am(i + 1, 2 * x[i], r, 2 * i + 1, c, x.t - i - 1)) >= x.DV) {
            r[i + x.t] -= x.DV;
            r[i + x.t + 1] = 1;
          }
        }
        if (r.t > 0) r[r.t - 1] += x.am(i, x[i], r, 2 * i, 0, 1);
        r.s = 0;
        r.clamp();
      }
      function bnpDivRemTo(m, q, r) {
        var pm = m.abs();
        if (pm.t <= 0) return;
        var pt = this.abs();
        if (pt.t < pm.t) {
          if (q != null) q.fromInt(0);
          if (r != null) this.copyTo(r);
          return;
        }
        if (r == null) r = nbi();
        var y = nbi(), ts = this.s, ms = m.s;
        var nsh = this.DB - nbits(pm[pm.t - 1]);
        if (nsh > 0) {
          pm.lShiftTo(nsh, y);
          pt.lShiftTo(nsh, r);
        } else {
          pm.copyTo(y);
          pt.copyTo(r);
        }
        var ys = y.t;
        var y0 = y[ys - 1];
        if (y0 == 0) return;
        var yt = y0 * (1 << this.F1) + (ys > 1 ? y[ys - 2] >> this.F2 : 0);
        var d1 = this.FV / yt, d2 = (1 << this.F1) / yt, e = 1 << this.F2;
        var i = r.t, j = i - ys, t2 = q == null ? nbi() : q;
        y.dlShiftTo(j, t2);
        if (r.compareTo(t2) >= 0) {
          r[r.t++] = 1;
          r.subTo(t2, r);
        }
        BigInteger.ONE.dlShiftTo(ys, t2);
        t2.subTo(y, y);
        while (y.t < ys) y[y.t++] = 0;
        while (--j >= 0) {
          var qd = r[--i] == y0 ? this.DM : Math.floor(r[i] * d1 + (r[i - 1] + e) * d2);
          if ((r[i] += y.am(0, qd, r, j, 0, ys)) < qd) {
            y.dlShiftTo(j, t2);
            r.subTo(t2, r);
            while (r[i] < --qd) r.subTo(t2, r);
          }
        }
        if (q != null) {
          r.drShiftTo(ys, q);
          if (ts != ms) BigInteger.ZERO.subTo(q, q);
        }
        r.t = ys;
        r.clamp();
        if (nsh > 0) r.rShiftTo(nsh, r);
        if (ts < 0) BigInteger.ZERO.subTo(r, r);
      }
      function bnMod(a) {
        var r = nbi();
        this.abs().divRemTo(a, null, r);
        if (this.s < 0 && r.compareTo(BigInteger.ZERO) > 0) a.subTo(r, r);
        return r;
      }
      function Classic(m) {
        this.m = m;
      }
      function cConvert(x) {
        if (x.s < 0 || x.compareTo(this.m) >= 0) return x.mod(this.m);
        else return x;
      }
      function cRevert(x) {
        return x;
      }
      function cReduce(x) {
        x.divRemTo(this.m, null, x);
      }
      function cMulTo(x, y, r) {
        x.multiplyTo(y, r);
        this.reduce(r);
      }
      function cSqrTo(x, r) {
        x.squareTo(r);
        this.reduce(r);
      }
      Classic.prototype.convert = cConvert;
      Classic.prototype.revert = cRevert;
      Classic.prototype.reduce = cReduce;
      Classic.prototype.mulTo = cMulTo;
      Classic.prototype.sqrTo = cSqrTo;
      function bnpInvDigit() {
        if (this.t < 1) return 0;
        var x = this[0];
        if ((x & 1) == 0) return 0;
        var y = x & 3;
        y = y * (2 - (x & 15) * y) & 15;
        y = y * (2 - (x & 255) * y) & 255;
        y = y * (2 - ((x & 65535) * y & 65535)) & 65535;
        y = y * (2 - x * y % this.DV) % this.DV;
        return y > 0 ? this.DV - y : -y;
      }
      function Montgomery(m) {
        this.m = m;
        this.mp = m.invDigit();
        this.mpl = this.mp & 32767;
        this.mph = this.mp >> 15;
        this.um = (1 << m.DB - 15) - 1;
        this.mt2 = 2 * m.t;
      }
      function montConvert(x) {
        var r = nbi();
        x.abs().dlShiftTo(this.m.t, r);
        r.divRemTo(this.m, null, r);
        if (x.s < 0 && r.compareTo(BigInteger.ZERO) > 0) this.m.subTo(r, r);
        return r;
      }
      function montRevert(x) {
        var r = nbi();
        x.copyTo(r);
        this.reduce(r);
        return r;
      }
      function montReduce(x) {
        while (x.t <= this.mt2)
          x[x.t++] = 0;
        for (var i = 0; i < this.m.t; ++i) {
          var j = x[i] & 32767;
          var u0 = j * this.mpl + ((j * this.mph + (x[i] >> 15) * this.mpl & this.um) << 15) & x.DM;
          j = i + this.m.t;
          x[j] += this.m.am(0, u0, x, i, 0, this.m.t);
          while (x[j] >= x.DV) {
            x[j] -= x.DV;
            x[++j]++;
          }
        }
        x.clamp();
        x.drShiftTo(this.m.t, x);
        if (x.compareTo(this.m) >= 0) x.subTo(this.m, x);
      }
      function montSqrTo(x, r) {
        x.squareTo(r);
        this.reduce(r);
      }
      function montMulTo(x, y, r) {
        x.multiplyTo(y, r);
        this.reduce(r);
      }
      Montgomery.prototype.convert = montConvert;
      Montgomery.prototype.revert = montRevert;
      Montgomery.prototype.reduce = montReduce;
      Montgomery.prototype.mulTo = montMulTo;
      Montgomery.prototype.sqrTo = montSqrTo;
      function bnpIsEven() {
        return (this.t > 0 ? this[0] & 1 : this.s) == 0;
      }
      function bnpExp(e, z2) {
        if (e > 4294967295 || e < 1) return BigInteger.ONE;
        var r = nbi(), r2 = nbi(), g = z2.convert(this), i = nbits(e) - 1;
        g.copyTo(r);
        while (--i >= 0) {
          z2.sqrTo(r, r2);
          if ((e & 1 << i) > 0) z2.mulTo(r2, g, r);
          else {
            var t2 = r;
            r = r2;
            r2 = t2;
          }
        }
        return z2.revert(r);
      }
      function bnModPowInt(e, m) {
        var z2;
        if (e < 256 || m.isEven()) z2 = new Classic(m);
        else z2 = new Montgomery(m);
        return this.exp(e, z2);
      }
      BigInteger.prototype.copyTo = bnpCopyTo;
      BigInteger.prototype.fromInt = bnpFromInt;
      BigInteger.prototype.fromString = bnpFromString;
      BigInteger.prototype.clamp = bnpClamp;
      BigInteger.prototype.dlShiftTo = bnpDLShiftTo;
      BigInteger.prototype.drShiftTo = bnpDRShiftTo;
      BigInteger.prototype.lShiftTo = bnpLShiftTo;
      BigInteger.prototype.rShiftTo = bnpRShiftTo;
      BigInteger.prototype.subTo = bnpSubTo;
      BigInteger.prototype.multiplyTo = bnpMultiplyTo;
      BigInteger.prototype.squareTo = bnpSquareTo;
      BigInteger.prototype.divRemTo = bnpDivRemTo;
      BigInteger.prototype.invDigit = bnpInvDigit;
      BigInteger.prototype.isEven = bnpIsEven;
      BigInteger.prototype.exp = bnpExp;
      BigInteger.prototype.toString = bnToString;
      BigInteger.prototype.negate = bnNegate;
      BigInteger.prototype.abs = bnAbs;
      BigInteger.prototype.compareTo = bnCompareTo;
      BigInteger.prototype.bitLength = bnBitLength;
      BigInteger.prototype.mod = bnMod;
      BigInteger.prototype.modPowInt = bnModPowInt;
      BigInteger.ZERO = nbv(0);
      BigInteger.ONE = nbv(1);
      function bnClone() {
        var r = nbi();
        this.copyTo(r);
        return r;
      }
      function bnIntValue() {
        if (this.s < 0) {
          if (this.t == 1) return this[0] - this.DV;
          else if (this.t == 0) return -1;
        } else if (this.t == 1) return this[0];
        else if (this.t == 0) return 0;
        return (this[1] & (1 << 32 - this.DB) - 1) << this.DB | this[0];
      }
      function bnByteValue() {
        return this.t == 0 ? this.s : this[0] << 24 >> 24;
      }
      function bnShortValue() {
        return this.t == 0 ? this.s : this[0] << 16 >> 16;
      }
      function bnpChunkSize(r) {
        return Math.floor(Math.LN2 * this.DB / Math.log(r));
      }
      function bnSigNum() {
        if (this.s < 0) return -1;
        else if (this.t <= 0 || this.t == 1 && this[0] <= 0) return 0;
        else return 1;
      }
      function bnpToRadix(b) {
        if (b == null) b = 10;
        if (this.signum() == 0 || b < 2 || b > 36) return "0";
        var cs = this.chunkSize(b);
        var a = Math.pow(b, cs);
        var d = nbv(a), y = nbi(), z2 = nbi(), r = "";
        this.divRemTo(d, y, z2);
        while (y.signum() > 0) {
          r = (a + z2.intValue()).toString(b).substr(1) + r;
          y.divRemTo(d, y, z2);
        }
        return z2.intValue().toString(b) + r;
      }
      function bnpFromRadix(s, b) {
        this.fromInt(0);
        if (b == null) b = 10;
        var cs = this.chunkSize(b);
        var d = Math.pow(b, cs), mi = false, j = 0, w = 0;
        for (var i = 0; i < s.length; ++i) {
          var x = intAt(s, i);
          if (x < 0) {
            if (s.charAt(i) == "-" && this.signum() == 0) mi = true;
            continue;
          }
          w = b * w + x;
          if (++j >= cs) {
            this.dMultiply(d);
            this.dAddOffset(w, 0);
            j = 0;
            w = 0;
          }
        }
        if (j > 0) {
          this.dMultiply(Math.pow(b, j));
          this.dAddOffset(w, 0);
        }
        if (mi) BigInteger.ZERO.subTo(this, this);
      }
      function bnpFromNumber(a, b, c) {
        if ("number" == typeof b) {
          if (a < 2) this.fromInt(1);
          else {
            this.fromNumber(a, c);
            if (!this.testBit(a - 1))
              this.bitwiseTo(BigInteger.ONE.shiftLeft(a - 1), op_or, this);
            if (this.isEven()) this.dAddOffset(1, 0);
            while (!this.isProbablePrime(b)) {
              this.dAddOffset(2, 0);
              if (this.bitLength() > a) this.subTo(BigInteger.ONE.shiftLeft(a - 1), this);
            }
          }
        } else {
          var x = new Array(), t2 = a & 7;
          x.length = (a >> 3) + 1;
          b.nextBytes(x);
          if (t2 > 0) x[0] &= (1 << t2) - 1;
          else x[0] = 0;
          this.fromString(x, 256);
        }
      }
      function bnToByteArray() {
        var i = this.t, r = new Array();
        r[0] = this.s;
        var p = this.DB - i * this.DB % 8, d, k = 0;
        if (i-- > 0) {
          if (p < this.DB && (d = this[i] >> p) != (this.s & this.DM) >> p)
            r[k++] = d | this.s << this.DB - p;
          while (i >= 0) {
            if (p < 8) {
              d = (this[i] & (1 << p) - 1) << 8 - p;
              d |= this[--i] >> (p += this.DB - 8);
            } else {
              d = this[i] >> (p -= 8) & 255;
              if (p <= 0) {
                p += this.DB;
                --i;
              }
            }
            if ((d & 128) != 0) d |= -256;
            if (k == 0 && (this.s & 128) != (d & 128)) ++k;
            if (k > 0 || d != this.s) r[k++] = d;
          }
        }
        return r;
      }
      function bnEquals(a) {
        return this.compareTo(a) == 0;
      }
      function bnMin(a) {
        return this.compareTo(a) < 0 ? this : a;
      }
      function bnMax(a) {
        return this.compareTo(a) > 0 ? this : a;
      }
      function bnpBitwiseTo(a, op, r) {
        var i, f, m = Math.min(a.t, this.t);
        for (i = 0; i < m; ++i) r[i] = op(this[i], a[i]);
        if (a.t < this.t) {
          f = a.s & this.DM;
          for (i = m; i < this.t; ++i) r[i] = op(this[i], f);
          r.t = this.t;
        } else {
          f = this.s & this.DM;
          for (i = m; i < a.t; ++i) r[i] = op(f, a[i]);
          r.t = a.t;
        }
        r.s = op(this.s, a.s);
        r.clamp();
      }
      function op_and(x, y) {
        return x & y;
      }
      function bnAnd(a) {
        var r = nbi();
        this.bitwiseTo(a, op_and, r);
        return r;
      }
      function op_or(x, y) {
        return x | y;
      }
      function bnOr(a) {
        var r = nbi();
        this.bitwiseTo(a, op_or, r);
        return r;
      }
      function op_xor(x, y) {
        return x ^ y;
      }
      function bnXor(a) {
        var r = nbi();
        this.bitwiseTo(a, op_xor, r);
        return r;
      }
      function op_andnot(x, y) {
        return x & ~y;
      }
      function bnAndNot(a) {
        var r = nbi();
        this.bitwiseTo(a, op_andnot, r);
        return r;
      }
      function bnNot() {
        var r = nbi();
        for (var i = 0; i < this.t; ++i) r[i] = this.DM & ~this[i];
        r.t = this.t;
        r.s = ~this.s;
        return r;
      }
      function bnShiftLeft(n) {
        var r = nbi();
        if (n < 0) this.rShiftTo(-n, r);
        else this.lShiftTo(n, r);
        return r;
      }
      function bnShiftRight(n) {
        var r = nbi();
        if (n < 0) this.lShiftTo(-n, r);
        else this.rShiftTo(n, r);
        return r;
      }
      function lbit(x) {
        if (x == 0) return -1;
        var r = 0;
        if ((x & 65535) == 0) {
          x >>= 16;
          r += 16;
        }
        if ((x & 255) == 0) {
          x >>= 8;
          r += 8;
        }
        if ((x & 15) == 0) {
          x >>= 4;
          r += 4;
        }
        if ((x & 3) == 0) {
          x >>= 2;
          r += 2;
        }
        if ((x & 1) == 0) ++r;
        return r;
      }
      function bnGetLowestSetBit() {
        for (var i = 0; i < this.t; ++i)
          if (this[i] != 0) return i * this.DB + lbit(this[i]);
        if (this.s < 0) return this.t * this.DB;
        return -1;
      }
      function cbit(x) {
        var r = 0;
        while (x != 0) {
          x &= x - 1;
          ++r;
        }
        return r;
      }
      function bnBitCount() {
        var r = 0, x = this.s & this.DM;
        for (var i = 0; i < this.t; ++i) r += cbit(this[i] ^ x);
        return r;
      }
      function bnTestBit(n) {
        var j = Math.floor(n / this.DB);
        if (j >= this.t) return this.s != 0;
        return (this[j] & 1 << n % this.DB) != 0;
      }
      function bnpChangeBit(n, op) {
        var r = BigInteger.ONE.shiftLeft(n);
        this.bitwiseTo(r, op, r);
        return r;
      }
      function bnSetBit(n) {
        return this.changeBit(n, op_or);
      }
      function bnClearBit(n) {
        return this.changeBit(n, op_andnot);
      }
      function bnFlipBit(n) {
        return this.changeBit(n, op_xor);
      }
      function bnpAddTo(a, r) {
        var i = 0, c = 0, m = Math.min(a.t, this.t);
        while (i < m) {
          c += this[i] + a[i];
          r[i++] = c & this.DM;
          c >>= this.DB;
        }
        if (a.t < this.t) {
          c += a.s;
          while (i < this.t) {
            c += this[i];
            r[i++] = c & this.DM;
            c >>= this.DB;
          }
          c += this.s;
        } else {
          c += this.s;
          while (i < a.t) {
            c += a[i];
            r[i++] = c & this.DM;
            c >>= this.DB;
          }
          c += a.s;
        }
        r.s = c < 0 ? -1 : 0;
        if (c > 0) r[i++] = c;
        else if (c < -1) r[i++] = this.DV + c;
        r.t = i;
        r.clamp();
      }
      function bnAdd(a) {
        var r = nbi();
        this.addTo(a, r);
        return r;
      }
      function bnSubtract(a) {
        var r = nbi();
        this.subTo(a, r);
        return r;
      }
      function bnMultiply(a) {
        var r = nbi();
        this.multiplyTo(a, r);
        return r;
      }
      function bnSquare() {
        var r = nbi();
        this.squareTo(r);
        return r;
      }
      function bnDivide(a) {
        var r = nbi();
        this.divRemTo(a, r, null);
        return r;
      }
      function bnRemainder(a) {
        var r = nbi();
        this.divRemTo(a, null, r);
        return r;
      }
      function bnDivideAndRemainder(a) {
        var q = nbi(), r = nbi();
        this.divRemTo(a, q, r);
        return new Array(q, r);
      }
      function bnpDMultiply(n) {
        this[this.t] = this.am(0, n - 1, this, 0, 0, this.t);
        ++this.t;
        this.clamp();
      }
      function bnpDAddOffset(n, w) {
        if (n == 0) return;
        while (this.t <= w) this[this.t++] = 0;
        this[w] += n;
        while (this[w] >= this.DV) {
          this[w] -= this.DV;
          if (++w >= this.t) this[this.t++] = 0;
          ++this[w];
        }
      }
      function NullExp() {
      }
      function nNop(x) {
        return x;
      }
      function nMulTo(x, y, r) {
        x.multiplyTo(y, r);
      }
      function nSqrTo(x, r) {
        x.squareTo(r);
      }
      NullExp.prototype.convert = nNop;
      NullExp.prototype.revert = nNop;
      NullExp.prototype.mulTo = nMulTo;
      NullExp.prototype.sqrTo = nSqrTo;
      function bnPow(e) {
        return this.exp(e, new NullExp());
      }
      function bnpMultiplyLowerTo(a, n, r) {
        var i = Math.min(this.t + a.t, n);
        r.s = 0;
        r.t = i;
        while (i > 0) r[--i] = 0;
        var j;
        for (j = r.t - this.t; i < j; ++i) r[i + this.t] = this.am(0, a[i], r, i, 0, this.t);
        for (j = Math.min(a.t, n); i < j; ++i) this.am(0, a[i], r, i, 0, n - i);
        r.clamp();
      }
      function bnpMultiplyUpperTo(a, n, r) {
        --n;
        var i = r.t = this.t + a.t - n;
        r.s = 0;
        while (--i >= 0) r[i] = 0;
        for (i = Math.max(n - this.t, 0); i < a.t; ++i)
          r[this.t + i - n] = this.am(n - i, a[i], r, 0, 0, this.t + i - n);
        r.clamp();
        r.drShiftTo(1, r);
      }
      function Barrett(m) {
        this.r2 = nbi();
        this.q3 = nbi();
        BigInteger.ONE.dlShiftTo(2 * m.t, this.r2);
        this.mu = this.r2.divide(m);
        this.m = m;
      }
      function barrettConvert(x) {
        if (x.s < 0 || x.t > 2 * this.m.t) return x.mod(this.m);
        else if (x.compareTo(this.m) < 0) return x;
        else {
          var r = nbi();
          x.copyTo(r);
          this.reduce(r);
          return r;
        }
      }
      function barrettRevert(x) {
        return x;
      }
      function barrettReduce(x) {
        x.drShiftTo(this.m.t - 1, this.r2);
        if (x.t > this.m.t + 1) {
          x.t = this.m.t + 1;
          x.clamp();
        }
        this.mu.multiplyUpperTo(this.r2, this.m.t + 1, this.q3);
        this.m.multiplyLowerTo(this.q3, this.m.t + 1, this.r2);
        while (x.compareTo(this.r2) < 0) x.dAddOffset(1, this.m.t + 1);
        x.subTo(this.r2, x);
        while (x.compareTo(this.m) >= 0) x.subTo(this.m, x);
      }
      function barrettSqrTo(x, r) {
        x.squareTo(r);
        this.reduce(r);
      }
      function barrettMulTo(x, y, r) {
        x.multiplyTo(y, r);
        this.reduce(r);
      }
      Barrett.prototype.convert = barrettConvert;
      Barrett.prototype.revert = barrettRevert;
      Barrett.prototype.reduce = barrettReduce;
      Barrett.prototype.mulTo = barrettMulTo;
      Barrett.prototype.sqrTo = barrettSqrTo;
      function bnModPow(e, m) {
        var i = e.bitLength(), k, r = nbv(1), z2;
        if (i <= 0) return r;
        else if (i < 18) k = 1;
        else if (i < 48) k = 3;
        else if (i < 144) k = 4;
        else if (i < 768) k = 5;
        else k = 6;
        if (i < 8)
          z2 = new Classic(m);
        else if (m.isEven())
          z2 = new Barrett(m);
        else
          z2 = new Montgomery(m);
        var g = new Array(), n = 3, k1 = k - 1, km = (1 << k) - 1;
        g[1] = z2.convert(this);
        if (k > 1) {
          var g2 = nbi();
          z2.sqrTo(g[1], g2);
          while (n <= km) {
            g[n] = nbi();
            z2.mulTo(g2, g[n - 2], g[n]);
            n += 2;
          }
        }
        var j = e.t - 1, w, is1 = true, r2 = nbi(), t2;
        i = nbits(e[j]) - 1;
        while (j >= 0) {
          if (i >= k1) w = e[j] >> i - k1 & km;
          else {
            w = (e[j] & (1 << i + 1) - 1) << k1 - i;
            if (j > 0) w |= e[j - 1] >> this.DB + i - k1;
          }
          n = k;
          while ((w & 1) == 0) {
            w >>= 1;
            --n;
          }
          if ((i -= n) < 0) {
            i += this.DB;
            --j;
          }
          if (is1) {
            g[w].copyTo(r);
            is1 = false;
          } else {
            while (n > 1) {
              z2.sqrTo(r, r2);
              z2.sqrTo(r2, r);
              n -= 2;
            }
            if (n > 0) z2.sqrTo(r, r2);
            else {
              t2 = r;
              r = r2;
              r2 = t2;
            }
            z2.mulTo(r2, g[w], r);
          }
          while (j >= 0 && (e[j] & 1 << i) == 0) {
            z2.sqrTo(r, r2);
            t2 = r;
            r = r2;
            r2 = t2;
            if (--i < 0) {
              i = this.DB - 1;
              --j;
            }
          }
        }
        return z2.revert(r);
      }
      function bnGCD(a) {
        var x = this.s < 0 ? this.negate() : this.clone();
        var y = a.s < 0 ? a.negate() : a.clone();
        if (x.compareTo(y) < 0) {
          var t2 = x;
          x = y;
          y = t2;
        }
        var i = x.getLowestSetBit(), g = y.getLowestSetBit();
        if (g < 0) return x;
        if (i < g) g = i;
        if (g > 0) {
          x.rShiftTo(g, x);
          y.rShiftTo(g, y);
        }
        while (x.signum() > 0) {
          if ((i = x.getLowestSetBit()) > 0) x.rShiftTo(i, x);
          if ((i = y.getLowestSetBit()) > 0) y.rShiftTo(i, y);
          if (x.compareTo(y) >= 0) {
            x.subTo(y, x);
            x.rShiftTo(1, x);
          } else {
            y.subTo(x, y);
            y.rShiftTo(1, y);
          }
        }
        if (g > 0) y.lShiftTo(g, y);
        return y;
      }
      function bnpModInt(n) {
        if (n <= 0) return 0;
        var d = this.DV % n, r = this.s < 0 ? n - 1 : 0;
        if (this.t > 0)
          if (d == 0) r = this[0] % n;
          else for (var i = this.t - 1; i >= 0; --i) r = (d * r + this[i]) % n;
        return r;
      }
      function bnModInverse(m) {
        var ac = m.isEven();
        if (this.isEven() && ac || m.signum() == 0) return BigInteger.ZERO;
        var u = m.clone(), v = this.clone();
        var a = nbv(1), b = nbv(0), c = nbv(0), d = nbv(1);
        while (u.signum() != 0) {
          while (u.isEven()) {
            u.rShiftTo(1, u);
            if (ac) {
              if (!a.isEven() || !b.isEven()) {
                a.addTo(this, a);
                b.subTo(m, b);
              }
              a.rShiftTo(1, a);
            } else if (!b.isEven()) b.subTo(m, b);
            b.rShiftTo(1, b);
          }
          while (v.isEven()) {
            v.rShiftTo(1, v);
            if (ac) {
              if (!c.isEven() || !d.isEven()) {
                c.addTo(this, c);
                d.subTo(m, d);
              }
              c.rShiftTo(1, c);
            } else if (!d.isEven()) d.subTo(m, d);
            d.rShiftTo(1, d);
          }
          if (u.compareTo(v) >= 0) {
            u.subTo(v, u);
            if (ac) a.subTo(c, a);
            b.subTo(d, b);
          } else {
            v.subTo(u, v);
            if (ac) c.subTo(a, c);
            d.subTo(b, d);
          }
        }
        if (v.compareTo(BigInteger.ONE) != 0) return BigInteger.ZERO;
        if (d.compareTo(m) >= 0) return d.subtract(m);
        if (d.signum() < 0) d.addTo(m, d);
        else return d;
        if (d.signum() < 0) return d.add(m);
        else return d;
      }
      var lowprimes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641, 643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809, 811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977, 983, 991, 997];
      var lplim = (1 << 26) / lowprimes[lowprimes.length - 1];
      function bnIsProbablePrime(t2) {
        var i, x = this.abs();
        if (x.t == 1 && x[0] <= lowprimes[lowprimes.length - 1]) {
          for (i = 0; i < lowprimes.length; ++i)
            if (x[0] == lowprimes[i]) return true;
          return false;
        }
        if (x.isEven()) return false;
        i = 1;
        while (i < lowprimes.length) {
          var m = lowprimes[i], j = i + 1;
          while (j < lowprimes.length && m < lplim) m *= lowprimes[j++];
          m = x.modInt(m);
          while (i < j) if (m % lowprimes[i++] == 0) return false;
        }
        return x.millerRabin(t2);
      }
      function bnpMillerRabin(t2) {
        var n1 = this.subtract(BigInteger.ONE);
        var k = n1.getLowestSetBit();
        if (k <= 0) return false;
        var r = n1.shiftRight(k);
        t2 = t2 + 1 >> 1;
        if (t2 > lowprimes.length) t2 = lowprimes.length;
        var a = nbi();
        for (var i = 0; i < t2; ++i) {
          a.fromInt(lowprimes[Math.floor(Math.random() * lowprimes.length)]);
          var y = a.modPow(r, this);
          if (y.compareTo(BigInteger.ONE) != 0 && y.compareTo(n1) != 0) {
            var j = 1;
            while (j++ < k && y.compareTo(n1) != 0) {
              y = y.modPowInt(2, this);
              if (y.compareTo(BigInteger.ONE) == 0) return false;
            }
            if (y.compareTo(n1) != 0) return false;
          }
        }
        return true;
      }
      BigInteger.prototype.chunkSize = bnpChunkSize;
      BigInteger.prototype.toRadix = bnpToRadix;
      BigInteger.prototype.fromRadix = bnpFromRadix;
      BigInteger.prototype.fromNumber = bnpFromNumber;
      BigInteger.prototype.bitwiseTo = bnpBitwiseTo;
      BigInteger.prototype.changeBit = bnpChangeBit;
      BigInteger.prototype.addTo = bnpAddTo;
      BigInteger.prototype.dMultiply = bnpDMultiply;
      BigInteger.prototype.dAddOffset = bnpDAddOffset;
      BigInteger.prototype.multiplyLowerTo = bnpMultiplyLowerTo;
      BigInteger.prototype.multiplyUpperTo = bnpMultiplyUpperTo;
      BigInteger.prototype.modInt = bnpModInt;
      BigInteger.prototype.millerRabin = bnpMillerRabin;
      BigInteger.prototype.clone = bnClone;
      BigInteger.prototype.intValue = bnIntValue;
      BigInteger.prototype.byteValue = bnByteValue;
      BigInteger.prototype.shortValue = bnShortValue;
      BigInteger.prototype.signum = bnSigNum;
      BigInteger.prototype.toByteArray = bnToByteArray;
      BigInteger.prototype.equals = bnEquals;
      BigInteger.prototype.min = bnMin;
      BigInteger.prototype.max = bnMax;
      BigInteger.prototype.and = bnAnd;
      BigInteger.prototype.or = bnOr;
      BigInteger.prototype.xor = bnXor;
      BigInteger.prototype.andNot = bnAndNot;
      BigInteger.prototype.not = bnNot;
      BigInteger.prototype.shiftLeft = bnShiftLeft;
      BigInteger.prototype.shiftRight = bnShiftRight;
      BigInteger.prototype.getLowestSetBit = bnGetLowestSetBit;
      BigInteger.prototype.bitCount = bnBitCount;
      BigInteger.prototype.testBit = bnTestBit;
      BigInteger.prototype.setBit = bnSetBit;
      BigInteger.prototype.clearBit = bnClearBit;
      BigInteger.prototype.flipBit = bnFlipBit;
      BigInteger.prototype.add = bnAdd;
      BigInteger.prototype.subtract = bnSubtract;
      BigInteger.prototype.multiply = bnMultiply;
      BigInteger.prototype.divide = bnDivide;
      BigInteger.prototype.remainder = bnRemainder;
      BigInteger.prototype.divideAndRemainder = bnDivideAndRemainder;
      BigInteger.prototype.modPow = bnModPow;
      BigInteger.prototype.modInverse = bnModInverse;
      BigInteger.prototype.pow = bnPow;
      BigInteger.prototype.gcd = bnGCD;
      BigInteger.prototype.isProbablePrime = bnIsProbablePrime;
      BigInteger.prototype.square = bnSquare;
      BigInteger.prototype.Barrett = Barrett;
      var rng_state;
      var rng_pool;
      var rng_pptr;
      function rng_seed_int(x) {
        rng_pool[rng_pptr++] ^= x & 255;
        rng_pool[rng_pptr++] ^= x >> 8 & 255;
        rng_pool[rng_pptr++] ^= x >> 16 & 255;
        rng_pool[rng_pptr++] ^= x >> 24 & 255;
        if (rng_pptr >= rng_psize) rng_pptr -= rng_psize;
      }
      function rng_seed_time() {
        rng_seed_int((/* @__PURE__ */ new Date()).getTime());
      }
      if (rng_pool == null) {
        rng_pool = new Array();
        rng_pptr = 0;
        var t;
        if (typeof window !== "undefined" && window.crypto) {
          if (window.crypto.getRandomValues) {
            var ua = new Uint8Array(32);
            window.crypto.getRandomValues(ua);
            for (t = 0; t < 32; ++t)
              rng_pool[rng_pptr++] = ua[t];
          } else if (navigator.appName == "Netscape" && navigator.appVersion < "5") {
            var z = window.crypto.random(32);
            for (t = 0; t < z.length; ++t)
              rng_pool[rng_pptr++] = z.charCodeAt(t) & 255;
          }
        }
        while (rng_pptr < rng_psize) {
          t = Math.floor(65536 * Math.random());
          rng_pool[rng_pptr++] = t >>> 8;
          rng_pool[rng_pptr++] = t & 255;
        }
        rng_pptr = 0;
        rng_seed_time();
      }
      function rng_get_byte() {
        if (rng_state == null) {
          rng_seed_time();
          rng_state = prng_newstate();
          rng_state.init(rng_pool);
          for (rng_pptr = 0; rng_pptr < rng_pool.length; ++rng_pptr)
            rng_pool[rng_pptr] = 0;
          rng_pptr = 0;
        }
        return rng_state.next();
      }
      function rng_get_bytes(ba) {
        var i;
        for (i = 0; i < ba.length; ++i) ba[i] = rng_get_byte();
      }
      function SecureRandom() {
      }
      SecureRandom.prototype.nextBytes = rng_get_bytes;
      function Arcfour() {
        this.i = 0;
        this.j = 0;
        this.S = new Array();
      }
      function ARC4init(key) {
        var i, j, t2;
        for (i = 0; i < 256; ++i)
          this.S[i] = i;
        j = 0;
        for (i = 0; i < 256; ++i) {
          j = j + this.S[i] + key[i % key.length] & 255;
          t2 = this.S[i];
          this.S[i] = this.S[j];
          this.S[j] = t2;
        }
        this.i = 0;
        this.j = 0;
      }
      function ARC4next() {
        var t2;
        this.i = this.i + 1 & 255;
        this.j = this.j + this.S[this.i] & 255;
        t2 = this.S[this.i];
        this.S[this.i] = this.S[this.j];
        this.S[this.j] = t2;
        return this.S[t2 + this.S[this.i] & 255];
      }
      Arcfour.prototype.init = ARC4init;
      Arcfour.prototype.next = ARC4next;
      function prng_newstate() {
        return new Arcfour();
      }
      var rng_psize = 256;
      if (typeof exports !== "undefined") {
        exports = module.exports = {
          default: BigInteger,
          BigInteger,
          SecureRandom
        };
      } else {
        this.jsbn = {
          BigInteger,
          SecureRandom
        };
      }
    }).call(exports);
  }
});

// node_modules/ip-address/lib/common.js
var require_common2 = __commonJS({
  "node_modules/ip-address/lib/common.js"(exports) {
    "use strict";
    var falseIfInvalid = exports.falseIfInvalid = function(fn) {
      return function() {
        if (!this.valid) {
          return false;
        }
        return fn.apply(this, arguments);
      };
    };
    exports.isInSubnet = falseIfInvalid(function(address) {
      if (this.subnetMask < address.subnetMask) {
        return false;
      }
      if (this.mask(address.subnetMask) === address.mask()) {
        return true;
      }
      return false;
    });
    exports.isCorrect = function(defaultBits) {
      return falseIfInvalid(function() {
        if (this.addressMinusSuffix !== this.correctForm()) {
          return false;
        }
        if (this.subnetMask === defaultBits && !this.parsedSubnet) {
          return true;
        }
        return this.parsedSubnet === String(this.subnetMask);
      });
    };
  }
});

// node_modules/sprintf-js/src/sprintf.js
var require_sprintf = __commonJS({
  "node_modules/sprintf-js/src/sprintf.js"(exports) {
    !(function() {
      "use strict";
      var re = {
        not_string: /[^s]/,
        not_bool: /[^t]/,
        not_type: /[^T]/,
        not_primitive: /[^v]/,
        number: /[diefg]/,
        numeric_arg: /[bcdiefguxX]/,
        json: /[j]/,
        not_json: /[^j]/,
        text: /^[^\x25]+/,
        modulo: /^\x25{2}/,
        placeholder: /^\x25(?:([1-9]\d*)\$|\(([^)]+)\))?(\+)?(0|'[^$])?(-)?(\d+)?(?:\.(\d+))?([b-gijostTuvxX])/,
        key: /^([a-z_][a-z_\d]*)/i,
        key_access: /^\.([a-z_][a-z_\d]*)/i,
        index_access: /^\[(\d+)\]/,
        sign: /^[+-]/
      };
      function sprintf(key) {
        return sprintf_format(sprintf_parse(key), arguments);
      }
      function vsprintf(fmt, argv) {
        return sprintf.apply(null, [fmt].concat(argv || []));
      }
      function sprintf_format(parse_tree, argv) {
        var cursor = 1, tree_length = parse_tree.length, arg, output = "", i, k, ph, pad, pad_character, pad_length, is_positive, sign;
        for (i = 0; i < tree_length; i++) {
          if (typeof parse_tree[i] === "string") {
            output += parse_tree[i];
          } else if (typeof parse_tree[i] === "object") {
            ph = parse_tree[i];
            if (ph.keys) {
              arg = argv[cursor];
              for (k = 0; k < ph.keys.length; k++) {
                if (arg == void 0) {
                  throw new Error(sprintf('[sprintf] Cannot access property "%s" of undefined value "%s"', ph.keys[k], ph.keys[k - 1]));
                }
                arg = arg[ph.keys[k]];
              }
            } else if (ph.param_no) {
              arg = argv[ph.param_no];
            } else {
              arg = argv[cursor++];
            }
            if (re.not_type.test(ph.type) && re.not_primitive.test(ph.type) && arg instanceof Function) {
              arg = arg();
            }
            if (re.numeric_arg.test(ph.type) && (typeof arg !== "number" && isNaN(arg))) {
              throw new TypeError(sprintf("[sprintf] expecting number but found %T", arg));
            }
            if (re.number.test(ph.type)) {
              is_positive = arg >= 0;
            }
            switch (ph.type) {
              case "b":
                arg = parseInt(arg, 10).toString(2);
                break;
              case "c":
                arg = String.fromCharCode(parseInt(arg, 10));
                break;
              case "d":
              case "i":
                arg = parseInt(arg, 10);
                break;
              case "j":
                arg = JSON.stringify(arg, null, ph.width ? parseInt(ph.width) : 0);
                break;
              case "e":
                arg = ph.precision ? parseFloat(arg).toExponential(ph.precision) : parseFloat(arg).toExponential();
                break;
              case "f":
                arg = ph.precision ? parseFloat(arg).toFixed(ph.precision) : parseFloat(arg);
                break;
              case "g":
                arg = ph.precision ? String(Number(arg.toPrecision(ph.precision))) : parseFloat(arg);
                break;
              case "o":
                arg = (parseInt(arg, 10) >>> 0).toString(8);
                break;
              case "s":
                arg = String(arg);
                arg = ph.precision ? arg.substring(0, ph.precision) : arg;
                break;
              case "t":
                arg = String(!!arg);
                arg = ph.precision ? arg.substring(0, ph.precision) : arg;
                break;
              case "T":
                arg = Object.prototype.toString.call(arg).slice(8, -1).toLowerCase();
                arg = ph.precision ? arg.substring(0, ph.precision) : arg;
                break;
              case "u":
                arg = parseInt(arg, 10) >>> 0;
                break;
              case "v":
                arg = arg.valueOf();
                arg = ph.precision ? arg.substring(0, ph.precision) : arg;
                break;
              case "x":
                arg = (parseInt(arg, 10) >>> 0).toString(16);
                break;
              case "X":
                arg = (parseInt(arg, 10) >>> 0).toString(16).toUpperCase();
                break;
            }
            if (re.json.test(ph.type)) {
              output += arg;
            } else {
              if (re.number.test(ph.type) && (!is_positive || ph.sign)) {
                sign = is_positive ? "+" : "-";
                arg = arg.toString().replace(re.sign, "");
              } else {
                sign = "";
              }
              pad_character = ph.pad_char ? ph.pad_char === "0" ? "0" : ph.pad_char.charAt(1) : " ";
              pad_length = ph.width - (sign + arg).length;
              pad = ph.width ? pad_length > 0 ? pad_character.repeat(pad_length) : "" : "";
              output += ph.align ? sign + arg + pad : pad_character === "0" ? sign + pad + arg : pad + sign + arg;
            }
          }
        }
        return output;
      }
      var sprintf_cache = /* @__PURE__ */ Object.create(null);
      function sprintf_parse(fmt) {
        if (sprintf_cache[fmt]) {
          return sprintf_cache[fmt];
        }
        var _fmt = fmt, match, parse_tree = [], arg_names = 0;
        while (_fmt) {
          if ((match = re.text.exec(_fmt)) !== null) {
            parse_tree.push(match[0]);
          } else if ((match = re.modulo.exec(_fmt)) !== null) {
            parse_tree.push("%");
          } else if ((match = re.placeholder.exec(_fmt)) !== null) {
            if (match[2]) {
              arg_names |= 1;
              var field_list = [], replacement_field = match[2], field_match = [];
              if ((field_match = re.key.exec(replacement_field)) !== null) {
                field_list.push(field_match[1]);
                while ((replacement_field = replacement_field.substring(field_match[0].length)) !== "") {
                  if ((field_match = re.key_access.exec(replacement_field)) !== null) {
                    field_list.push(field_match[1]);
                  } else if ((field_match = re.index_access.exec(replacement_field)) !== null) {
                    field_list.push(field_match[1]);
                  } else {
                    throw new SyntaxError("[sprintf] failed to parse named argument key");
                  }
                }
              } else {
                throw new SyntaxError("[sprintf] failed to parse named argument key");
              }
              match[2] = field_list;
            } else {
              arg_names |= 2;
            }
            if (arg_names === 3) {
              throw new Error("[sprintf] mixing positional and named placeholders is not (yet) supported");
            }
            parse_tree.push(
              {
                placeholder: match[0],
                param_no: match[1],
                keys: match[2],
                sign: match[3],
                pad_char: match[4],
                align: match[5],
                width: match[6],
                precision: match[7],
                type: match[8]
              }
            );
          } else {
            throw new SyntaxError("[sprintf] unexpected placeholder");
          }
          _fmt = _fmt.substring(match[0].length);
        }
        return sprintf_cache[fmt] = parse_tree;
      }
      if (typeof exports !== "undefined") {
        exports["sprintf"] = sprintf;
        exports["vsprintf"] = vsprintf;
      }
      if (typeof window !== "undefined") {
        window["sprintf"] = sprintf;
        window["vsprintf"] = vsprintf;
        if (typeof define === "function" && define["amd"]) {
          define(function() {
            return {
              "sprintf": sprintf,
              "vsprintf": vsprintf
            };
          });
        }
      }
    })();
  }
});

// node_modules/lodash.padstart/index.js
var require_lodash = __commonJS({
  "node_modules/lodash.padstart/index.js"(exports, module) {
    var INFINITY = 1 / 0;
    var MAX_SAFE_INTEGER = 9007199254740991;
    var MAX_INTEGER = 17976931348623157e292;
    var NAN = 0 / 0;
    var symbolTag = "[object Symbol]";
    var reTrim = /^\s+|\s+$/g;
    var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
    var reIsBinary = /^0b[01]+$/i;
    var reIsOctal = /^0o[0-7]+$/i;
    var rsAstralRange = "\\ud800-\\udfff";
    var rsComboMarksRange = "\\u0300-\\u036f\\ufe20-\\ufe23";
    var rsComboSymbolsRange = "\\u20d0-\\u20f0";
    var rsVarRange = "\\ufe0e\\ufe0f";
    var rsAstral = "[" + rsAstralRange + "]";
    var rsCombo = "[" + rsComboMarksRange + rsComboSymbolsRange + "]";
    var rsFitz = "\\ud83c[\\udffb-\\udfff]";
    var rsModifier = "(?:" + rsCombo + "|" + rsFitz + ")";
    var rsNonAstral = "[^" + rsAstralRange + "]";
    var rsRegional = "(?:\\ud83c[\\udde6-\\uddff]){2}";
    var rsSurrPair = "[\\ud800-\\udbff][\\udc00-\\udfff]";
    var rsZWJ = "\\u200d";
    var reOptMod = rsModifier + "?";
    var rsOptVar = "[" + rsVarRange + "]?";
    var rsOptJoin = "(?:" + rsZWJ + "(?:" + [rsNonAstral, rsRegional, rsSurrPair].join("|") + ")" + rsOptVar + reOptMod + ")*";
    var rsSeq = rsOptVar + reOptMod + rsOptJoin;
    var rsSymbol = "(?:" + [rsNonAstral + rsCombo + "?", rsCombo, rsRegional, rsSurrPair, rsAstral].join("|") + ")";
    var reUnicode = RegExp(rsFitz + "(?=" + rsFitz + ")|" + rsSymbol + rsSeq, "g");
    var reHasUnicode = RegExp("[" + rsZWJ + rsAstralRange + rsComboMarksRange + rsComboSymbolsRange + rsVarRange + "]");
    var freeParseInt = parseInt;
    var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
    var freeSelf = typeof self == "object" && self && self.Object === Object && self;
    var root = freeGlobal || freeSelf || Function("return this")();
    var asciiSize = baseProperty("length");
    function asciiToArray(string) {
      return string.split("");
    }
    function baseProperty(key) {
      return function(object) {
        return object == null ? void 0 : object[key];
      };
    }
    function hasUnicode(string) {
      return reHasUnicode.test(string);
    }
    function stringSize(string) {
      return hasUnicode(string) ? unicodeSize(string) : asciiSize(string);
    }
    function stringToArray(string) {
      return hasUnicode(string) ? unicodeToArray(string) : asciiToArray(string);
    }
    function unicodeSize(string) {
      var result = reUnicode.lastIndex = 0;
      while (reUnicode.test(string)) {
        result++;
      }
      return result;
    }
    function unicodeToArray(string) {
      return string.match(reUnicode) || [];
    }
    var objectProto = Object.prototype;
    var objectToString = objectProto.toString;
    var Symbol2 = root.Symbol;
    var nativeCeil = Math.ceil;
    var nativeFloor = Math.floor;
    var symbolProto = Symbol2 ? Symbol2.prototype : void 0;
    var symbolToString = symbolProto ? symbolProto.toString : void 0;
    function baseRepeat(string, n) {
      var result = "";
      if (!string || n < 1 || n > MAX_SAFE_INTEGER) {
        return result;
      }
      do {
        if (n % 2) {
          result += string;
        }
        n = nativeFloor(n / 2);
        if (n) {
          string += string;
        }
      } while (n);
      return result;
    }
    function baseSlice(array, start, end) {
      var index = -1, length = array.length;
      if (start < 0) {
        start = -start > length ? 0 : length + start;
      }
      end = end > length ? length : end;
      if (end < 0) {
        end += length;
      }
      length = start > end ? 0 : end - start >>> 0;
      start >>>= 0;
      var result = Array(length);
      while (++index < length) {
        result[index] = array[index + start];
      }
      return result;
    }
    function baseToString(value) {
      if (typeof value == "string") {
        return value;
      }
      if (isSymbol(value)) {
        return symbolToString ? symbolToString.call(value) : "";
      }
      var result = value + "";
      return result == "0" && 1 / value == -INFINITY ? "-0" : result;
    }
    function castSlice(array, start, end) {
      var length = array.length;
      end = end === void 0 ? length : end;
      return !start && end >= length ? array : baseSlice(array, start, end);
    }
    function createPadding(length, chars) {
      chars = chars === void 0 ? " " : baseToString(chars);
      var charsLength = chars.length;
      if (charsLength < 2) {
        return charsLength ? baseRepeat(chars, length) : chars;
      }
      var result = baseRepeat(chars, nativeCeil(length / stringSize(chars)));
      return hasUnicode(chars) ? castSlice(stringToArray(result), 0, length).join("") : result.slice(0, length);
    }
    function isObject(value) {
      var type = typeof value;
      return !!value && (type == "object" || type == "function");
    }
    function isObjectLike(value) {
      return !!value && typeof value == "object";
    }
    function isSymbol(value) {
      return typeof value == "symbol" || isObjectLike(value) && objectToString.call(value) == symbolTag;
    }
    function toFinite(value) {
      if (!value) {
        return value === 0 ? value : 0;
      }
      value = toNumber(value);
      if (value === INFINITY || value === -INFINITY) {
        var sign = value < 0 ? -1 : 1;
        return sign * MAX_INTEGER;
      }
      return value === value ? value : 0;
    }
    function toInteger(value) {
      var result = toFinite(value), remainder = result % 1;
      return result === result ? remainder ? result - remainder : result : 0;
    }
    function toNumber(value) {
      if (typeof value == "number") {
        return value;
      }
      if (isSymbol(value)) {
        return NAN;
      }
      if (isObject(value)) {
        var other = typeof value.valueOf == "function" ? value.valueOf() : value;
        value = isObject(other) ? other + "" : other;
      }
      if (typeof value != "string") {
        return value === 0 ? value : +value;
      }
      value = value.replace(reTrim, "");
      var isBinary = reIsBinary.test(value);
      return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
    }
    function toString(value) {
      return value == null ? "" : baseToString(value);
    }
    function padStart(string, length, chars) {
      string = toString(string);
      length = toInteger(length);
      var strLength = length ? stringSize(string) : 0;
      return length && strLength < length ? createPadding(length - strLength, chars) + string : string;
    }
    module.exports = padStart;
  }
});

// node_modules/lodash.repeat/index.js
var require_lodash2 = __commonJS({
  "node_modules/lodash.repeat/index.js"(exports, module) {
    var INFINITY = 1 / 0;
    var MAX_SAFE_INTEGER = 9007199254740991;
    var MAX_INTEGER = 17976931348623157e292;
    var NAN = 0 / 0;
    var funcTag = "[object Function]";
    var genTag = "[object GeneratorFunction]";
    var symbolTag = "[object Symbol]";
    var reTrim = /^\s+|\s+$/g;
    var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
    var reIsBinary = /^0b[01]+$/i;
    var reIsOctal = /^0o[0-7]+$/i;
    var reIsUint = /^(?:0|[1-9]\d*)$/;
    var freeParseInt = parseInt;
    var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
    var freeSelf = typeof self == "object" && self && self.Object === Object && self;
    var root = freeGlobal || freeSelf || Function("return this")();
    var objectProto = Object.prototype;
    var objectToString = objectProto.toString;
    var Symbol2 = root.Symbol;
    var nativeFloor = Math.floor;
    var symbolProto = Symbol2 ? Symbol2.prototype : void 0;
    var symbolToString = symbolProto ? symbolProto.toString : void 0;
    function baseRepeat(string, n) {
      var result = "";
      if (!string || n < 1 || n > MAX_SAFE_INTEGER) {
        return result;
      }
      do {
        if (n % 2) {
          result += string;
        }
        n = nativeFloor(n / 2);
        if (n) {
          string += string;
        }
      } while (n);
      return result;
    }
    function baseToString(value) {
      if (typeof value == "string") {
        return value;
      }
      if (isSymbol(value)) {
        return symbolToString ? symbolToString.call(value) : "";
      }
      var result = value + "";
      return result == "0" && 1 / value == -INFINITY ? "-0" : result;
    }
    function isIndex(value, length) {
      length = length == null ? MAX_SAFE_INTEGER : length;
      return !!length && (typeof value == "number" || reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
    }
    function isIterateeCall(value, index, object) {
      if (!isObject(object)) {
        return false;
      }
      var type = typeof index;
      if (type == "number" ? isArrayLike(object) && isIndex(index, object.length) : type == "string" && index in object) {
        return eq(object[index], value);
      }
      return false;
    }
    function eq(value, other) {
      return value === other || value !== value && other !== other;
    }
    function isArrayLike(value) {
      return value != null && isLength(value.length) && !isFunction(value);
    }
    function isFunction(value) {
      var tag = isObject(value) ? objectToString.call(value) : "";
      return tag == funcTag || tag == genTag;
    }
    function isLength(value) {
      return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
    }
    function isObject(value) {
      var type = typeof value;
      return !!value && (type == "object" || type == "function");
    }
    function isObjectLike(value) {
      return !!value && typeof value == "object";
    }
    function isSymbol(value) {
      return typeof value == "symbol" || isObjectLike(value) && objectToString.call(value) == symbolTag;
    }
    function toFinite(value) {
      if (!value) {
        return value === 0 ? value : 0;
      }
      value = toNumber(value);
      if (value === INFINITY || value === -INFINITY) {
        var sign = value < 0 ? -1 : 1;
        return sign * MAX_INTEGER;
      }
      return value === value ? value : 0;
    }
    function toInteger(value) {
      var result = toFinite(value), remainder = result % 1;
      return result === result ? remainder ? result - remainder : result : 0;
    }
    function toNumber(value) {
      if (typeof value == "number") {
        return value;
      }
      if (isSymbol(value)) {
        return NAN;
      }
      if (isObject(value)) {
        var other = typeof value.valueOf == "function" ? value.valueOf() : value;
        value = isObject(other) ? other + "" : other;
      }
      if (typeof value != "string") {
        return value === 0 ? value : +value;
      }
      value = value.replace(reTrim, "");
      var isBinary = reIsBinary.test(value);
      return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
    }
    function toString(value) {
      return value == null ? "" : baseToString(value);
    }
    function repeat(string, n, guard) {
      if (guard ? isIterateeCall(string, n, guard) : n === void 0) {
        n = 1;
      } else {
        n = toInteger(n);
      }
      return baseRepeat(toString(string), n);
    }
    module.exports = repeat;
  }
});

// node_modules/ip-address/lib/v4/constants.js
var require_constants = __commonJS({
  "node_modules/ip-address/lib/v4/constants.js"(exports) {
    exports.BITS = 32;
    exports.GROUPS = 4;
    exports.RE_ADDRESS = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/g;
    exports.RE_SUBNET_STRING = /\/\d{1,2}$/;
  }
});

// node_modules/ip-address/lib/ipv4.js
var require_ipv4 = __commonJS({
  "node_modules/ip-address/lib/ipv4.js"(exports, module) {
    "use strict";
    var BigInteger = require_jsbn().BigInteger;
    var common = require_common2();
    var sprintf = require_sprintf().sprintf;
    var padStart = require_lodash();
    var repeat = require_lodash2();
    var constants = require_constants();
    function Address4(address) {
      this.valid = false;
      this.address = address;
      this.groups = constants.GROUPS;
      this.v4 = true;
      this.subnet = "/32";
      this.subnetMask = 32;
      var subnet = constants.RE_SUBNET_STRING.exec(address);
      if (subnet) {
        this.parsedSubnet = subnet[0].replace("/", "");
        this.subnetMask = parseInt(this.parsedSubnet, 10);
        this.subnet = "/" + this.subnetMask;
        if (this.subnetMask < 0 || this.subnetMask > constants.BITS) {
          this.valid = false;
          this.error = "Invalid subnet mask.";
          return;
        }
        address = address.replace(constants.RE_SUBNET_STRING, "");
      }
      this.addressMinusSuffix = address;
      this.parsedAddress = this.parse(address);
    }
    Address4.prototype.parse = function(address) {
      var groups = address.split(".");
      if (address.match(constants.RE_ADDRESS)) {
        this.valid = true;
      } else {
        this.error = "Invalid IPv4 address.";
      }
      return groups;
    };
    Address4.prototype.isValid = function() {
      return this.valid;
    };
    Address4.prototype.correctForm = function() {
      return this.parsedAddress.map(function(part) {
        return parseInt(part, 10);
      }).join(".");
    };
    Address4.prototype.isCorrect = common.isCorrect(constants.BITS);
    Address4.fromHex = function(hex) {
      var padded = padStart(hex.replace(/:/g, ""), 8, "0");
      var groups = [];
      var i;
      for (i = 0; i < 8; i += 2) {
        var h = padded.slice(i, i + 2);
        groups.push(parseInt(h, 16));
      }
      return new Address4(groups.join("."));
    };
    Address4.fromInteger = function(integer) {
      return Address4.fromHex(integer.toString(16));
    };
    Address4.prototype.toHex = function() {
      return this.parsedAddress.map(function(part) {
        return sprintf("%02x", parseInt(part, 10));
      }).join(":");
    };
    Address4.prototype.toArray = function() {
      return this.parsedAddress.map(function(part) {
        return parseInt(part, 10);
      });
    };
    Address4.prototype.toGroup6 = function() {
      var output = [];
      var i;
      for (i = 0; i < constants.GROUPS; i += 2) {
        var hex = sprintf(
          "%02x%02x",
          parseInt(this.parsedAddress[i], 10),
          parseInt(this.parsedAddress[i + 1], 10)
        );
        output.push(sprintf("%x", parseInt(hex, 16)));
      }
      return output.join(":");
    };
    Address4.prototype.bigInteger = function() {
      if (!this.valid) {
        return null;
      }
      return new BigInteger(this.parsedAddress.map(function(n) {
        return sprintf("%02x", parseInt(n, 10));
      }).join(""), 16);
    };
    Address4.prototype._startAddress = function() {
      return new BigInteger(
        this.mask() + repeat("0", constants.BITS - this.subnetMask),
        2
      );
    };
    Address4.prototype.startAddress = function() {
      return Address4.fromBigInteger(this._startAddress());
    };
    Address4.prototype.startAddressExclusive = function() {
      var adjust = new BigInteger("1");
      return Address4.fromBigInteger(this._startAddress().add(adjust));
    };
    Address4.prototype._endAddress = function() {
      return new BigInteger(
        this.mask() + repeat("1", constants.BITS - this.subnetMask),
        2
      );
    };
    Address4.prototype.endAddress = function() {
      return Address4.fromBigInteger(this._endAddress());
    };
    Address4.prototype.endAddressExclusive = function() {
      var adjust = new BigInteger("1");
      return Address4.fromBigInteger(this._endAddress().subtract(adjust));
    };
    Address4.fromBigInteger = function(bigInteger) {
      return Address4.fromInteger(parseInt(bigInteger.toString(), 10));
    };
    Address4.prototype.mask = function(optionalMask) {
      if (optionalMask === void 0) {
        optionalMask = this.subnetMask;
      }
      return this.getBitsBase2(0, optionalMask);
    };
    Address4.prototype.getBitsBase2 = function(start, end) {
      return this.binaryZeroPad().slice(start, end);
    };
    Address4.prototype.isInSubnet = common.isInSubnet;
    Address4.prototype.isMulticast = function() {
      return this.isInSubnet(new Address4("224.0.0.0/4"));
    };
    Address4.prototype.binaryZeroPad = function() {
      return padStart(this.bigInteger().toString(2), constants.BITS, "0");
    };
    module.exports = Address4;
  }
});

// node_modules/lodash.merge/index.js
var require_lodash3 = __commonJS({
  "node_modules/lodash.merge/index.js"(exports, module) {
    var LARGE_ARRAY_SIZE = 200;
    var HASH_UNDEFINED = "__lodash_hash_undefined__";
    var HOT_COUNT = 800;
    var HOT_SPAN = 16;
    var MAX_SAFE_INTEGER = 9007199254740991;
    var argsTag = "[object Arguments]";
    var arrayTag = "[object Array]";
    var asyncTag = "[object AsyncFunction]";
    var boolTag = "[object Boolean]";
    var dateTag = "[object Date]";
    var errorTag = "[object Error]";
    var funcTag = "[object Function]";
    var genTag = "[object GeneratorFunction]";
    var mapTag = "[object Map]";
    var numberTag = "[object Number]";
    var nullTag = "[object Null]";
    var objectTag = "[object Object]";
    var proxyTag = "[object Proxy]";
    var regexpTag = "[object RegExp]";
    var setTag = "[object Set]";
    var stringTag = "[object String]";
    var undefinedTag = "[object Undefined]";
    var weakMapTag = "[object WeakMap]";
    var arrayBufferTag = "[object ArrayBuffer]";
    var dataViewTag = "[object DataView]";
    var float32Tag = "[object Float32Array]";
    var float64Tag = "[object Float64Array]";
    var int8Tag = "[object Int8Array]";
    var int16Tag = "[object Int16Array]";
    var int32Tag = "[object Int32Array]";
    var uint8Tag = "[object Uint8Array]";
    var uint8ClampedTag = "[object Uint8ClampedArray]";
    var uint16Tag = "[object Uint16Array]";
    var uint32Tag = "[object Uint32Array]";
    var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
    var reIsHostCtor = /^\[object .+?Constructor\]$/;
    var reIsUint = /^(?:0|[1-9]\d*)$/;
    var typedArrayTags = {};
    typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
    typedArrayTags[argsTag] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag] = typedArrayTags[mapTag] = typedArrayTags[numberTag] = typedArrayTags[objectTag] = typedArrayTags[regexpTag] = typedArrayTags[setTag] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag] = false;
    var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
    var freeSelf = typeof self == "object" && self && self.Object === Object && self;
    var root = freeGlobal || freeSelf || Function("return this")();
    var freeExports = typeof exports == "object" && exports && !exports.nodeType && exports;
    var freeModule = freeExports && typeof module == "object" && module && !module.nodeType && module;
    var moduleExports = freeModule && freeModule.exports === freeExports;
    var freeProcess = moduleExports && freeGlobal.process;
    var nodeUtil = (function() {
      try {
        var types = freeModule && freeModule.require && freeModule.require("util").types;
        if (types) {
          return types;
        }
        return freeProcess && freeProcess.binding && freeProcess.binding("util");
      } catch (e) {
      }
    })();
    var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;
    function apply(func, thisArg, args) {
      switch (args.length) {
        case 0:
          return func.call(thisArg);
        case 1:
          return func.call(thisArg, args[0]);
        case 2:
          return func.call(thisArg, args[0], args[1]);
        case 3:
          return func.call(thisArg, args[0], args[1], args[2]);
      }
      return func.apply(thisArg, args);
    }
    function baseTimes(n, iteratee) {
      var index = -1, result = Array(n);
      while (++index < n) {
        result[index] = iteratee(index);
      }
      return result;
    }
    function baseUnary(func) {
      return function(value) {
        return func(value);
      };
    }
    function getValue(object, key) {
      return object == null ? void 0 : object[key];
    }
    function overArg(func, transform) {
      return function(arg) {
        return func(transform(arg));
      };
    }
    var arrayProto = Array.prototype;
    var funcProto = Function.prototype;
    var objectProto = Object.prototype;
    var coreJsData = root["__core-js_shared__"];
    var funcToString = funcProto.toString;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var maskSrcKey = (function() {
      var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || "");
      return uid ? "Symbol(src)_1." + uid : "";
    })();
    var nativeObjectToString = objectProto.toString;
    var objectCtorString = funcToString.call(Object);
    var reIsNative = RegExp(
      "^" + funcToString.call(hasOwnProperty).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
    );
    var Buffer2 = moduleExports ? root.Buffer : void 0;
    var Symbol2 = root.Symbol;
    var Uint8Array2 = root.Uint8Array;
    var allocUnsafe = Buffer2 ? Buffer2.allocUnsafe : void 0;
    var getPrototype = overArg(Object.getPrototypeOf, Object);
    var objectCreate = Object.create;
    var propertyIsEnumerable = objectProto.propertyIsEnumerable;
    var splice = arrayProto.splice;
    var symToStringTag = Symbol2 ? Symbol2.toStringTag : void 0;
    var defineProperty = (function() {
      try {
        var func = getNative(Object, "defineProperty");
        func({}, "", {});
        return func;
      } catch (e) {
      }
    })();
    var nativeIsBuffer = Buffer2 ? Buffer2.isBuffer : void 0;
    var nativeMax = Math.max;
    var nativeNow = Date.now;
    var Map = getNative(root, "Map");
    var nativeCreate = getNative(Object, "create");
    var baseCreate = /* @__PURE__ */ (function() {
      function object() {
      }
      return function(proto) {
        if (!isObject(proto)) {
          return {};
        }
        if (objectCreate) {
          return objectCreate(proto);
        }
        object.prototype = proto;
        var result = new object();
        object.prototype = void 0;
        return result;
      };
    })();
    function Hash(entries) {
      var index = -1, length = entries == null ? 0 : entries.length;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    function hashClear() {
      this.__data__ = nativeCreate ? nativeCreate(null) : {};
      this.size = 0;
    }
    function hashDelete(key) {
      var result = this.has(key) && delete this.__data__[key];
      this.size -= result ? 1 : 0;
      return result;
    }
    function hashGet(key) {
      var data = this.__data__;
      if (nativeCreate) {
        var result = data[key];
        return result === HASH_UNDEFINED ? void 0 : result;
      }
      return hasOwnProperty.call(data, key) ? data[key] : void 0;
    }
    function hashHas(key) {
      var data = this.__data__;
      return nativeCreate ? data[key] !== void 0 : hasOwnProperty.call(data, key);
    }
    function hashSet(key, value) {
      var data = this.__data__;
      this.size += this.has(key) ? 0 : 1;
      data[key] = nativeCreate && value === void 0 ? HASH_UNDEFINED : value;
      return this;
    }
    Hash.prototype.clear = hashClear;
    Hash.prototype["delete"] = hashDelete;
    Hash.prototype.get = hashGet;
    Hash.prototype.has = hashHas;
    Hash.prototype.set = hashSet;
    function ListCache(entries) {
      var index = -1, length = entries == null ? 0 : entries.length;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    function listCacheClear() {
      this.__data__ = [];
      this.size = 0;
    }
    function listCacheDelete(key) {
      var data = this.__data__, index = assocIndexOf(data, key);
      if (index < 0) {
        return false;
      }
      var lastIndex = data.length - 1;
      if (index == lastIndex) {
        data.pop();
      } else {
        splice.call(data, index, 1);
      }
      --this.size;
      return true;
    }
    function listCacheGet(key) {
      var data = this.__data__, index = assocIndexOf(data, key);
      return index < 0 ? void 0 : data[index][1];
    }
    function listCacheHas(key) {
      return assocIndexOf(this.__data__, key) > -1;
    }
    function listCacheSet(key, value) {
      var data = this.__data__, index = assocIndexOf(data, key);
      if (index < 0) {
        ++this.size;
        data.push([key, value]);
      } else {
        data[index][1] = value;
      }
      return this;
    }
    ListCache.prototype.clear = listCacheClear;
    ListCache.prototype["delete"] = listCacheDelete;
    ListCache.prototype.get = listCacheGet;
    ListCache.prototype.has = listCacheHas;
    ListCache.prototype.set = listCacheSet;
    function MapCache(entries) {
      var index = -1, length = entries == null ? 0 : entries.length;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    function mapCacheClear() {
      this.size = 0;
      this.__data__ = {
        "hash": new Hash(),
        "map": new (Map || ListCache)(),
        "string": new Hash()
      };
    }
    function mapCacheDelete(key) {
      var result = getMapData(this, key)["delete"](key);
      this.size -= result ? 1 : 0;
      return result;
    }
    function mapCacheGet(key) {
      return getMapData(this, key).get(key);
    }
    function mapCacheHas(key) {
      return getMapData(this, key).has(key);
    }
    function mapCacheSet(key, value) {
      var data = getMapData(this, key), size = data.size;
      data.set(key, value);
      this.size += data.size == size ? 0 : 1;
      return this;
    }
    MapCache.prototype.clear = mapCacheClear;
    MapCache.prototype["delete"] = mapCacheDelete;
    MapCache.prototype.get = mapCacheGet;
    MapCache.prototype.has = mapCacheHas;
    MapCache.prototype.set = mapCacheSet;
    function Stack(entries) {
      var data = this.__data__ = new ListCache(entries);
      this.size = data.size;
    }
    function stackClear() {
      this.__data__ = new ListCache();
      this.size = 0;
    }
    function stackDelete(key) {
      var data = this.__data__, result = data["delete"](key);
      this.size = data.size;
      return result;
    }
    function stackGet(key) {
      return this.__data__.get(key);
    }
    function stackHas(key) {
      return this.__data__.has(key);
    }
    function stackSet(key, value) {
      var data = this.__data__;
      if (data instanceof ListCache) {
        var pairs = data.__data__;
        if (!Map || pairs.length < LARGE_ARRAY_SIZE - 1) {
          pairs.push([key, value]);
          this.size = ++data.size;
          return this;
        }
        data = this.__data__ = new MapCache(pairs);
      }
      data.set(key, value);
      this.size = data.size;
      return this;
    }
    Stack.prototype.clear = stackClear;
    Stack.prototype["delete"] = stackDelete;
    Stack.prototype.get = stackGet;
    Stack.prototype.has = stackHas;
    Stack.prototype.set = stackSet;
    function arrayLikeKeys(value, inherited) {
      var isArr = isArray(value), isArg = !isArr && isArguments(value), isBuff = !isArr && !isArg && isBuffer(value), isType = !isArr && !isArg && !isBuff && isTypedArray(value), skipIndexes = isArr || isArg || isBuff || isType, result = skipIndexes ? baseTimes(value.length, String) : [], length = result.length;
      for (var key in value) {
        if ((inherited || hasOwnProperty.call(value, key)) && !(skipIndexes && // Safari 9 has enumerable `arguments.length` in strict mode.
        (key == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
        isBuff && (key == "offset" || key == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
        isType && (key == "buffer" || key == "byteLength" || key == "byteOffset") || // Skip index properties.
        isIndex(key, length)))) {
          result.push(key);
        }
      }
      return result;
    }
    function assignMergeValue(object, key, value) {
      if (value !== void 0 && !eq(object[key], value) || value === void 0 && !(key in object)) {
        baseAssignValue(object, key, value);
      }
    }
    function assignValue(object, key, value) {
      var objValue = object[key];
      if (!(hasOwnProperty.call(object, key) && eq(objValue, value)) || value === void 0 && !(key in object)) {
        baseAssignValue(object, key, value);
      }
    }
    function assocIndexOf(array, key) {
      var length = array.length;
      while (length--) {
        if (eq(array[length][0], key)) {
          return length;
        }
      }
      return -1;
    }
    function baseAssignValue(object, key, value) {
      if (key == "__proto__" && defineProperty) {
        defineProperty(object, key, {
          "configurable": true,
          "enumerable": true,
          "value": value,
          "writable": true
        });
      } else {
        object[key] = value;
      }
    }
    var baseFor = createBaseFor();
    function baseGetTag(value) {
      if (value == null) {
        return value === void 0 ? undefinedTag : nullTag;
      }
      return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
    }
    function baseIsArguments(value) {
      return isObjectLike(value) && baseGetTag(value) == argsTag;
    }
    function baseIsNative(value) {
      if (!isObject(value) || isMasked(value)) {
        return false;
      }
      var pattern = isFunction(value) ? reIsNative : reIsHostCtor;
      return pattern.test(toSource(value));
    }
    function baseIsTypedArray(value) {
      return isObjectLike(value) && isLength(value.length) && !!typedArrayTags[baseGetTag(value)];
    }
    function baseKeysIn(object) {
      if (!isObject(object)) {
        return nativeKeysIn(object);
      }
      var isProto = isPrototype(object), result = [];
      for (var key in object) {
        if (!(key == "constructor" && (isProto || !hasOwnProperty.call(object, key)))) {
          result.push(key);
        }
      }
      return result;
    }
    function baseMerge(object, source, srcIndex, customizer, stack) {
      if (object === source) {
        return;
      }
      baseFor(source, function(srcValue, key) {
        stack || (stack = new Stack());
        if (isObject(srcValue)) {
          baseMergeDeep(object, source, key, srcIndex, baseMerge, customizer, stack);
        } else {
          var newValue = customizer ? customizer(safeGet(object, key), srcValue, key + "", object, source, stack) : void 0;
          if (newValue === void 0) {
            newValue = srcValue;
          }
          assignMergeValue(object, key, newValue);
        }
      }, keysIn);
    }
    function baseMergeDeep(object, source, key, srcIndex, mergeFunc, customizer, stack) {
      var objValue = safeGet(object, key), srcValue = safeGet(source, key), stacked = stack.get(srcValue);
      if (stacked) {
        assignMergeValue(object, key, stacked);
        return;
      }
      var newValue = customizer ? customizer(objValue, srcValue, key + "", object, source, stack) : void 0;
      var isCommon = newValue === void 0;
      if (isCommon) {
        var isArr = isArray(srcValue), isBuff = !isArr && isBuffer(srcValue), isTyped = !isArr && !isBuff && isTypedArray(srcValue);
        newValue = srcValue;
        if (isArr || isBuff || isTyped) {
          if (isArray(objValue)) {
            newValue = objValue;
          } else if (isArrayLikeObject(objValue)) {
            newValue = copyArray(objValue);
          } else if (isBuff) {
            isCommon = false;
            newValue = cloneBuffer(srcValue, true);
          } else if (isTyped) {
            isCommon = false;
            newValue = cloneTypedArray(srcValue, true);
          } else {
            newValue = [];
          }
        } else if (isPlainObject(srcValue) || isArguments(srcValue)) {
          newValue = objValue;
          if (isArguments(objValue)) {
            newValue = toPlainObject(objValue);
          } else if (!isObject(objValue) || isFunction(objValue)) {
            newValue = initCloneObject(srcValue);
          }
        } else {
          isCommon = false;
        }
      }
      if (isCommon) {
        stack.set(srcValue, newValue);
        mergeFunc(newValue, srcValue, srcIndex, customizer, stack);
        stack["delete"](srcValue);
      }
      assignMergeValue(object, key, newValue);
    }
    function baseRest(func, start) {
      return setToString(overRest(func, start, identity), func + "");
    }
    var baseSetToString = !defineProperty ? identity : function(func, string) {
      return defineProperty(func, "toString", {
        "configurable": true,
        "enumerable": false,
        "value": constant(string),
        "writable": true
      });
    };
    function cloneBuffer(buffer, isDeep) {
      if (isDeep) {
        return buffer.slice();
      }
      var length = buffer.length, result = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);
      buffer.copy(result);
      return result;
    }
    function cloneArrayBuffer(arrayBuffer) {
      var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
      new Uint8Array2(result).set(new Uint8Array2(arrayBuffer));
      return result;
    }
    function cloneTypedArray(typedArray, isDeep) {
      var buffer = isDeep ? cloneArrayBuffer(typedArray.buffer) : typedArray.buffer;
      return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
    }
    function copyArray(source, array) {
      var index = -1, length = source.length;
      array || (array = Array(length));
      while (++index < length) {
        array[index] = source[index];
      }
      return array;
    }
    function copyObject(source, props, object, customizer) {
      var isNew = !object;
      object || (object = {});
      var index = -1, length = props.length;
      while (++index < length) {
        var key = props[index];
        var newValue = customizer ? customizer(object[key], source[key], key, object, source) : void 0;
        if (newValue === void 0) {
          newValue = source[key];
        }
        if (isNew) {
          baseAssignValue(object, key, newValue);
        } else {
          assignValue(object, key, newValue);
        }
      }
      return object;
    }
    function createAssigner(assigner) {
      return baseRest(function(object, sources) {
        var index = -1, length = sources.length, customizer = length > 1 ? sources[length - 1] : void 0, guard = length > 2 ? sources[2] : void 0;
        customizer = assigner.length > 3 && typeof customizer == "function" ? (length--, customizer) : void 0;
        if (guard && isIterateeCall(sources[0], sources[1], guard)) {
          customizer = length < 3 ? void 0 : customizer;
          length = 1;
        }
        object = Object(object);
        while (++index < length) {
          var source = sources[index];
          if (source) {
            assigner(object, source, index, customizer);
          }
        }
        return object;
      });
    }
    function createBaseFor(fromRight) {
      return function(object, iteratee, keysFunc) {
        var index = -1, iterable = Object(object), props = keysFunc(object), length = props.length;
        while (length--) {
          var key = props[fromRight ? length : ++index];
          if (iteratee(iterable[key], key, iterable) === false) {
            break;
          }
        }
        return object;
      };
    }
    function getMapData(map, key) {
      var data = map.__data__;
      return isKeyable(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
    }
    function getNative(object, key) {
      var value = getValue(object, key);
      return baseIsNative(value) ? value : void 0;
    }
    function getRawTag(value) {
      var isOwn = hasOwnProperty.call(value, symToStringTag), tag = value[symToStringTag];
      try {
        value[symToStringTag] = void 0;
        var unmasked = true;
      } catch (e) {
      }
      var result = nativeObjectToString.call(value);
      if (unmasked) {
        if (isOwn) {
          value[symToStringTag] = tag;
        } else {
          delete value[symToStringTag];
        }
      }
      return result;
    }
    function initCloneObject(object) {
      return typeof object.constructor == "function" && !isPrototype(object) ? baseCreate(getPrototype(object)) : {};
    }
    function isIndex(value, length) {
      var type = typeof value;
      length = length == null ? MAX_SAFE_INTEGER : length;
      return !!length && (type == "number" || type != "symbol" && reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
    }
    function isIterateeCall(value, index, object) {
      if (!isObject(object)) {
        return false;
      }
      var type = typeof index;
      if (type == "number" ? isArrayLike(object) && isIndex(index, object.length) : type == "string" && index in object) {
        return eq(object[index], value);
      }
      return false;
    }
    function isKeyable(value) {
      var type = typeof value;
      return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
    }
    function isMasked(func) {
      return !!maskSrcKey && maskSrcKey in func;
    }
    function isPrototype(value) {
      var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto;
      return value === proto;
    }
    function nativeKeysIn(object) {
      var result = [];
      if (object != null) {
        for (var key in Object(object)) {
          result.push(key);
        }
      }
      return result;
    }
    function objectToString(value) {
      return nativeObjectToString.call(value);
    }
    function overRest(func, start, transform) {
      start = nativeMax(start === void 0 ? func.length - 1 : start, 0);
      return function() {
        var args = arguments, index = -1, length = nativeMax(args.length - start, 0), array = Array(length);
        while (++index < length) {
          array[index] = args[start + index];
        }
        index = -1;
        var otherArgs = Array(start + 1);
        while (++index < start) {
          otherArgs[index] = args[index];
        }
        otherArgs[start] = transform(array);
        return apply(func, this, otherArgs);
      };
    }
    function safeGet(object, key) {
      if (key === "constructor" && typeof object[key] === "function") {
        return;
      }
      if (key == "__proto__") {
        return;
      }
      return object[key];
    }
    var setToString = shortOut(baseSetToString);
    function shortOut(func) {
      var count = 0, lastCalled = 0;
      return function() {
        var stamp = nativeNow(), remaining = HOT_SPAN - (stamp - lastCalled);
        lastCalled = stamp;
        if (remaining > 0) {
          if (++count >= HOT_COUNT) {
            return arguments[0];
          }
        } else {
          count = 0;
        }
        return func.apply(void 0, arguments);
      };
    }
    function toSource(func) {
      if (func != null) {
        try {
          return funcToString.call(func);
        } catch (e) {
        }
        try {
          return func + "";
        } catch (e) {
        }
      }
      return "";
    }
    function eq(value, other) {
      return value === other || value !== value && other !== other;
    }
    var isArguments = baseIsArguments(/* @__PURE__ */ (function() {
      return arguments;
    })()) ? baseIsArguments : function(value) {
      return isObjectLike(value) && hasOwnProperty.call(value, "callee") && !propertyIsEnumerable.call(value, "callee");
    };
    var isArray = Array.isArray;
    function isArrayLike(value) {
      return value != null && isLength(value.length) && !isFunction(value);
    }
    function isArrayLikeObject(value) {
      return isObjectLike(value) && isArrayLike(value);
    }
    var isBuffer = nativeIsBuffer || stubFalse;
    function isFunction(value) {
      if (!isObject(value)) {
        return false;
      }
      var tag = baseGetTag(value);
      return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
    }
    function isLength(value) {
      return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
    }
    function isObject(value) {
      var type = typeof value;
      return value != null && (type == "object" || type == "function");
    }
    function isObjectLike(value) {
      return value != null && typeof value == "object";
    }
    function isPlainObject(value) {
      if (!isObjectLike(value) || baseGetTag(value) != objectTag) {
        return false;
      }
      var proto = getPrototype(value);
      if (proto === null) {
        return true;
      }
      var Ctor = hasOwnProperty.call(proto, "constructor") && proto.constructor;
      return typeof Ctor == "function" && Ctor instanceof Ctor && funcToString.call(Ctor) == objectCtorString;
    }
    var isTypedArray = nodeIsTypedArray ? baseUnary(nodeIsTypedArray) : baseIsTypedArray;
    function toPlainObject(value) {
      return copyObject(value, keysIn(value));
    }
    function keysIn(object) {
      return isArrayLike(object) ? arrayLikeKeys(object, true) : baseKeysIn(object);
    }
    var merge = createAssigner(function(object, source, srcIndex) {
      baseMerge(object, source, srcIndex);
    });
    function constant(value) {
      return function() {
        return value;
      };
    }
    function identity(value) {
      return value;
    }
    function stubFalse() {
      return false;
    }
    module.exports = merge;
  }
});

// node_modules/lodash.find/index.js
var require_lodash4 = __commonJS({
  "node_modules/lodash.find/index.js"(exports, module) {
    var LARGE_ARRAY_SIZE = 200;
    var FUNC_ERROR_TEXT = "Expected a function";
    var HASH_UNDEFINED = "__lodash_hash_undefined__";
    var UNORDERED_COMPARE_FLAG = 1;
    var PARTIAL_COMPARE_FLAG = 2;
    var INFINITY = 1 / 0;
    var MAX_SAFE_INTEGER = 9007199254740991;
    var MAX_INTEGER = 17976931348623157e292;
    var NAN = 0 / 0;
    var argsTag = "[object Arguments]";
    var arrayTag = "[object Array]";
    var boolTag = "[object Boolean]";
    var dateTag = "[object Date]";
    var errorTag = "[object Error]";
    var funcTag = "[object Function]";
    var genTag = "[object GeneratorFunction]";
    var mapTag = "[object Map]";
    var numberTag = "[object Number]";
    var objectTag = "[object Object]";
    var promiseTag = "[object Promise]";
    var regexpTag = "[object RegExp]";
    var setTag = "[object Set]";
    var stringTag = "[object String]";
    var symbolTag = "[object Symbol]";
    var weakMapTag = "[object WeakMap]";
    var arrayBufferTag = "[object ArrayBuffer]";
    var dataViewTag = "[object DataView]";
    var float32Tag = "[object Float32Array]";
    var float64Tag = "[object Float64Array]";
    var int8Tag = "[object Int8Array]";
    var int16Tag = "[object Int16Array]";
    var int32Tag = "[object Int32Array]";
    var uint8Tag = "[object Uint8Array]";
    var uint8ClampedTag = "[object Uint8ClampedArray]";
    var uint16Tag = "[object Uint16Array]";
    var uint32Tag = "[object Uint32Array]";
    var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/;
    var reIsPlainProp = /^\w*$/;
    var reLeadingDot = /^\./;
    var rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
    var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
    var reTrim = /^\s+|\s+$/g;
    var reEscapeChar = /\\(\\)?/g;
    var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
    var reIsBinary = /^0b[01]+$/i;
    var reIsHostCtor = /^\[object .+?Constructor\]$/;
    var reIsOctal = /^0o[0-7]+$/i;
    var reIsUint = /^(?:0|[1-9]\d*)$/;
    var typedArrayTags = {};
    typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
    typedArrayTags[argsTag] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag] = typedArrayTags[mapTag] = typedArrayTags[numberTag] = typedArrayTags[objectTag] = typedArrayTags[regexpTag] = typedArrayTags[setTag] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag] = false;
    var freeParseInt = parseInt;
    var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
    var freeSelf = typeof self == "object" && self && self.Object === Object && self;
    var root = freeGlobal || freeSelf || Function("return this")();
    var freeExports = typeof exports == "object" && exports && !exports.nodeType && exports;
    var freeModule = freeExports && typeof module == "object" && module && !module.nodeType && module;
    var moduleExports = freeModule && freeModule.exports === freeExports;
    var freeProcess = moduleExports && freeGlobal.process;
    var nodeUtil = (function() {
      try {
        return freeProcess && freeProcess.binding("util");
      } catch (e) {
      }
    })();
    var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;
    function arraySome(array, predicate) {
      var index = -1, length = array ? array.length : 0;
      while (++index < length) {
        if (predicate(array[index], index, array)) {
          return true;
        }
      }
      return false;
    }
    function baseFindIndex(array, predicate, fromIndex, fromRight) {
      var length = array.length, index = fromIndex + (fromRight ? 1 : -1);
      while (fromRight ? index-- : ++index < length) {
        if (predicate(array[index], index, array)) {
          return index;
        }
      }
      return -1;
    }
    function baseProperty(key) {
      return function(object) {
        return object == null ? void 0 : object[key];
      };
    }
    function baseTimes(n, iteratee) {
      var index = -1, result = Array(n);
      while (++index < n) {
        result[index] = iteratee(index);
      }
      return result;
    }
    function baseUnary(func) {
      return function(value) {
        return func(value);
      };
    }
    function getValue(object, key) {
      return object == null ? void 0 : object[key];
    }
    function isHostObject(value) {
      var result = false;
      if (value != null && typeof value.toString != "function") {
        try {
          result = !!(value + "");
        } catch (e) {
        }
      }
      return result;
    }
    function mapToArray(map) {
      var index = -1, result = Array(map.size);
      map.forEach(function(value, key) {
        result[++index] = [key, value];
      });
      return result;
    }
    function overArg(func, transform) {
      return function(arg) {
        return func(transform(arg));
      };
    }
    function setToArray(set) {
      var index = -1, result = Array(set.size);
      set.forEach(function(value) {
        result[++index] = value;
      });
      return result;
    }
    var arrayProto = Array.prototype;
    var funcProto = Function.prototype;
    var objectProto = Object.prototype;
    var coreJsData = root["__core-js_shared__"];
    var maskSrcKey = (function() {
      var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || "");
      return uid ? "Symbol(src)_1." + uid : "";
    })();
    var funcToString = funcProto.toString;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var objectToString = objectProto.toString;
    var reIsNative = RegExp(
      "^" + funcToString.call(hasOwnProperty).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
    );
    var Symbol2 = root.Symbol;
    var Uint8Array2 = root.Uint8Array;
    var propertyIsEnumerable = objectProto.propertyIsEnumerable;
    var splice = arrayProto.splice;
    var nativeKeys = overArg(Object.keys, Object);
    var nativeMax = Math.max;
    var DataView = getNative(root, "DataView");
    var Map = getNative(root, "Map");
    var Promise2 = getNative(root, "Promise");
    var Set2 = getNative(root, "Set");
    var WeakMap = getNative(root, "WeakMap");
    var nativeCreate = getNative(Object, "create");
    var dataViewCtorString = toSource(DataView);
    var mapCtorString = toSource(Map);
    var promiseCtorString = toSource(Promise2);
    var setCtorString = toSource(Set2);
    var weakMapCtorString = toSource(WeakMap);
    var symbolProto = Symbol2 ? Symbol2.prototype : void 0;
    var symbolValueOf = symbolProto ? symbolProto.valueOf : void 0;
    var symbolToString = symbolProto ? symbolProto.toString : void 0;
    function Hash(entries) {
      var index = -1, length = entries ? entries.length : 0;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    function hashClear() {
      this.__data__ = nativeCreate ? nativeCreate(null) : {};
    }
    function hashDelete(key) {
      return this.has(key) && delete this.__data__[key];
    }
    function hashGet(key) {
      var data = this.__data__;
      if (nativeCreate) {
        var result = data[key];
        return result === HASH_UNDEFINED ? void 0 : result;
      }
      return hasOwnProperty.call(data, key) ? data[key] : void 0;
    }
    function hashHas(key) {
      var data = this.__data__;
      return nativeCreate ? data[key] !== void 0 : hasOwnProperty.call(data, key);
    }
    function hashSet(key, value) {
      var data = this.__data__;
      data[key] = nativeCreate && value === void 0 ? HASH_UNDEFINED : value;
      return this;
    }
    Hash.prototype.clear = hashClear;
    Hash.prototype["delete"] = hashDelete;
    Hash.prototype.get = hashGet;
    Hash.prototype.has = hashHas;
    Hash.prototype.set = hashSet;
    function ListCache(entries) {
      var index = -1, length = entries ? entries.length : 0;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    function listCacheClear() {
      this.__data__ = [];
    }
    function listCacheDelete(key) {
      var data = this.__data__, index = assocIndexOf(data, key);
      if (index < 0) {
        return false;
      }
      var lastIndex = data.length - 1;
      if (index == lastIndex) {
        data.pop();
      } else {
        splice.call(data, index, 1);
      }
      return true;
    }
    function listCacheGet(key) {
      var data = this.__data__, index = assocIndexOf(data, key);
      return index < 0 ? void 0 : data[index][1];
    }
    function listCacheHas(key) {
      return assocIndexOf(this.__data__, key) > -1;
    }
    function listCacheSet(key, value) {
      var data = this.__data__, index = assocIndexOf(data, key);
      if (index < 0) {
        data.push([key, value]);
      } else {
        data[index][1] = value;
      }
      return this;
    }
    ListCache.prototype.clear = listCacheClear;
    ListCache.prototype["delete"] = listCacheDelete;
    ListCache.prototype.get = listCacheGet;
    ListCache.prototype.has = listCacheHas;
    ListCache.prototype.set = listCacheSet;
    function MapCache(entries) {
      var index = -1, length = entries ? entries.length : 0;
      this.clear();
      while (++index < length) {
        var entry = entries[index];
        this.set(entry[0], entry[1]);
      }
    }
    function mapCacheClear() {
      this.__data__ = {
        "hash": new Hash(),
        "map": new (Map || ListCache)(),
        "string": new Hash()
      };
    }
    function mapCacheDelete(key) {
      return getMapData(this, key)["delete"](key);
    }
    function mapCacheGet(key) {
      return getMapData(this, key).get(key);
    }
    function mapCacheHas(key) {
      return getMapData(this, key).has(key);
    }
    function mapCacheSet(key, value) {
      getMapData(this, key).set(key, value);
      return this;
    }
    MapCache.prototype.clear = mapCacheClear;
    MapCache.prototype["delete"] = mapCacheDelete;
    MapCache.prototype.get = mapCacheGet;
    MapCache.prototype.has = mapCacheHas;
    MapCache.prototype.set = mapCacheSet;
    function SetCache(values) {
      var index = -1, length = values ? values.length : 0;
      this.__data__ = new MapCache();
      while (++index < length) {
        this.add(values[index]);
      }
    }
    function setCacheAdd(value) {
      this.__data__.set(value, HASH_UNDEFINED);
      return this;
    }
    function setCacheHas(value) {
      return this.__data__.has(value);
    }
    SetCache.prototype.add = SetCache.prototype.push = setCacheAdd;
    SetCache.prototype.has = setCacheHas;
    function Stack(entries) {
      this.__data__ = new ListCache(entries);
    }
    function stackClear() {
      this.__data__ = new ListCache();
    }
    function stackDelete(key) {
      return this.__data__["delete"](key);
    }
    function stackGet(key) {
      return this.__data__.get(key);
    }
    function stackHas(key) {
      return this.__data__.has(key);
    }
    function stackSet(key, value) {
      var cache = this.__data__;
      if (cache instanceof ListCache) {
        var pairs = cache.__data__;
        if (!Map || pairs.length < LARGE_ARRAY_SIZE - 1) {
          pairs.push([key, value]);
          return this;
        }
        cache = this.__data__ = new MapCache(pairs);
      }
      cache.set(key, value);
      return this;
    }
    Stack.prototype.clear = stackClear;
    Stack.prototype["delete"] = stackDelete;
    Stack.prototype.get = stackGet;
    Stack.prototype.has = stackHas;
    Stack.prototype.set = stackSet;
    function arrayLikeKeys(value, inherited) {
      var result = isArray(value) || isArguments(value) ? baseTimes(value.length, String) : [];
      var length = result.length, skipIndexes = !!length;
      for (var key in value) {
        if ((inherited || hasOwnProperty.call(value, key)) && !(skipIndexes && (key == "length" || isIndex(key, length)))) {
          result.push(key);
        }
      }
      return result;
    }
    function assocIndexOf(array, key) {
      var length = array.length;
      while (length--) {
        if (eq(array[length][0], key)) {
          return length;
        }
      }
      return -1;
    }
    function baseGet(object, path) {
      path = isKey(path, object) ? [path] : castPath(path);
      var index = 0, length = path.length;
      while (object != null && index < length) {
        object = object[toKey(path[index++])];
      }
      return index && index == length ? object : void 0;
    }
    function baseGetTag(value) {
      return objectToString.call(value);
    }
    function baseHasIn(object, key) {
      return object != null && key in Object(object);
    }
    function baseIsEqual(value, other, customizer, bitmask, stack) {
      if (value === other) {
        return true;
      }
      if (value == null || other == null || !isObject(value) && !isObjectLike(other)) {
        return value !== value && other !== other;
      }
      return baseIsEqualDeep(value, other, baseIsEqual, customizer, bitmask, stack);
    }
    function baseIsEqualDeep(object, other, equalFunc, customizer, bitmask, stack) {
      var objIsArr = isArray(object), othIsArr = isArray(other), objTag = arrayTag, othTag = arrayTag;
      if (!objIsArr) {
        objTag = getTag(object);
        objTag = objTag == argsTag ? objectTag : objTag;
      }
      if (!othIsArr) {
        othTag = getTag(other);
        othTag = othTag == argsTag ? objectTag : othTag;
      }
      var objIsObj = objTag == objectTag && !isHostObject(object), othIsObj = othTag == objectTag && !isHostObject(other), isSameTag = objTag == othTag;
      if (isSameTag && !objIsObj) {
        stack || (stack = new Stack());
        return objIsArr || isTypedArray(object) ? equalArrays(object, other, equalFunc, customizer, bitmask, stack) : equalByTag(object, other, objTag, equalFunc, customizer, bitmask, stack);
      }
      if (!(bitmask & PARTIAL_COMPARE_FLAG)) {
        var objIsWrapped = objIsObj && hasOwnProperty.call(object, "__wrapped__"), othIsWrapped = othIsObj && hasOwnProperty.call(other, "__wrapped__");
        if (objIsWrapped || othIsWrapped) {
          var objUnwrapped = objIsWrapped ? object.value() : object, othUnwrapped = othIsWrapped ? other.value() : other;
          stack || (stack = new Stack());
          return equalFunc(objUnwrapped, othUnwrapped, customizer, bitmask, stack);
        }
      }
      if (!isSameTag) {
        return false;
      }
      stack || (stack = new Stack());
      return equalObjects(object, other, equalFunc, customizer, bitmask, stack);
    }
    function baseIsMatch(object, source, matchData, customizer) {
      var index = matchData.length, length = index, noCustomizer = !customizer;
      if (object == null) {
        return !length;
      }
      object = Object(object);
      while (index--) {
        var data = matchData[index];
        if (noCustomizer && data[2] ? data[1] !== object[data[0]] : !(data[0] in object)) {
          return false;
        }
      }
      while (++index < length) {
        data = matchData[index];
        var key = data[0], objValue = object[key], srcValue = data[1];
        if (noCustomizer && data[2]) {
          if (objValue === void 0 && !(key in object)) {
            return false;
          }
        } else {
          var stack = new Stack();
          if (customizer) {
            var result = customizer(objValue, srcValue, key, object, source, stack);
          }
          if (!(result === void 0 ? baseIsEqual(srcValue, objValue, customizer, UNORDERED_COMPARE_FLAG | PARTIAL_COMPARE_FLAG, stack) : result)) {
            return false;
          }
        }
      }
      return true;
    }
    function baseIsNative(value) {
      if (!isObject(value) || isMasked(value)) {
        return false;
      }
      var pattern = isFunction(value) || isHostObject(value) ? reIsNative : reIsHostCtor;
      return pattern.test(toSource(value));
    }
    function baseIsTypedArray(value) {
      return isObjectLike(value) && isLength(value.length) && !!typedArrayTags[objectToString.call(value)];
    }
    function baseIteratee(value) {
      if (typeof value == "function") {
        return value;
      }
      if (value == null) {
        return identity;
      }
      if (typeof value == "object") {
        return isArray(value) ? baseMatchesProperty(value[0], value[1]) : baseMatches(value);
      }
      return property(value);
    }
    function baseKeys(object) {
      if (!isPrototype(object)) {
        return nativeKeys(object);
      }
      var result = [];
      for (var key in Object(object)) {
        if (hasOwnProperty.call(object, key) && key != "constructor") {
          result.push(key);
        }
      }
      return result;
    }
    function baseMatches(source) {
      var matchData = getMatchData(source);
      if (matchData.length == 1 && matchData[0][2]) {
        return matchesStrictComparable(matchData[0][0], matchData[0][1]);
      }
      return function(object) {
        return object === source || baseIsMatch(object, source, matchData);
      };
    }
    function baseMatchesProperty(path, srcValue) {
      if (isKey(path) && isStrictComparable(srcValue)) {
        return matchesStrictComparable(toKey(path), srcValue);
      }
      return function(object) {
        var objValue = get(object, path);
        return objValue === void 0 && objValue === srcValue ? hasIn(object, path) : baseIsEqual(srcValue, objValue, void 0, UNORDERED_COMPARE_FLAG | PARTIAL_COMPARE_FLAG);
      };
    }
    function basePropertyDeep(path) {
      return function(object) {
        return baseGet(object, path);
      };
    }
    function baseToString(value) {
      if (typeof value == "string") {
        return value;
      }
      if (isSymbol(value)) {
        return symbolToString ? symbolToString.call(value) : "";
      }
      var result = value + "";
      return result == "0" && 1 / value == -INFINITY ? "-0" : result;
    }
    function castPath(value) {
      return isArray(value) ? value : stringToPath(value);
    }
    function createFind(findIndexFunc) {
      return function(collection, predicate, fromIndex) {
        var iterable = Object(collection);
        if (!isArrayLike(collection)) {
          var iteratee = baseIteratee(predicate, 3);
          collection = keys(collection);
          predicate = function(key) {
            return iteratee(iterable[key], key, iterable);
          };
        }
        var index = findIndexFunc(collection, predicate, fromIndex);
        return index > -1 ? iterable[iteratee ? collection[index] : index] : void 0;
      };
    }
    function equalArrays(array, other, equalFunc, customizer, bitmask, stack) {
      var isPartial = bitmask & PARTIAL_COMPARE_FLAG, arrLength = array.length, othLength = other.length;
      if (arrLength != othLength && !(isPartial && othLength > arrLength)) {
        return false;
      }
      var stacked = stack.get(array);
      if (stacked && stack.get(other)) {
        return stacked == other;
      }
      var index = -1, result = true, seen = bitmask & UNORDERED_COMPARE_FLAG ? new SetCache() : void 0;
      stack.set(array, other);
      stack.set(other, array);
      while (++index < arrLength) {
        var arrValue = array[index], othValue = other[index];
        if (customizer) {
          var compared = isPartial ? customizer(othValue, arrValue, index, other, array, stack) : customizer(arrValue, othValue, index, array, other, stack);
        }
        if (compared !== void 0) {
          if (compared) {
            continue;
          }
          result = false;
          break;
        }
        if (seen) {
          if (!arraySome(other, function(othValue2, othIndex) {
            if (!seen.has(othIndex) && (arrValue === othValue2 || equalFunc(arrValue, othValue2, customizer, bitmask, stack))) {
              return seen.add(othIndex);
            }
          })) {
            result = false;
            break;
          }
        } else if (!(arrValue === othValue || equalFunc(arrValue, othValue, customizer, bitmask, stack))) {
          result = false;
          break;
        }
      }
      stack["delete"](array);
      stack["delete"](other);
      return result;
    }
    function equalByTag(object, other, tag, equalFunc, customizer, bitmask, stack) {
      switch (tag) {
        case dataViewTag:
          if (object.byteLength != other.byteLength || object.byteOffset != other.byteOffset) {
            return false;
          }
          object = object.buffer;
          other = other.buffer;
        case arrayBufferTag:
          if (object.byteLength != other.byteLength || !equalFunc(new Uint8Array2(object), new Uint8Array2(other))) {
            return false;
          }
          return true;
        case boolTag:
        case dateTag:
        case numberTag:
          return eq(+object, +other);
        case errorTag:
          return object.name == other.name && object.message == other.message;
        case regexpTag:
        case stringTag:
          return object == other + "";
        case mapTag:
          var convert = mapToArray;
        case setTag:
          var isPartial = bitmask & PARTIAL_COMPARE_FLAG;
          convert || (convert = setToArray);
          if (object.size != other.size && !isPartial) {
            return false;
          }
          var stacked = stack.get(object);
          if (stacked) {
            return stacked == other;
          }
          bitmask |= UNORDERED_COMPARE_FLAG;
          stack.set(object, other);
          var result = equalArrays(convert(object), convert(other), equalFunc, customizer, bitmask, stack);
          stack["delete"](object);
          return result;
        case symbolTag:
          if (symbolValueOf) {
            return symbolValueOf.call(object) == symbolValueOf.call(other);
          }
      }
      return false;
    }
    function equalObjects(object, other, equalFunc, customizer, bitmask, stack) {
      var isPartial = bitmask & PARTIAL_COMPARE_FLAG, objProps = keys(object), objLength = objProps.length, othProps = keys(other), othLength = othProps.length;
      if (objLength != othLength && !isPartial) {
        return false;
      }
      var index = objLength;
      while (index--) {
        var key = objProps[index];
        if (!(isPartial ? key in other : hasOwnProperty.call(other, key))) {
          return false;
        }
      }
      var stacked = stack.get(object);
      if (stacked && stack.get(other)) {
        return stacked == other;
      }
      var result = true;
      stack.set(object, other);
      stack.set(other, object);
      var skipCtor = isPartial;
      while (++index < objLength) {
        key = objProps[index];
        var objValue = object[key], othValue = other[key];
        if (customizer) {
          var compared = isPartial ? customizer(othValue, objValue, key, other, object, stack) : customizer(objValue, othValue, key, object, other, stack);
        }
        if (!(compared === void 0 ? objValue === othValue || equalFunc(objValue, othValue, customizer, bitmask, stack) : compared)) {
          result = false;
          break;
        }
        skipCtor || (skipCtor = key == "constructor");
      }
      if (result && !skipCtor) {
        var objCtor = object.constructor, othCtor = other.constructor;
        if (objCtor != othCtor && ("constructor" in object && "constructor" in other) && !(typeof objCtor == "function" && objCtor instanceof objCtor && typeof othCtor == "function" && othCtor instanceof othCtor)) {
          result = false;
        }
      }
      stack["delete"](object);
      stack["delete"](other);
      return result;
    }
    function getMapData(map, key) {
      var data = map.__data__;
      return isKeyable(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
    }
    function getMatchData(object) {
      var result = keys(object), length = result.length;
      while (length--) {
        var key = result[length], value = object[key];
        result[length] = [key, value, isStrictComparable(value)];
      }
      return result;
    }
    function getNative(object, key) {
      var value = getValue(object, key);
      return baseIsNative(value) ? value : void 0;
    }
    var getTag = baseGetTag;
    if (DataView && getTag(new DataView(new ArrayBuffer(1))) != dataViewTag || Map && getTag(new Map()) != mapTag || Promise2 && getTag(Promise2.resolve()) != promiseTag || Set2 && getTag(new Set2()) != setTag || WeakMap && getTag(new WeakMap()) != weakMapTag) {
      getTag = function(value) {
        var result = objectToString.call(value), Ctor = result == objectTag ? value.constructor : void 0, ctorString = Ctor ? toSource(Ctor) : void 0;
        if (ctorString) {
          switch (ctorString) {
            case dataViewCtorString:
              return dataViewTag;
            case mapCtorString:
              return mapTag;
            case promiseCtorString:
              return promiseTag;
            case setCtorString:
              return setTag;
            case weakMapCtorString:
              return weakMapTag;
          }
        }
        return result;
      };
    }
    function hasPath(object, path, hasFunc) {
      path = isKey(path, object) ? [path] : castPath(path);
      var result, index = -1, length = path.length;
      while (++index < length) {
        var key = toKey(path[index]);
        if (!(result = object != null && hasFunc(object, key))) {
          break;
        }
        object = object[key];
      }
      if (result) {
        return result;
      }
      var length = object ? object.length : 0;
      return !!length && isLength(length) && isIndex(key, length) && (isArray(object) || isArguments(object));
    }
    function isIndex(value, length) {
      length = length == null ? MAX_SAFE_INTEGER : length;
      return !!length && (typeof value == "number" || reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
    }
    function isKey(value, object) {
      if (isArray(value)) {
        return false;
      }
      var type = typeof value;
      if (type == "number" || type == "symbol" || type == "boolean" || value == null || isSymbol(value)) {
        return true;
      }
      return reIsPlainProp.test(value) || !reIsDeepProp.test(value) || object != null && value in Object(object);
    }
    function isKeyable(value) {
      var type = typeof value;
      return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
    }
    function isMasked(func) {
      return !!maskSrcKey && maskSrcKey in func;
    }
    function isPrototype(value) {
      var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto;
      return value === proto;
    }
    function isStrictComparable(value) {
      return value === value && !isObject(value);
    }
    function matchesStrictComparable(key, srcValue) {
      return function(object) {
        if (object == null) {
          return false;
        }
        return object[key] === srcValue && (srcValue !== void 0 || key in Object(object));
      };
    }
    var stringToPath = memoize(function(string) {
      string = toString(string);
      var result = [];
      if (reLeadingDot.test(string)) {
        result.push("");
      }
      string.replace(rePropName, function(match, number, quote, string2) {
        result.push(quote ? string2.replace(reEscapeChar, "$1") : number || match);
      });
      return result;
    });
    function toKey(value) {
      if (typeof value == "string" || isSymbol(value)) {
        return value;
      }
      var result = value + "";
      return result == "0" && 1 / value == -INFINITY ? "-0" : result;
    }
    function toSource(func) {
      if (func != null) {
        try {
          return funcToString.call(func);
        } catch (e) {
        }
        try {
          return func + "";
        } catch (e) {
        }
      }
      return "";
    }
    function findIndex(array, predicate, fromIndex) {
      var length = array ? array.length : 0;
      if (!length) {
        return -1;
      }
      var index = fromIndex == null ? 0 : toInteger(fromIndex);
      if (index < 0) {
        index = nativeMax(length + index, 0);
      }
      return baseFindIndex(array, baseIteratee(predicate, 3), index);
    }
    var find = createFind(findIndex);
    function memoize(func, resolver) {
      if (typeof func != "function" || resolver && typeof resolver != "function") {
        throw new TypeError(FUNC_ERROR_TEXT);
      }
      var memoized = function() {
        var args = arguments, key = resolver ? resolver.apply(this, args) : args[0], cache = memoized.cache;
        if (cache.has(key)) {
          return cache.get(key);
        }
        var result = func.apply(this, args);
        memoized.cache = cache.set(key, result);
        return result;
      };
      memoized.cache = new (memoize.Cache || MapCache)();
      return memoized;
    }
    memoize.Cache = MapCache;
    function eq(value, other) {
      return value === other || value !== value && other !== other;
    }
    function isArguments(value) {
      return isArrayLikeObject(value) && hasOwnProperty.call(value, "callee") && (!propertyIsEnumerable.call(value, "callee") || objectToString.call(value) == argsTag);
    }
    var isArray = Array.isArray;
    function isArrayLike(value) {
      return value != null && isLength(value.length) && !isFunction(value);
    }
    function isArrayLikeObject(value) {
      return isObjectLike(value) && isArrayLike(value);
    }
    function isFunction(value) {
      var tag = isObject(value) ? objectToString.call(value) : "";
      return tag == funcTag || tag == genTag;
    }
    function isLength(value) {
      return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
    }
    function isObject(value) {
      var type = typeof value;
      return !!value && (type == "object" || type == "function");
    }
    function isObjectLike(value) {
      return !!value && typeof value == "object";
    }
    function isSymbol(value) {
      return typeof value == "symbol" || isObjectLike(value) && objectToString.call(value) == symbolTag;
    }
    var isTypedArray = nodeIsTypedArray ? baseUnary(nodeIsTypedArray) : baseIsTypedArray;
    function toFinite(value) {
      if (!value) {
        return value === 0 ? value : 0;
      }
      value = toNumber(value);
      if (value === INFINITY || value === -INFINITY) {
        var sign = value < 0 ? -1 : 1;
        return sign * MAX_INTEGER;
      }
      return value === value ? value : 0;
    }
    function toInteger(value) {
      var result = toFinite(value), remainder = result % 1;
      return result === result ? remainder ? result - remainder : result : 0;
    }
    function toNumber(value) {
      if (typeof value == "number") {
        return value;
      }
      if (isSymbol(value)) {
        return NAN;
      }
      if (isObject(value)) {
        var other = typeof value.valueOf == "function" ? value.valueOf() : value;
        value = isObject(other) ? other + "" : other;
      }
      if (typeof value != "string") {
        return value === 0 ? value : +value;
      }
      value = value.replace(reTrim, "");
      var isBinary = reIsBinary.test(value);
      return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
    }
    function toString(value) {
      return value == null ? "" : baseToString(value);
    }
    function get(object, path, defaultValue) {
      var result = object == null ? void 0 : baseGet(object, path);
      return result === void 0 ? defaultValue : result;
    }
    function hasIn(object, path) {
      return object != null && hasPath(object, path, baseHasIn);
    }
    function keys(object) {
      return isArrayLike(object) ? arrayLikeKeys(object) : baseKeys(object);
    }
    function identity(value) {
      return value;
    }
    function property(path) {
      return isKey(path) ? baseProperty(toKey(path)) : basePropertyDeep(path);
    }
    module.exports = find;
  }
});

// node_modules/lodash.max/index.js
var require_lodash5 = __commonJS({
  "node_modules/lodash.max/index.js"(exports, module) {
    var symbolTag = "[object Symbol]";
    var objectProto = Object.prototype;
    var objectToString = objectProto.toString;
    function baseExtremum(array, iteratee, comparator) {
      var index = -1, length = array.length;
      while (++index < length) {
        var value = array[index], current = iteratee(value);
        if (current != null && (computed === void 0 ? current === current && !isSymbol(current) : comparator(current, computed))) {
          var computed = current, result = value;
        }
      }
      return result;
    }
    function baseGt(value, other) {
      return value > other;
    }
    function isObjectLike(value) {
      return !!value && typeof value == "object";
    }
    function isSymbol(value) {
      return typeof value == "symbol" || isObjectLike(value) && objectToString.call(value) == symbolTag;
    }
    function identity(value) {
      return value;
    }
    function max(array) {
      return array && array.length ? baseExtremum(array, identity, baseGt) : void 0;
    }
    module.exports = max;
  }
});

// node_modules/ip-address/lib/v6/constants.js
var require_constants2 = __commonJS({
  "node_modules/ip-address/lib/v6/constants.js"(exports) {
    exports.BITS = 128;
    exports.GROUPS = 8;
    exports.SCOPES = {
      0: "Reserved",
      1: "Interface local",
      2: "Link local",
      4: "Admin local",
      5: "Site local",
      8: "Organization local",
      14: "Global",
      15: "Reserved"
    };
    exports.TYPES = {
      "ff01::1/128": "Multicast (All nodes on this interface)",
      "ff01::2/128": "Multicast (All routers on this interface)",
      "ff02::1/128": "Multicast (All nodes on this link)",
      "ff02::2/128": "Multicast (All routers on this link)",
      "ff05::2/128": "Multicast (All routers in this site)",
      "ff02::5/128": "Multicast (OSPFv3 AllSPF routers)",
      "ff02::6/128": "Multicast (OSPFv3 AllDR routers)",
      "ff02::9/128": "Multicast (RIP routers)",
      "ff02::a/128": "Multicast (EIGRP routers)",
      "ff02::d/128": "Multicast (PIM routers)",
      "ff02::16/128": "Multicast (MLDv2 reports)",
      "ff01::fb/128": "Multicast (mDNSv6)",
      "ff02::fb/128": "Multicast (mDNSv6)",
      "ff05::fb/128": "Multicast (mDNSv6)",
      "ff02::1:2/128": "Multicast (All DHCP servers and relay agents on this link)",
      "ff05::1:2/128": "Multicast (All DHCP servers and relay agents in this site)",
      "ff02::1:3/128": "Multicast (All DHCP servers on this link)",
      "ff05::1:3/128": "Multicast (All DHCP servers in this site)",
      "::/128": "Unspecified",
      "::1/128": "Loopback",
      "ff00::/8": "Multicast",
      "fe80::/10": "Link-local unicast"
    };
    exports.RE_BAD_CHARACTERS = /([^0-9a-f:\/%])/ig;
    exports.RE_BAD_ADDRESS = /([0-9a-f]{5,}|:{3,}|[^:]:$|^:[^:]|\/$)/ig;
    exports.RE_SUBNET_STRING = /\/\d{1,3}(?=%|$)/;
    exports.RE_ZONE_STRING = /%.*$/;
    exports.RE_URL = new RegExp(/^\[{0,1}([0-9a-f:]+)\]{0,1}/);
    exports.RE_URL_WITH_PORT = new RegExp(/\[([0-9a-f:]+)\]:([0-9]{1,5})/);
  }
});

// node_modules/ip-address/lib/v6/attributes.js
var require_attributes = __commonJS({
  "node_modules/ip-address/lib/v6/attributes.js"(exports) {
    "use strict";
    var common = require_common2();
    var v6 = require_constants2();
    exports.isValid = function() {
      return this.valid;
    };
    exports.isInSubnet = common.isInSubnet;
    exports.isCorrect = common.isCorrect(v6.BITS);
    exports.isCanonical = common.falseIfInvalid(function() {
      return this.addressMinusSuffix === this.canonicalForm();
    });
    exports.isLinkLocal = common.falseIfInvalid(function() {
      if (this.getBitsBase2(0, 64) === "1111111010000000000000000000000000000000000000000000000000000000") {
        return true;
      }
      return false;
    });
    exports.isMulticast = common.falseIfInvalid(function() {
      return this.getType() === "Multicast";
    });
    exports.is4 = common.falseIfInvalid(function() {
      return this.v4;
    });
    exports.isTeredo = common.falseIfInvalid(function() {
      return this.isInSubnet(new this.constructor("2001::/32"));
    });
    exports.is6to4 = common.falseIfInvalid(function() {
      return this.isInSubnet(new this.constructor("2002::/16"));
    });
    exports.isLoopback = common.falseIfInvalid(function() {
      return this.getType() === "Loopback";
    });
  }
});

// node_modules/ip-address/lib/v6/helpers.js
var require_helpers = __commonJS({
  "node_modules/ip-address/lib/v6/helpers.js"(exports) {
    "use strict";
    var sprintf = require_sprintf().sprintf;
    var spanAllZeroes = exports.spanAllZeroes = function(s) {
      return s.replace(/(0+)/g, '<span class="zero">$1</span>');
    };
    exports.spanAll = function(s, optionalOffset) {
      if (optionalOffset === void 0) {
        optionalOffset = 0;
      }
      var letters = s.split("");
      return letters.map(function(n, i) {
        return sprintf(
          '<span class="digit value-%s position-%d">%s</span>',
          n,
          i + optionalOffset,
          spanAllZeroes(n)
        );
      }).join("");
    };
    function spanLeadingZeroesSimple(group) {
      return group.replace(/^(0+)/, '<span class="zero">$1</span>');
    }
    exports.spanLeadingZeroes = function(address) {
      var groups = address.split(":");
      return groups.map(function(g) {
        return spanLeadingZeroesSimple(g);
      }).join(":");
    };
    exports.simpleGroup = function(addressString, offset) {
      var groups = addressString.split(":");
      if (!offset) {
        offset = 0;
      }
      return groups.map(function(g, i) {
        if (/group-v4/.test(g)) {
          return g;
        }
        return sprintf(
          '<span class="hover-group group-%d">%s</span>',
          i + offset,
          spanLeadingZeroesSimple(g)
        );
      }).join(":");
    };
  }
});

// node_modules/ip-address/lib/v6/html.js
var require_html = __commonJS({
  "node_modules/ip-address/lib/v6/html.js"(exports) {
    "use strict";
    var constants4 = require_constants();
    var helpers = require_helpers();
    var sprintf = require_sprintf().sprintf;
    exports.href = function(optionalPort) {
      if (optionalPort === void 0) {
        optionalPort = "";
      } else {
        optionalPort = sprintf(":%s", optionalPort);
      }
      return sprintf("http://[%s]%s/", this.correctForm(), optionalPort);
    };
    exports.link = function(options) {
      if (!options) {
        options = {};
      }
      if (options.className === void 0) {
        options.className = "";
      }
      if (options.prefix === void 0) {
        options.prefix = "/#address=";
      }
      if (options.v4 === void 0) {
        options.v4 = false;
      }
      var formFunction = this.correctForm;
      if (options.v4) {
        formFunction = this.to4in6;
      }
      if (options.className) {
        return sprintf(
          '<a href="%1$s%2$s" class="%3$s">%2$s</a>',
          options.prefix,
          formFunction.call(this),
          options.className
        );
      }
      return sprintf(
        '<a href="%1$s%2$s">%2$s</a>',
        options.prefix,
        formFunction.call(this)
      );
    };
    exports.group = function() {
      var address4 = this.address.match(constants4.RE_ADDRESS);
      var i;
      if (address4) {
        var segments = address4[0].split(".");
        this.address = this.address.replace(
          constants4.RE_ADDRESS,
          sprintf(
            '<span class="hover-group group-v4 group-6">%s</span>.<span class="hover-group group-v4 group-7">%s</span>',
            segments.slice(0, 2).join("."),
            segments.slice(2, 4).join(".")
          )
        );
      }
      if (this.elidedGroups === 0) {
        return helpers.simpleGroup(this.address);
      }
      var output = [];
      var halves = this.address.split("::");
      if (halves[0].length) {
        output.push(helpers.simpleGroup(halves[0]));
      } else {
        output.push("");
      }
      var classes = ["hover-group"];
      for (i = this.elisionBegin; i < this.elisionBegin + this.elidedGroups; i++) {
        classes.push(sprintf("group-%d", i));
      }
      output.push(sprintf('<span class="%s"></span>', classes.join(" ")));
      if (halves[1].length) {
        output.push(helpers.simpleGroup(halves[1], this.elisionEnd));
      } else {
        output.push("");
      }
      return output.join(":");
    };
  }
});

// node_modules/ip-address/lib/v6/regular-expressions.js
var require_regular_expressions = __commonJS({
  "node_modules/ip-address/lib/v6/regular-expressions.js"(exports) {
    "use strict";
    var sprintf = require_sprintf().sprintf;
    var v6 = require_constants2();
    function groupPossibilities(possibilities) {
      return sprintf("(%s)", possibilities.join("|"));
    }
    function padGroup(group) {
      if (group.length < 4) {
        return sprintf("0{0,%d}%s", 4 - group.length, group);
      }
      return group;
    }
    var ADDRESS_BOUNDARY = "[^A-Fa-f0-9:]";
    function simpleRegularExpression(groups) {
      var zeroIndexes = [];
      groups.forEach(function(group, i) {
        var groupInteger = parseInt(group, 16);
        if (groupInteger === 0) {
          zeroIndexes.push(i);
        }
      });
      var possibilities = zeroIndexes.map(function(zeroIndex) {
        return groups.map(function(group, i) {
          if (i === zeroIndex) {
            var elision = i === 0 || i === v6.GROUPS - 1 ? ":" : "";
            return groupPossibilities([padGroup(group), elision]);
          }
          return padGroup(group);
        }).join(":");
      });
      possibilities.push(groups.map(padGroup).join(":"));
      return groupPossibilities(possibilities);
    }
    function possibleElisions(elidedGroups, moreLeft, moreRight) {
      var left = moreLeft ? "" : ":";
      var right = moreRight ? "" : ":";
      var possibilities = [];
      if (!moreLeft && !moreRight) {
        possibilities.push("::");
      }
      if (moreLeft && moreRight) {
        possibilities.push("");
      }
      if (moreRight && !moreLeft || !moreRight && moreLeft) {
        possibilities.push(":");
      }
      possibilities.push(sprintf("%s(:0{1,4}){1,%d}", left, elidedGroups - 1));
      possibilities.push(sprintf("(0{1,4}:){1,%d}%s", elidedGroups - 1, right));
      possibilities.push(sprintf("(0{1,4}:){%d}0{1,4}", elidedGroups - 1));
      for (var groups = 1; groups < elidedGroups - 1; groups++) {
        for (var position = 1; position < elidedGroups - groups; position++) {
          possibilities.push(sprintf(
            "(0{1,4}:){%d}:(0{1,4}:){%d}0{1,4}",
            position,
            elidedGroups - position - groups - 1
          ));
        }
      }
      return groupPossibilities(possibilities);
    }
    exports.regularExpressionString = function(optionalSubString) {
      if (optionalSubString === void 0) {
        optionalSubString = false;
      }
      var output = [];
      var address6 = new this.constructor(this.correctForm());
      if (address6.elidedGroups === 0) {
        output.push(simpleRegularExpression(address6.parsedAddress));
      } else if (address6.elidedGroups === v6.GROUPS) {
        output.push(possibleElisions(v6.GROUPS));
      } else {
        var halves = address6.address.split("::");
        if (halves[0].length) {
          output.push(simpleRegularExpression(halves[0].split(":")));
        }
        output.push(possibleElisions(
          address6.elidedGroups,
          halves[0].length !== 0,
          halves[1].length !== 0
        ));
        if (halves[1].length) {
          output.push(simpleRegularExpression(halves[1].split(":")));
        }
        output = [output.join(":")];
      }
      if (!optionalSubString) {
        output = [].concat(
          "(?=^|",
          ADDRESS_BOUNDARY,
          "|[^\\w\\:])(",
          output,
          ")(?=[^\\w\\:]|",
          ADDRESS_BOUNDARY,
          "|$)"
        );
      }
      return output.join("");
    };
    exports.regularExpression = function(optionalSubstring) {
      return new RegExp(this.regularExpressionString(optionalSubstring), "i");
    };
  }
});

// node_modules/ip-address/lib/ipv6.js
var require_ipv6 = __commonJS({
  "node_modules/ip-address/lib/ipv6.js"(exports, module) {
    "use strict";
    var BigInteger = require_jsbn().BigInteger;
    var sprintf = require_sprintf().sprintf;
    var merge = require_lodash3();
    var padStart = require_lodash();
    var repeat = require_lodash2();
    var find = require_lodash4();
    var max = require_lodash5();
    var constants4 = require_constants();
    var constants6 = require_constants2();
    var Address4 = require_ipv4();
    function addCommas(number) {
      var r = /(\d+)(\d{3})/;
      while (r.test(number)) {
        number = number.replace(r, "$1,$2");
      }
      return number;
    }
    function spanLeadingZeroes4(n) {
      n = n.replace(/^(0{1,})([1-9]+)$/, '<span class="parse-error">$1</span>$2');
      n = n.replace(/^(0{1,})(0)$/, '<span class="parse-error">$1</span>$2');
      return n;
    }
    function Address6(address, optionalGroups) {
      if (optionalGroups === void 0) {
        this.groups = constants6.GROUPS;
      } else {
        this.groups = optionalGroups;
      }
      this.v4 = false;
      this.subnet = "/128";
      this.subnetMask = 128;
      this.zone = "";
      this.address = address;
      var subnet = constants6.RE_SUBNET_STRING.exec(address);
      if (subnet) {
        this.parsedSubnet = subnet[0].replace("/", "");
        this.subnetMask = parseInt(this.parsedSubnet, 10);
        this.subnet = "/" + this.subnetMask;
        if (isNaN(this.subnetMask) || this.subnetMask < 0 || this.subnetMask > constants6.BITS) {
          this.valid = false;
          this.error = "Invalid subnet mask.";
          return;
        }
        address = address.replace(constants6.RE_SUBNET_STRING, "");
      } else if (/\//.test(address)) {
        this.valid = false;
        this.error = "Invalid subnet mask.";
        return;
      }
      var zone = constants6.RE_ZONE_STRING.exec(address);
      if (zone) {
        this.zone = zone[0];
        address = address.replace(constants6.RE_ZONE_STRING, "");
      }
      this.addressMinusSuffix = address;
      this.parsedAddress = this.parse(this.addressMinusSuffix);
    }
    merge(Address6.prototype, require_attributes());
    merge(Address6.prototype, require_html());
    merge(Address6.prototype, require_regular_expressions());
    Address6.fromBigInteger = function(bigInteger) {
      var hex = padStart(bigInteger.toString(16), 32, "0");
      var groups = [];
      var i;
      for (i = 0; i < constants6.GROUPS; i++) {
        groups.push(hex.slice(i * 4, (i + 1) * 4));
      }
      return new Address6(groups.join(":"));
    };
    Address6.fromURL = function(url) {
      var host;
      var port;
      var result;
      if (url.indexOf("[") !== -1 && url.indexOf("]:") !== -1) {
        result = constants6.RE_URL_WITH_PORT.exec(url);
        if (result === null) {
          return {
            error: "failed to parse address with port",
            address: null,
            port: null
          };
        }
        host = result[1];
        port = result[2];
      } else if (url.indexOf("/") !== -1) {
        url = url.replace(/^[a-z0-9]+:\/\//, "");
        result = constants6.RE_URL.exec(url);
        if (result === null) {
          return {
            error: "failed to parse address from URL",
            address: null,
            port: null
          };
        }
        host = result[1];
      } else {
        host = url;
      }
      if (port) {
        port = parseInt(port, 10);
        if (port < 0 || port > 65536) {
          port = null;
        }
      } else {
        port = null;
      }
      return {
        address: new Address6(host),
        port
      };
    };
    Address6.fromAddress4 = function(address4) {
      var address4 = new Address4(address4);
      var mask6 = constants6.BITS - (constants4.BITS - address4.subnetMask);
      return new Address6("::ffff:" + address4.correctForm() + "/" + mask6);
    };
    Address6.fromArpa = function(arpaFormAddress) {
      var address = arpaFormAddress.replace(/(\.ip6\.arpa)?\.$/, "");
      var semicolonAmount = 7;
      if (address.length !== 63) {
        address = {
          error: "Not Valid 'ip6.arpa' form",
          address: null
        };
        return address;
      }
      address = address.split(".").reverse();
      for (var i = semicolonAmount; i > 0; i--) {
        var insertIndex = i * 4;
        address.splice(insertIndex, 0, ":");
      }
      address = address.join("");
      return new Address6(address);
    };
    function compact(address, slice) {
      var s1 = [];
      var s2 = [];
      var i;
      for (i = 0; i < address.length; i++) {
        if (i < slice[0]) {
          s1.push(address[i]);
        } else if (i > slice[1]) {
          s2.push(address[i]);
        }
      }
      return s1.concat(["compact"]).concat(s2);
    }
    Address6.prototype.microsoftTranscription = function() {
      return sprintf(
        "%s.ipv6-literal.net",
        this.correctForm().replace(/:/g, "-")
      );
    };
    Address6.prototype.mask = function(optionalMask) {
      if (optionalMask === void 0) {
        optionalMask = this.subnetMask;
      }
      return this.getBitsBase2(0, optionalMask);
    };
    Address6.prototype.possibleSubnets = function(optionalSubnetSize) {
      if (optionalSubnetSize === void 0) {
        optionalSubnetSize = 128;
      }
      var availableBits = constants6.BITS - this.subnetMask;
      var subnetBits = Math.abs(optionalSubnetSize - constants6.BITS);
      var subnetPowers = availableBits - subnetBits;
      if (subnetPowers < 0) {
        return "0";
      }
      return addCommas(new BigInteger("2", 10).pow(subnetPowers).toString(10));
    };
    Address6.prototype._startAddress = function() {
      return new BigInteger(
        this.mask() + repeat("0", constants6.BITS - this.subnetMask),
        2
      );
    };
    Address6.prototype.startAddress = function() {
      return Address6.fromBigInteger(this._startAddress());
    };
    Address6.prototype.startAddressExclusive = function() {
      var adjust = new BigInteger("1");
      return Address6.fromBigInteger(this._startAddress().add(adjust));
    };
    Address6.prototype._endAddress = function() {
      return new BigInteger(
        this.mask() + repeat("1", constants6.BITS - this.subnetMask),
        2
      );
    };
    Address6.prototype.endAddress = function() {
      return Address6.fromBigInteger(this._endAddress());
    };
    Address6.prototype.endAddressExclusive = function() {
      var adjust = new BigInteger("1");
      return Address6.fromBigInteger(this._endAddress().subtract(adjust));
    };
    Address6.prototype.getScope = function() {
      var scope = constants6.SCOPES[this.getBits(12, 16)];
      if (this.getType() === "Global unicast" && scope !== "Link local") {
        scope = "Global";
      }
      return scope;
    };
    Address6.prototype.getType = function() {
      var self2 = this;
      function isType(name, type) {
        return self2.isInSubnet(new Address6(type));
      }
      return find(constants6.TYPES, isType) || "Global unicast";
    };
    Address6.prototype.getBits = function(start, end) {
      return new BigInteger(this.getBitsBase2(start, end), 2);
    };
    Address6.prototype.getBitsBase2 = function(start, end) {
      return this.binaryZeroPad().slice(start, end);
    };
    Address6.prototype.getBitsBase16 = function(start, end) {
      var length = end - start;
      if (length % 4 !== 0) {
        return null;
      }
      return padStart(this.getBits(start, end).toString(16), length / 4, "0");
    };
    Address6.prototype.getBitsPastSubnet = function() {
      return this.getBitsBase2(this.subnetMask, constants6.BITS);
    };
    Address6.prototype.reverseForm = function(options) {
      if (!options) {
        options = {};
      }
      var characters = Math.floor(this.subnetMask / 4);
      var reversed = this.canonicalForm().replace(/:/g, "").split("").slice(0, characters).reverse().join(".");
      if (characters > 0) {
        if (options.omitSuffix) {
          return reversed;
        }
        return sprintf("%s.ip6.arpa.", reversed);
      }
      if (options.omitSuffix) {
        return "";
      }
      return "ip6.arpa.";
    };
    Address6.prototype.correctForm = function() {
      if (!this.parsedAddress) {
        return null;
      }
      var i;
      var groups = [];
      var zeroCounter = 0;
      var zeroes = [];
      for (i = 0; i < this.parsedAddress.length; i++) {
        var value = parseInt(this.parsedAddress[i], 16);
        if (value === 0) {
          zeroCounter++;
        }
        if (value !== 0 && zeroCounter > 0) {
          if (zeroCounter > 1) {
            zeroes.push([i - zeroCounter, i - 1]);
          }
          zeroCounter = 0;
        }
      }
      if (zeroCounter > 1) {
        zeroes.push([
          this.parsedAddress.length - zeroCounter,
          this.parsedAddress.length - 1
        ]);
      }
      var zeroLengths = zeroes.map(function(n) {
        return n[1] - n[0] + 1;
      });
      if (zeroes.length > 0) {
        var index = zeroLengths.indexOf(max(zeroLengths));
        groups = compact(this.parsedAddress, zeroes[index]);
      } else {
        groups = this.parsedAddress;
      }
      for (i = 0; i < groups.length; i++) {
        if (groups[i] !== "compact") {
          groups[i] = parseInt(groups[i], 16).toString(16);
        }
      }
      var correct = groups.join(":");
      correct = correct.replace(/^compact$/, "::");
      correct = correct.replace(/^compact|compact$/, ":");
      correct = correct.replace(/compact/, "");
      return correct;
    };
    Address6.prototype.binaryZeroPad = function() {
      return padStart(this.bigInteger().toString(2), constants6.BITS, "0");
    };
    Address6.prototype.parse4in6 = function(address) {
      var groups = address.split(":");
      var lastGroup = groups.slice(-1)[0];
      var address4 = lastGroup.match(constants4.RE_ADDRESS);
      if (address4) {
        var temp4 = new Address4(address4[0]);
        for (var i = 0; i < temp4.groups; i++) {
          if (/^0[0-9]+/.test(temp4.parsedAddress[i])) {
            this.valid = false;
            this.error = "IPv4 addresses can not have leading zeroes.";
            this.parseError = address.replace(
              constants4.RE_ADDRESS,
              temp4.parsedAddress.map(spanLeadingZeroes4).join(".")
            );
            return null;
          }
        }
        this.v4 = true;
        groups[groups.length - 1] = temp4.toGroup6();
        address = groups.join(":");
      }
      return address;
    };
    Address6.prototype.parse = function(address) {
      address = this.parse4in6(address);
      if (this.error) {
        return null;
      }
      var badCharacters = address.match(constants6.RE_BAD_CHARACTERS);
      if (badCharacters) {
        this.valid = false;
        this.error = sprintf(
          "Bad character%s detected in address: %s",
          badCharacters.length > 1 ? "s" : "",
          badCharacters.join("")
        );
        this.parseError = address.replace(
          constants6.RE_BAD_CHARACTERS,
          '<span class="parse-error">$1</span>'
        );
        return null;
      }
      var badAddress = address.match(constants6.RE_BAD_ADDRESS);
      if (badAddress) {
        this.valid = false;
        this.error = sprintf("Address failed regex: %s", badAddress.join(""));
        this.parseError = address.replace(
          constants6.RE_BAD_ADDRESS,
          '<span class="parse-error">$1</span>'
        );
        return null;
      }
      var groups = [];
      var halves = address.split("::");
      if (halves.length === 2) {
        var first = halves[0].split(":");
        var last = halves[1].split(":");
        if (first.length === 1 && first[0] === "") {
          first = [];
        }
        if (last.length === 1 && last[0] === "") {
          last = [];
        }
        var remaining = this.groups - (first.length + last.length);
        if (!remaining) {
          this.valid = false;
          this.error = "Error parsing groups";
          return null;
        }
        this.elidedGroups = remaining;
        this.elisionBegin = first.length;
        this.elisionEnd = first.length + this.elidedGroups;
        first.forEach(function(group) {
          groups.push(group);
        });
        for (var i = 0; i < remaining; i++) {
          groups.push(0);
        }
        last.forEach(function(group) {
          groups.push(group);
        });
      } else if (halves.length === 1) {
        groups = address.split(":");
        this.elidedGroups = 0;
      } else {
        this.valid = false;
        this.error = "Too many :: groups found";
        return null;
      }
      groups = groups.map(function(g) {
        return sprintf("%x", parseInt(g, 16));
      });
      if (groups.length !== this.groups) {
        this.valid = false;
        this.error = "Incorrect number of groups found";
        return null;
      }
      this.valid = true;
      return groups;
    };
    function paddedHex(octet) {
      return sprintf("%04x", parseInt(octet, 16));
    }
    Address6.prototype.canonicalForm = function() {
      if (!this.valid) {
        return null;
      }
      return this.parsedAddress.map(paddedHex).join(":");
    };
    Address6.prototype.decimal = function() {
      if (!this.valid) {
        return null;
      }
      return this.parsedAddress.map(function(n) {
        return sprintf("%05d", parseInt(n, 16));
      }).join(":");
    };
    Address6.prototype.bigInteger = function() {
      if (!this.valid) {
        return null;
      }
      return new BigInteger(this.parsedAddress.map(paddedHex).join(""), 16);
    };
    Address6.prototype.to4 = function() {
      var binary = this.binaryZeroPad().split("");
      return Address4.fromHex(new BigInteger(binary.slice(96, 128).join(""), 2).toString(16));
    };
    Address6.prototype.to4in6 = function() {
      var address4 = this.to4();
      var address6 = new Address6(this.parsedAddress.slice(0, 6).join(":"), 6);
      var correct = address6.correctForm();
      var infix = "";
      if (!/:$/.test(correct)) {
        infix = ":";
      }
      return address6.correctForm() + infix + address4.address;
    };
    Address6.prototype.inspectTeredo = function() {
      var prefix = this.getBitsBase16(0, 32);
      var udpPort = this.getBits(80, 96).xor(new BigInteger("ffff", 16)).toString();
      var server4 = Address4.fromHex(this.getBitsBase16(32, 64));
      var client4 = Address4.fromHex(this.getBits(96, 128).xor(new BigInteger("ffffffff", 16)).toString(16));
      var flags = this.getBits(64, 80);
      var flagsBase2 = this.getBitsBase2(64, 80);
      var coneNat = flags.testBit(15);
      var reserved = flags.testBit(14);
      var groupIndividual = flags.testBit(8);
      var universalLocal = flags.testBit(9);
      var nonce = new BigInteger(flagsBase2.slice(2, 6) + flagsBase2.slice(8, 16), 2).toString(10);
      return {
        prefix: sprintf("%s:%s", prefix.slice(0, 4), prefix.slice(4, 8)),
        server4: server4.address,
        client4: client4.address,
        flags: flagsBase2,
        coneNat,
        microsoft: {
          reserved,
          universalLocal,
          groupIndividual,
          nonce
        },
        udpPort
      };
    };
    Address6.prototype.inspect6to4 = function() {
      var prefix = this.getBitsBase16(0, 16);
      var gateway = Address4.fromHex(this.getBitsBase16(16, 48));
      return {
        prefix: sprintf("%s", prefix.slice(0, 4)),
        gateway: gateway.address
      };
    };
    Address6.prototype.to6to4 = function() {
      if (!this.is4()) {
        return null;
      }
      var addr6to4 = [
        "2002",
        this.getBitsBase16(96, 112),
        this.getBitsBase16(112, 128),
        "",
        "/16"
      ].join(":");
      return new Address6(addr6to4);
    };
    Address6.prototype.toByteArray = function() {
      var byteArray = this.bigInteger().toByteArray();
      if (byteArray.length === 17 && byteArray[0] === 0) {
        return byteArray.slice(1);
      }
      return byteArray;
    };
    function unsignByte(b) {
      return b & 255;
    }
    Address6.prototype.toUnsignedByteArray = function() {
      return this.toByteArray().map(unsignByte);
    };
    Address6.fromByteArray = function(bytes) {
      return this.fromUnsignedByteArray(bytes.map(unsignByte));
    };
    Address6.fromUnsignedByteArray = function(bytes) {
      var BYTE_MAX = new BigInteger("256", 10);
      var result = new BigInteger("0", 10);
      var multiplier = new BigInteger("1", 10);
      for (var i = bytes.length - 1; i >= 0; i--) {
        result = result.add(
          multiplier.multiply(new BigInteger(bytes[i].toString(10), 10))
        );
        multiplier = multiplier.multiply(BYTE_MAX);
      }
      return Address6.fromBigInteger(result);
    };
    module.exports = Address6;
  }
});

// node_modules/ip-address/ip-address.js
var require_ip_address = __commonJS({
  "node_modules/ip-address/ip-address.js"(exports) {
    "use strict";
    exports.Address4 = require_ipv4();
    exports.Address6 = require_ipv6();
    exports.v6 = {
      helpers: require_helpers()
    };
  }
});

// node_modules/cidr-regex/lib/index.js
var require_lib = __commonJS({
  "node_modules/cidr-regex/lib/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var cidrv4 = exports.cidrv4 = /^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])(\/([0-9]|[1-2][0-9]|3[0-2]))$/;
    var cidrv6 = exports.cidrv6 = /^((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%\.+)?(\/([0-9]|[1-9][0-9]|1[0-1][0-9]|12[0-8]))?$/;
    exports.default = cidrv4;
  }
});

// node_modules/get-ip-range/index.js
var require_get_ip_range = __commonJS({
  "node_modules/get-ip-range/index.js"(exports, module) {
    var ip = require_ip();
    var ipAddress = require_ip_address();
    var { cidrv4, cidrv6 } = require_lib();
    var errorMessage = new Error("IP supplied is not valid");
    var getRangev4 = (ip1, ip2) => {
      const ips = [];
      let firstAddressLong = ip.toLong(ip1);
      const lastAddressLong = ip.toLong(ip2);
      for (firstAddressLong; firstAddressLong <= lastAddressLong; firstAddressLong++)
        ips.push(ip.fromLong(firstAddressLong));
      return ips;
    };
    var getRangev6 = (ip1, ip2) => {
      const ips = [];
      const firstAddress = new ipAddress.Address6(ip1);
      const lastAddress = new ipAddress.Address6(ip2);
      for (let i = firstAddress.bigInteger(); i <= lastAddress.bigInteger(); i++) {
        ips.push(ipAddress.Address6.fromBigInteger(i).correctForm());
      }
      return ips;
    };
    var isCIDR = (ip2) => {
      return ip2.indexOf("/") !== -1;
    };
    var isRange = (ip2) => {
      return ip2.indexOf("-") !== -1;
    };
    var convert = (cidrIp, ip2) => {
      const ip1v4 = new ipAddress.Address4(cidrIp);
      const ip1v6 = new ipAddress.Address6(cidrIp);
      if (ip2) {
        const ip2v4 = new ipAddress.Address4(ip2);
        const ip2v6 = new ipAddress.Address6(ip2);
        if (ip1v4.valid && ip2v4.valid && !isCIDR(cidrIp) && !isCIDR(ip2)) {
          return getRangev4(cidrIp, ip2);
        }
        if (ip1v6.valid && ip2v6.valid) {
          return getRangev6(cidrIp, ip2);
        }
      } else {
        if (ip1v4.valid) {
          const subnet = ip.cidrSubnet(cidrIp);
          const firstAddress = subnet.firstAddress;
          const lastAddress = subnet.lastAddress;
          return getRangev4(firstAddress, lastAddress);
        }
        if (ip1v6.valid) {
          const IPv6 = new ipAddress.Address6(cidrIp);
          return getRangev6(IPv6.startAddress().correctForm(), IPv6.endAddress().correctForm());
        }
        if (isRange(cidrIp)) {
          const [firstAddress, lastAddress] = cidrIp.split("-");
          return convert(firstAddress, lastAddress);
        }
      }
      throw errorMessage;
    };
    module.exports = convert;
  }
});

// node_modules/local-devices/src/parser/linux.js
var require_linux = __commonJS({
  "node_modules/local-devices/src/parser/linux.js"(exports, module) {
    module.exports = function parseLinux(row, servers, parseOne) {
      var result = {};
      if (row === "" || row.indexOf("incomplete") >= 0) {
        return;
      }
      var chunks = row.split(" ").filter(Boolean);
      if (parseOne) {
        result = prepareOne(chunks);
      } else {
        result = prepareAll(chunks);
      }
      if (!~servers.indexOf(result.ip)) {
        return;
      }
      return result;
    };
    function prepareOne(chunks) {
      return {
        name: "?",
        // a hostname is not provided on the raspberry pi (linux)
        ip: chunks[0],
        mac: chunks[2]
      };
    }
    function prepareAll(chunks) {
      return {
        name: chunks[0],
        ip: chunks[1].match(/\((.*)\)/)[1],
        mac: chunks[3]
      };
    }
  }
});

// node_modules/local-devices/src/parser/win32.js
var require_win32 = __commonJS({
  "node_modules/local-devices/src/parser/win32.js"(exports, module) {
    module.exports = function parseRow(row, servers) {
      var chunks = row.split(/\s+/g).filter(function(el) {
        return el.length > 1;
      });
      var ipAddress = chunks[0];
      if (!~servers.indexOf(ipAddress)) {
        return;
      }
      var macAddress = chunks[1].replace(/-/g, ":");
      if (macAddress === "(incomplete)") {
        return;
      }
      return {
        name: "?",
        // unresolved
        ip: ipAddress,
        mac: macAddress
      };
    };
  }
});

// node_modules/local-devices/src/parser/index.js
var require_parser = __commonJS({
  "node_modules/local-devices/src/parser/index.js"(exports, module) {
    module.exports = function parseRow(row, servers) {
      var nameStart = 0;
      var nameEnd = row.indexOf("(") - 1;
      var name = row.slice(nameStart, nameEnd);
      var ipStart = nameEnd + 2;
      var ipEnd = row.indexOf(")", ipStart);
      var ipAddress = row.slice(ipStart, ipEnd);
      if (!~servers.indexOf(ipAddress)) {
        return;
      }
      var macStart = row.indexOf(" at ", ipEnd) + 4;
      var macEnd = row.indexOf(" on ", macStart);
      var macAddress = row.slice(macStart, macEnd);
      if (macAddress === "(incomplete)") {
        return;
      }
      macAddress = macAddress.replace(/^.:/, "0$&").replace(/:.(?=:|$)/g, ":0X$&").replace(/X:/g, "");
      return {
        name,
        ip: ipAddress,
        mac: macAddress
      };
    };
  }
});

// node_modules/local-devices/src/index.js
var require_src2 = __commonJS({
  "node_modules/local-devices/src/index.js"(exports, module) {
    var ip = require_ip();
    var os = __require("os");
    var net = __require("net");
    var cp = require_child_process();
    var getIPRange = require_get_ip_range();
    var parseLinux = require_linux();
    var parseWin32 = require_win32();
    var parseRow = require_parser();
    var servers;
    var lock = {};
    var TEN_MEGA_BYTE = 1024 * 1024 * 10;
    var ONE_MINUTE = 60 * 1e3;
    var options = {
      maxBuffer: TEN_MEGA_BYTE,
      timeout: ONE_MINUTE
    };
    module.exports = function findLocalDevices({ address = "", skipNameResolution = false, arpPath = "arp" } = {}) {
      var key = String(address);
      if (isRange(address)) {
        try {
          servers = getIPRange(key);
        } catch (error) {
          return error;
        }
      } else {
        servers = getServers();
      }
      if (!lock[key]) {
        if (!address || isRange(key)) {
          lock[key] = pingServers().then(() => arpAll(skipNameResolution, arpPath)).then(unlock(key));
        } else {
          lock[key] = pingServer(address).then((address2) => arpOne(address2, arpPath)).then(unlock(key));
        }
      }
      return lock[key];
    };
    function isRange(address) {
      return address && new RegExp("/|-").test(address);
    }
    function getServers() {
      var interfaces = os.networkInterfaces();
      var result = [];
      for (var key in interfaces) {
        var addresses = interfaces[key];
        for (var i = addresses.length; i--; ) {
          var address = addresses[i];
          if (address.family === "IPv4" && !address.internal) {
            var subnet = ip.subnet(address.address, address.netmask);
            var current = ip.toLong(subnet.firstAddress);
            var last = ip.toLong(subnet.lastAddress) - 1;
            while (current++ < last) result.push(ip.fromLong(current));
          }
        }
      }
      return result;
    }
    function pingServers() {
      return Promise.all(servers.map(pingServer));
    }
    function pingServer(address) {
      return new Promise(function(resolve) {
        var socket = new net.Socket();
        socket.setTimeout(1e3, close);
        socket.connect(80, address, close);
        socket.once("error", close);
        function close() {
          socket.destroy();
          resolve(address);
        }
      });
    }
    function arpAll(skipNameResolution = false, arpPath) {
      const isWindows = process.platform.includes("win32");
      const cmd = skipNameResolution && !isWindows ? `${arpPath} -an` : `${arpPath} -a`;
      return cp.exec(cmd, options).then(parseAll);
    }
    function parseAll(data) {
      if (!data || !data[0]) {
        return [];
      }
      if (process.platform.includes("linux")) {
        var rows = data[0].split("\n");
        return rows.map(function(row) {
          return parseLinux(row, servers);
        }).filter(Boolean);
      } else if (process.platform.includes("win32")) {
        var winRows = data[0].split("\n").splice(1);
        return winRows.map(function(row) {
          return parseWin32(row, servers);
        }).filter(Boolean);
      }
      return data[0].trim().split("\n").map(function(row) {
        return parseRow(row, servers);
      }).filter(Boolean);
    }
    function arpOne(address, arpPath) {
      if (!ip.isV4Format(address) && !ip.isV6Format(address)) {
        return Promise.reject(new Error("Invalid IP address provided."));
      }
      return cp.exec(`${arpPath} -n ${address}`, options).then(parseOne);
    }
    function parseOne(data) {
      if (!data || !data[0]) {
        return;
      }
      if (process.platform.includes("linux")) {
        if (data[0].indexOf("no entry") >= 0) {
          return;
        }
        var rows = data[0].split("\n").slice(1)[0];
        return parseLinux(rows, servers, true);
      } else if (process.platform.includes("win32")) {
        return;
      }
      return parseRow(data[0], servers);
    }
    function unlock(key) {
      return function(data) {
        lock[key] = null;
        return data;
      };
    }
  }
});

// node_modules/tp-link-tapo-connect/dist/network-tools.js
var require_network_tools = __commonJS({
  "node_modules/tp-link-tapo-connect/dist/network-tools.js"(exports) {
    "use strict";
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = exports && exports.__generator || function(thisArg, body) {
      var _ = { label: 0, sent: function() {
        if (t[0] & 1) throw t[1];
        return t[1];
      }, trys: [], ops: [] }, f, y, t, g;
      return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([n, v]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          if (y = 0, t) op = [op[0] & 2, t.value];
          switch (op[0]) {
            case 0:
            case 1:
              t = op;
              break;
            case 4:
              _.label++;
              return { value: op[1], done: false };
            case 5:
              _.label++;
              y = op[1];
              op = [0];
              continue;
            case 7:
              op = _.ops.pop();
              _.trys.pop();
              continue;
            default:
              if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                _ = 0;
                continue;
              }
              if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                _.label = op[1];
                break;
              }
              if (op[0] === 6 && _.label < t[1]) {
                _.label = t[1];
                t = op;
                break;
              }
              if (t && _.label < t[2]) {
                _.label = t[2];
                _.ops.push(op);
                break;
              }
              if (t[2]) _.ops.pop();
              _.trys.pop();
              continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [6, e];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return { value: op[0] ? op[1] : void 0, done: true };
      }
    };
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.resolveMacToIp = void 0;
    var macaddr_1 = require_macaddr();
    var arp_lookup_1 = __importDefault(require_dist());
    var local_devices_1 = __importDefault(require_src2());
    var resolveMacToIp = function(mac) {
      return __awaiter(void 0, void 0, void 0, function() {
        var mac2, trial, ip, _a, _b;
        var _c, _d, _e, _f;
        return __generator(this, function(_g) {
          switch (_g.label) {
            case 0:
              mac2 = tidyMac(mac);
              trial = 0;
              return [4, arp_lookup_1.default.toIP(mac2)];
            case 1:
              if (!((_c = _g.sent()) !== null && _c !== void 0)) return [3, 2];
              _a = _c;
              return [3, 4];
            case 2:
              return [4, (0, local_devices_1.default)()];
            case 3:
              _a = (_d = _g.sent().find(function(devices) {
                return devices.mac === mac2;
              })) === null || _d === void 0 ? void 0 : _d.ip;
              _g.label = 4;
            case 4:
              ip = _a;
              _g.label = 5;
            case 5:
              if (!(trial < 5 && !ip)) return [3, 10];
              trial++;
              return [4, arp_lookup_1.default.toIP(mac2)];
            case 6:
              if (!((_e = _g.sent()) !== null && _e !== void 0)) return [3, 7];
              _b = _e;
              return [3, 9];
            case 7:
              return [4, (0, local_devices_1.default)()];
            case 8:
              _b = (_f = _g.sent().find(function(devices) {
                return devices.mac === mac2;
              })) === null || _f === void 0 ? void 0 : _f.ip;
              _g.label = 9;
            case 9:
              ip = _b;
              return [3, 5];
            case 10:
              return [2, ip];
          }
        });
      });
    };
    exports.resolveMacToIp = resolveMacToIp;
    var tidyMac = function(mac) {
      return (0, macaddr_1.parse)(mac).toString();
    };
  }
});

// node_modules/tp-link-tapo-connect/dist/colour-helper.js
var require_colour_helper = __commonJS({
  "node_modules/tp-link-tapo-connect/dist/colour-helper.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getColour = exports.temperature = exports.hexToHsl = exports.presetColours = void 0;
    exports.presetColours = {
      blue: {
        hue: 240,
        saturation: 100,
        color_temp: 0
      },
      red: {
        hue: 0,
        saturation: 100,
        color_temp: 0
      },
      yellow: {
        hue: 60,
        saturation: 100,
        color_temp: 0
      },
      green: {
        hue: 120,
        saturation: 100,
        color_temp: 0
      },
      white: {
        color_temp: 4500
      },
      daylightwhite: {
        color_temp: 5500
      },
      warmwhite: {
        color_temp: 2700
      }
    };
    var hexToHsl = function(hex) {
      if (hex.toLowerCase() === "#000000")
        return console.error("Cannot set light to black");
      var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
      var r = parseInt(result[1], 16);
      var g = parseInt(result[2], 16);
      var b = parseInt(result[3], 16);
      r /= 255, g /= 255, b /= 255;
      var max = Math.max(r, g, b), min = Math.min(r, g, b);
      var h, s, l = (max + min) / 2;
      if (max == min) {
        h = s = 0;
      } else {
        var d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case r:
            h = (g - b) / d + (g < b ? 6 : 0);
            break;
          case g:
            h = (b - r) / d + 2;
            break;
          case b:
            h = (r - g) / d + 4;
            break;
        }
        h /= 6;
      }
      s = s * 100;
      s = Math.round(s);
      l = l * 100;
      l = Math.round(l);
      h = Math.round(360 * h);
      return {
        hue: h,
        saturation: s,
        brightness: l
      };
    };
    exports.hexToHsl = hexToHsl;
    var temperature = function(temp) {
      var t = parseInt(temp.slice(0, -1));
      if (t < 2500 || t > 6500)
        return console.error("Colour temperature should be between 2500K and 6500K.");
      return {
        color_temp: t
      };
    };
    exports.temperature = temperature;
    var getColour = function(colour) {
      colour = colour.toLowerCase();
      if (colour.startsWith("#"))
        return (0, exports.hexToHsl)(colour);
      if (colour.endsWith("k"))
        return (0, exports.temperature)(colour);
      if (Object.keys(exports.presetColours).includes(colour))
        return exports.presetColours[colour];
      throw new Error("Invalid Colour");
    };
    exports.getColour = getColour;
  }
});

// node_modules/tp-link-tapo-connect/dist/tplink-cipher.js
var require_tplink_cipher = __commonJS({
  "node_modules/tp-link-tapo-connect/dist/tplink-cipher.js"(exports) {
    "use strict";
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = exports && exports.__generator || function(thisArg, body) {
      var _ = { label: 0, sent: function() {
        if (t[0] & 1) throw t[1];
        return t[1];
      }, trys: [], ops: [] }, f, y, t, g;
      return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([n, v]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          if (y = 0, t) op = [op[0] & 2, t.value];
          switch (op[0]) {
            case 0:
            case 1:
              t = op;
              break;
            case 4:
              _.label++;
              return { value: op[1], done: false };
            case 5:
              _.label++;
              y = op[1];
              op = [0];
              continue;
            case 7:
              op = _.ops.pop();
              _.trys.pop();
              continue;
            default:
              if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                _ = 0;
                continue;
              }
              if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                _.label = op[1];
                break;
              }
              if (op[0] === 6 && _.label < t[1]) {
                _.label = t[1];
                t = op;
                break;
              }
              if (t && _.label < t[2]) {
                _.label = t[2];
                _.ops.push(op);
                break;
              }
              if (t[2]) _.ops.pop();
              _.trys.pop();
              continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [6, e];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return { value: op[0] ? op[1] : void 0, done: true };
      }
    };
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.shaDigest = exports.base64Decode = exports.base64Encode = exports.readDeviceKey = exports.decrypt = exports.encrypt = exports.generateKeyPair = void 0;
    var crypto_1 = __importDefault(__require("crypto"));
    var util_1 = __importDefault(__require("util"));
    var RSA_CIPHER_ALGORITHM = "rsa";
    var AES_CIPHER_ALGORITHM = "aes-128-cbc";
    var PASSPHRASE = "top secret";
    var generateKeyPair = function() {
      return __awaiter(void 0, void 0, void 0, function() {
        var RSA_OPTIONS, generateKeyPair2;
        return __generator(this, function(_a) {
          RSA_OPTIONS = {
            modulusLength: 1024,
            publicKeyEncoding: {
              type: "spki",
              format: "pem"
            },
            privateKeyEncoding: {
              type: "pkcs1",
              format: "pem",
              cipher: "aes-256-cbc",
              passphrase: PASSPHRASE
            }
          };
          generateKeyPair2 = util_1.default.promisify(crypto_1.default.generateKeyPair);
          return [2, generateKeyPair2(RSA_CIPHER_ALGORITHM, RSA_OPTIONS)];
        });
      });
    };
    exports.generateKeyPair = generateKeyPair;
    var encrypt = function(data, deviceKey) {
      var cipher = crypto_1.default.createCipheriv(AES_CIPHER_ALGORITHM, deviceKey.key, deviceKey.iv);
      var ciphertext = cipher.update(Buffer.from(JSON.stringify(data)));
      return Buffer.concat([ciphertext, cipher.final()]).toString("base64");
    };
    exports.encrypt = encrypt;
    var decrypt = function(data, deviceKey) {
      var cipher = crypto_1.default.createDecipheriv(AES_CIPHER_ALGORITHM, deviceKey.key, deviceKey.iv);
      var ciphertext = cipher.update(Buffer.from(data, "base64"));
      return JSON.parse(Buffer.concat([ciphertext, cipher.final()]).toString());
    };
    exports.decrypt = decrypt;
    var readDeviceKey = function(pemKey, privateKey) {
      var keyBytes = Buffer.from(pemKey, "base64");
      var deviceKey = crypto_1.default.privateDecrypt({
        key: privateKey,
        padding: crypto_1.default.constants.RSA_PKCS1_PADDING,
        passphrase: PASSPHRASE
      }, keyBytes);
      return deviceKey;
    };
    exports.readDeviceKey = readDeviceKey;
    var base64Encode = function(data) {
      return Buffer.from(data).toString("base64");
    };
    exports.base64Encode = base64Encode;
    var base64Decode = function(data) {
      if (!data)
        return "";
      return Buffer.from(data, "base64").toString();
    };
    exports.base64Decode = base64Decode;
    var shaDigest = function(data) {
      var shasum = crypto_1.default.createHash("sha1");
      shasum.update(data);
      return shasum.digest("hex");
    };
    exports.shaDigest = shaDigest;
  }
});

// node_modules/tp-link-tapo-connect/dist/tapo-device.js
var require_tapo_device = __commonJS({
  "node_modules/tp-link-tapo-connect/dist/tapo-device.js"(exports) {
    "use strict";
    var __assign = exports && exports.__assign || function() {
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = exports && exports.__generator || function(thisArg, body) {
      var _ = { label: 0, sent: function() {
        if (t[0] & 1) throw t[1];
        return t[1];
      }, trys: [], ops: [] }, f, y, t, g;
      return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([n, v]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          if (y = 0, t) op = [op[0] & 2, t.value];
          switch (op[0]) {
            case 0:
            case 1:
              t = op;
              break;
            case 4:
              _.label++;
              return { value: op[1], done: false };
            case 5:
              _.label++;
              y = op[1];
              op = [0];
              continue;
            case 7:
              op = _.ops.pop();
              _.trys.pop();
              continue;
            default:
              if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                _ = 0;
                continue;
              }
              if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                _.label = op[1];
                break;
              }
              if (op[0] === 6 && _.label < t[1]) {
                _.label = t[1];
                t = op;
                break;
              }
              if (t && _.label < t[2]) {
                _.label = t[2];
                _.ops.push(op);
                break;
              }
              if (t[2]) _.ops.pop();
              _.trys.pop();
              continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [6, e];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return { value: op[0] ? op[1] : void 0, done: true };
      }
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.TapoDevice = void 0;
    var colour_helper_1 = require_colour_helper();
    var tplink_cipher_1 = require_tplink_cipher();
    var TapoDevice = function(_a) {
      var send = _a.send;
      var wrapRequestForChildDevice = function(request, deviceId) {
        if (!deviceId)
          return request;
        return {
          method: "control_child",
          params: {
            device_id: deviceId,
            // Note: requestData can be an array of requests with the block below
            requestData: request
            // requestData: {
            // 	method: 'multipleRequest',
            // 	params: {requests: [request]}
            // },
          }
        };
      };
      var setDeviceOn = function(deviceOn, deviceId) {
        return __awaiter(void 0, void 0, void 0, function() {
          var turnDeviceOnRequest;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                turnDeviceOnRequest = {
                  "method": "set_device_info",
                  "params": {
                    "device_on": deviceOn
                  }
                };
                return [4, send(wrapRequestForChildDevice(turnDeviceOnRequest, deviceId))];
              case 1:
                _a2.sent();
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      var augmentTapoDeviceInfo = function(deviceInfo) {
        return __assign(__assign({}, deviceInfo), { ssid: (0, tplink_cipher_1.base64Decode)(deviceInfo.ssid), nickname: (0, tplink_cipher_1.base64Decode)(deviceInfo.nickname) });
      };
      return {
        turnOn: function(deviceId) {
          return setDeviceOn(true, deviceId);
        },
        turnOff: function(deviceId) {
          return setDeviceOn(false, deviceId);
        },
        setBrightness: function(brightnessLevel) {
          if (brightnessLevel === void 0) {
            brightnessLevel = 100;
          }
          return __awaiter(void 0, void 0, void 0, function() {
            var setBrightnessRequest;
            return __generator(this, function(_a2) {
              switch (_a2.label) {
                case 0:
                  setBrightnessRequest = {
                    "method": "set_device_info",
                    "params": {
                      "brightness": brightnessLevel
                    }
                  };
                  return [4, send(setBrightnessRequest)];
                case 1:
                  _a2.sent();
                  return [
                    2
                    /*return*/
                  ];
              }
            });
          });
        },
        setColour: function(colour) {
          if (colour === void 0) {
            colour = "white";
          }
          return __awaiter(void 0, void 0, void 0, function() {
            var params, setColourRequest;
            return __generator(this, function(_a2) {
              switch (_a2.label) {
                case 0:
                  params = (0, colour_helper_1.getColour)(colour);
                  setColourRequest = {
                    "method": "set_device_info",
                    params
                  };
                  return [4, send(setColourRequest)];
                case 1:
                  _a2.sent();
                  return [
                    2
                    /*return*/
                  ];
              }
            });
          });
        },
        setHSL: function(hue, sat, lum) {
          return __awaiter(void 0, void 0, void 0, function() {
            var normalisedHue, normalisedSat, normalisedLum, setHSLRequest;
            return __generator(this, function(_a2) {
              switch (_a2.label) {
                case 0:
                  normalisedHue = hue % 360;
                  normalisedSat = Math.max(0, Math.min(100, sat));
                  normalisedLum = Math.max(0, Math.min(100, lum));
                  if (!(normalisedLum === 0)) return [3, 2];
                  return [4, setDeviceOn(false, void 0)];
                case 1:
                  _a2.sent();
                  _a2.label = 2;
                case 2:
                  setHSLRequest = {
                    "method": "set_device_info",
                    "params": {
                      "hue": normalisedHue,
                      "saturation": normalisedSat,
                      "brightness": normalisedLum
                    }
                  };
                  return [4, send(setHSLRequest)];
                case 3:
                  _a2.sent();
                  return [
                    2
                    /*return*/
                  ];
              }
            });
          });
        },
        getDeviceInfo: function() {
          return __awaiter(void 0, void 0, void 0, function() {
            var statusRequest, _a2;
            return __generator(this, function(_b) {
              switch (_b.label) {
                case 0:
                  statusRequest = {
                    "method": "get_device_info"
                  };
                  _a2 = augmentTapoDeviceInfo;
                  return [4, send(statusRequest)];
                case 1:
                  return [2, _a2.apply(void 0, [_b.sent()])];
              }
            });
          });
        },
        getChildDevicesInfo: function() {
          return __awaiter(void 0, void 0, void 0, function() {
            var listChildDeviceRequest, res;
            return __generator(this, function(_a2) {
              switch (_a2.label) {
                case 0:
                  listChildDeviceRequest = {
                    "method": "get_child_device_list",
                    start_index: 0
                  };
                  return [4, send(listChildDeviceRequest)];
                case 1:
                  res = _a2.sent();
                  return [2, res.child_device_list.map(function(deviceInfo) {
                    return augmentTapoDeviceInfo(deviceInfo);
                  }).sort(function(a, b) {
                    return a.position - b.position;
                  })];
              }
            });
          });
        },
        getEnergyUsage: function() {
          return __awaiter(void 0, void 0, void 0, function() {
            var statusRequest;
            return __generator(this, function(_a2) {
              switch (_a2.label) {
                case 0:
                  statusRequest = {
                    "method": "get_energy_usage"
                  };
                  return [4, send(statusRequest)];
                case 1:
                  return [2, _a2.sent()];
              }
            });
          });
        }
      };
    };
    exports.TapoDevice = TapoDevice;
  }
});

// node_modules/tp-link-tapo-connect/dist/tapo-utils.js
var require_tapo_utils = __commonJS({
  "node_modules/tp-link-tapo-connect/dist/tapo-utils.js"(exports) {
    "use strict";
    var __assign = exports && exports.__assign || function() {
      __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = exports && exports.__generator || function(thisArg, body) {
      var _ = { label: 0, sent: function() {
        if (t[0] & 1) throw t[1];
        return t[1];
      }, trys: [], ops: [] }, f, y, t, g;
      return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([n, v]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          if (y = 0, t) op = [op[0] & 2, t.value];
          switch (op[0]) {
            case 0:
            case 1:
              t = op;
              break;
            case 4:
              _.label++;
              return { value: op[1], done: false };
            case 5:
              _.label++;
              y = op[1];
              op = [0];
              continue;
            case 7:
              op = _.ops.pop();
              _.trys.pop();
              continue;
            default:
              if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                _ = 0;
                continue;
              }
              if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                _.label = op[1];
                break;
              }
              if (op[0] === 6 && _.label < t[1]) {
                _.label = t[1];
                t = op;
                break;
              }
              if (t && _.label < t[2]) {
                _.label = t[2];
                _.ops.push(op);
                break;
              }
              if (t[2]) _.ops.pop();
              _.trys.pop();
              continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [6, e];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return { value: op[0] ? op[1] : void 0, done: true };
      }
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.checkError = exports.isTapoDevice = exports.augmentTapoDevice = void 0;
    var tplink_cipher_1 = require_tplink_cipher();
    var augmentTapoDevice = function(deviceInfo) {
      return __awaiter(void 0, void 0, void 0, function() {
        return __generator(this, function(_a) {
          if ((0, exports.isTapoDevice)(deviceInfo.deviceType)) {
            return [2, __assign(__assign({}, deviceInfo), { alias: (0, tplink_cipher_1.base64Decode)(deviceInfo.alias) })];
          } else {
            return [2, deviceInfo];
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    exports.augmentTapoDevice = augmentTapoDevice;
    var isTapoDevice = function(deviceType) {
      switch (deviceType) {
        case "SMART.TAPOPLUG":
        case "SMART.TAPOBULB":
        case "SMART.IPCAMERA":
          return true;
        default:
          return false;
      }
    };
    exports.isTapoDevice = isTapoDevice;
    var checkError = function(responseData) {
      var errorCode = responseData["error_code"];
      if (errorCode) {
        switch (errorCode) {
          case 0:
            return;
          case -1005:
            throw new Error("AES Decode Fail");
          case -1006:
            throw new Error("Request length error");
          case -1008:
            throw new Error("Invalid request params");
          case -1301:
            throw new Error("Rate limit exceeded");
          case -1101:
            throw new Error("Session params error");
          case -1010:
            throw new Error("Invalid public key length");
          case -1012:
            throw new Error("Invalid terminal UUID");
          case -1501:
            throw new Error("Invalid credentials");
          case -1002:
            throw new Error("Transport not available error");
          case -1003:
            throw new Error("Malformed json request");
          case -20004:
            throw new Error("API rate limit exceeded");
          case -20104:
            throw new Error("Missing credentials");
          case -20601:
            throw new Error("Incorrect email or password");
          case -20675:
            throw new Error("Cloud token expired or invalid");
          case 1e3:
            throw new Error("Null transport error");
          case 1001:
            throw new Error("Command cancel error");
          case 1002:
            throw new Error("Transport not available error");
          case 1003:
            throw new Error("Device supports KLAP protocol - Legacy login not supported");
          case 1100:
            throw new Error("Handshake failed");
          case 1111:
            throw new Error("Login failed");
          case 1112:
            throw new Error("Http transport error");
          case 1200:
            throw new Error("Multirequest failed");
          case 9999:
            throw new Error("Session Timeout");
          default:
            throw new Error("Unrecognised Error Code: ".concat(errorCode, " (").concat(responseData["msg"], ")"));
        }
      }
    };
    exports.checkError = checkError;
  }
});

// node_modules/tp-link-tapo-connect/dist/klap-transport.js
var require_klap_transport = __commonJS({
  "node_modules/tp-link-tapo-connect/dist/klap-transport.js"(exports) {
    "use strict";
    var __extends = exports && exports.__extends || /* @__PURE__ */ (function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
          d2.__proto__ = b2;
        } || function(d2, b2) {
          for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        if (typeof b !== "function" && b !== null)
          throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    })();
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = exports && exports.__generator || function(thisArg, body) {
      var _ = { label: 0, sent: function() {
        if (t[0] & 1) throw t[1];
        return t[1];
      }, trys: [], ops: [] }, f, y, t, g;
      return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([n, v]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          if (y = 0, t) op = [op[0] & 2, t.value];
          switch (op[0]) {
            case 0:
            case 1:
              t = op;
              break;
            case 4:
              _.label++;
              return { value: op[1], done: false };
            case 5:
              _.label++;
              y = op[1];
              op = [0];
              continue;
            case 7:
              op = _.ops.pop();
              _.trys.pop();
              continue;
            default:
              if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                _ = 0;
                continue;
              }
              if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                _.label = op[1];
                break;
              }
              if (op[0] === 6 && _.label < t[1]) {
                _.label = t[1];
                t = op;
                break;
              }
              if (t && _.label < t[2]) {
                _.label = t[2];
                _.ops.push(op);
                break;
              }
              if (t[2]) _.ops.pop();
              _.trys.pop();
              continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [6, e];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return { value: op[0] ? op[1] : void 0, done: true };
      }
    };
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ProtocolUnsupportedError = exports.loginDeviceByIp = void 0;
    var axios_1 = __importDefault(require_axios2());
    var crypto_1 = __require("crypto");
    var tapo_device_1 = require_tapo_device();
    var tapo_utils_1 = require_tapo_utils();
    var AES_CIPHER_ALGORITHM = "aes-128-cbc";
    var loginDeviceByIp2 = function(email, password, deviceIp) {
      return __awaiter(void 0, void 0, void 0, function() {
        var localSeed, response, responseBytes, setCookieHeader, sessionCookie, remoteSeed, serverHash, localAuthHash, localSeedAuthHash, payload;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              localSeed = (0, crypto_1.randomBytes)(16);
              return [4, axios_1.default.post("http://".concat(deviceIp, "/app/handshake1"), localSeed, {
                responseType: "arraybuffer",
                withCredentials: true
              }).catch(function(error) {
                var _a2;
                if (((_a2 = error === null || error === void 0 ? void 0 : error.response) === null || _a2 === void 0 ? void 0 : _a2.status) === 404) {
                  throw new Error("Klap protocol not supported");
                }
                throw new Error("handshake1 failed: ".concat(error));
              })];
            case 1:
              response = _a.sent();
              responseBytes = Buffer.from(response.data);
              setCookieHeader = response.headers["set-cookie"][0];
              sessionCookie = setCookieHeader.substring(0, setCookieHeader.indexOf(";"));
              remoteSeed = responseBytes.slice(0, 16);
              serverHash = responseBytes.slice(16);
              localAuthHash = generateAuthHash(email, password);
              localSeedAuthHash = handshake1AuthHash(localSeed, remoteSeed, localAuthHash);
              if (!compare(localSeedAuthHash, serverHash)) {
                throw new Error("email or password incorrect");
              }
              payload = handshake2AuthHash(localSeed, remoteSeed, localAuthHash);
              return [4, axios_1.default.post("http://".concat(deviceIp, "/app/handshake2"), payload, {
                responseType: "arraybuffer",
                headers: {
                  "Cookie": sessionCookie
                }
              }).catch(function(error) {
                throw new Error("handshake2 failed: ".concat(error));
              })];
            case 2:
              _a.sent();
              return [2, createKlapEncryptionSession(deviceIp, localSeed, remoteSeed, localAuthHash, sessionCookie)];
          }
        });
      });
    };
    exports.loginDeviceByIp = loginDeviceByIp2;
    var createKlapEncryptionSession = function(deviceIp, localSeed, remoteSeed, userHash, sessionCookie) {
      var key = deriveKey(localSeed, remoteSeed, userHash);
      var iv = deriveIv(localSeed, remoteSeed, userHash);
      var sig = deriveSig(localSeed, remoteSeed, userHash);
      var seq = deriveSeqFromIv(iv);
      var encrypt = function(payload) {
        var payloadJson = JSON.stringify(payload);
        var cipher = (0, crypto_1.createCipheriv)(AES_CIPHER_ALGORITHM, key, ivWithSeq(iv, seq));
        var ciphertext = cipher.update(encode(payloadJson));
        return Buffer.concat([ciphertext, cipher.final()]);
      };
      var decrypt = function(payload) {
        var cipher = (0, crypto_1.createDecipheriv)(AES_CIPHER_ALGORITHM, key, ivWithSeq(iv, seq));
        var ciphertext = cipher.update(payload.slice(32));
        return JSON.parse(Buffer.concat([ciphertext, cipher.final()]).toString());
      };
      var encryptAndSign = function(payload) {
        var ciphertext = encrypt(payload);
        var signature = sha256(Buffer.concat([sig, seq, ciphertext]));
        return Buffer.concat([signature, ciphertext]);
      };
      var send = function(deviceRequest) {
        return __awaiter(void 0, void 0, void 0, function() {
          var encryptedRequest, response, decryptedResponse;
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                seq = incrementSeq(seq);
                encryptedRequest = encryptAndSign(deviceRequest);
                return [4, (0, axios_1.default)({
                  method: "post",
                  url: "http://".concat(deviceIp, "/app/request"),
                  data: encryptedRequest,
                  responseType: "arraybuffer",
                  headers: {
                    "Cookie": sessionCookie
                  },
                  params: {
                    seq: seq.readInt32BE()
                  }
                })];
              case 1:
                response = _a.sent();
                decryptedResponse = decrypt(response.data);
                (0, tapo_utils_1.checkError)(decryptedResponse);
                return [2, decryptedResponse.result];
            }
          });
        });
      };
      return (0, tapo_device_1.TapoDevice)({ send });
    };
    var ProtocolUnsupportedError = (
      /** @class */
      (function(_super) {
        __extends(ProtocolUnsupportedError2, _super);
        function ProtocolUnsupportedError2() {
          return _super !== null && _super.apply(this, arguments) || this;
        }
        return ProtocolUnsupportedError2;
      })(Error)
    );
    exports.ProtocolUnsupportedError = ProtocolUnsupportedError;
    var handshake1AuthHash = function(localSeed, remoteSeed, authHash) {
      return sha256(Buffer.concat([localSeed, remoteSeed, authHash]));
    };
    var handshake2AuthHash = function(localSeed, remoteSeed, authHash) {
      return sha256(Buffer.concat([remoteSeed, localSeed, authHash]));
    };
    var generateAuthHash = function(email, password) {
      return sha256(Buffer.concat([sha12(email), sha12(password)]));
    };
    var deriveKey = function(localSeed, remoteSeed, userHash) {
      return sha256(Buffer.concat([encode("lsk"), localSeed, remoteSeed, userHash])).slice(0, 16);
    };
    var deriveIv = function(localSeed, remoteSeed, userHash) {
      return sha256(Buffer.concat([encode("iv"), localSeed, remoteSeed, userHash]));
    };
    var deriveSig = function(localSeed, remoteSeed, userHash) {
      return sha256(Buffer.concat([encode("ldk"), localSeed, remoteSeed, userHash])).slice(0, 28);
    };
    var deriveSeqFromIv = function(iv) {
      return iv.slice(iv.length - 4);
    };
    var ivWithSeq = function(iv, seq) {
      return Buffer.concat([iv.slice(0, 12), seq]);
    };
    var incrementSeq = function(seq) {
      var buffer = Buffer.alloc(4);
      buffer.writeInt32BE(seq.readInt32BE() + 1);
      return buffer;
    };
    var sha256 = function(data) {
      return (0, crypto_1.createHash)("sha256").update(data).digest();
    };
    var sha12 = function(data) {
      return (0, crypto_1.createHash)("sha1").update(data).digest();
    };
    var compare = function(b1, b2) {
      return b1.compare(b2) === 0;
    };
    var encode = function(text) {
      return Buffer.from(text, "utf-8");
    };
  }
});

// node_modules/tp-link-tapo-connect/dist/secure-passthrough-transport.js
var require_secure_passthrough_transport = __commonJS({
  "node_modules/tp-link-tapo-connect/dist/secure-passthrough-transport.js"(exports) {
    "use strict";
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = exports && exports.__generator || function(thisArg, body) {
      var _ = { label: 0, sent: function() {
        if (t[0] & 1) throw t[1];
        return t[1];
      }, trys: [], ops: [] }, f, y, t, g;
      return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([n, v]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          if (y = 0, t) op = [op[0] & 2, t.value];
          switch (op[0]) {
            case 0:
            case 1:
              t = op;
              break;
            case 4:
              _.label++;
              return { value: op[1], done: false };
            case 5:
              _.label++;
              y = op[1];
              op = [0];
              continue;
            case 7:
              op = _.ops.pop();
              _.trys.pop();
              continue;
            default:
              if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                _ = 0;
                continue;
              }
              if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                _.label = op[1];
                break;
              }
              if (op[0] === 6 && _.label < t[1]) {
                _.label = t[1];
                t = op;
                break;
              }
              if (t && _.label < t[2]) {
                _.label = t[2];
                _.ops.push(op);
                break;
              }
              if (t[2]) _.ops.pop();
              _.trys.pop();
              continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [6, e];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return { value: op[0] ? op[1] : void 0, done: true };
      }
    };
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.securePassthrough = exports.loginDeviceByIp = void 0;
    var axios_1 = __importDefault(require_axios2());
    var tplink_cipher_1 = require_tplink_cipher();
    var tapo_device_1 = require_tapo_device();
    var tapo_utils_1 = require_tapo_utils();
    var loginDeviceByIp2 = function(email, password, deviceIp) {
      return __awaiter(void 0, void 0, void 0, function() {
        var deviceKey, loginDeviceRequest, loginDeviceResponse, send;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, handshake(deviceIp)];
            case 1:
              deviceKey = _a.sent();
              loginDeviceRequest = {
                "method": "login_device",
                "params": {
                  "username": (0, tplink_cipher_1.base64Encode)((0, tplink_cipher_1.shaDigest)(email)),
                  "password": (0, tplink_cipher_1.base64Encode)(password)
                },
                "requestTimeMils": 0
              };
              return [4, (0, exports.securePassthrough)(loginDeviceRequest, deviceKey)];
            case 2:
              loginDeviceResponse = _a.sent();
              deviceKey.token = loginDeviceResponse.token;
              send = function(request) {
                return (0, exports.securePassthrough)(request, deviceKey);
              };
              return [2, (0, tapo_device_1.TapoDevice)({
                send
              })];
          }
        });
      });
    };
    exports.loginDeviceByIp = loginDeviceByIp2;
    var handshake = function(deviceIp) {
      return __awaiter(void 0, void 0, void 0, function() {
        var keyPair, handshakeRequest, response, setCookieHeader, sessionCookie, deviceKey;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, (0, tplink_cipher_1.generateKeyPair)()];
            case 1:
              keyPair = _a.sent();
              handshakeRequest = {
                method: "handshake",
                params: {
                  "key": keyPair.publicKey
                }
              };
              return [4, (0, axios_1.default)({
                method: "post",
                url: "http://".concat(deviceIp, "/app"),
                data: handshakeRequest
              })];
            case 2:
              response = _a.sent();
              (0, tapo_utils_1.checkError)(response.data);
              setCookieHeader = response.headers["set-cookie"][0];
              sessionCookie = setCookieHeader.substring(0, setCookieHeader.indexOf(";"));
              deviceKey = (0, tplink_cipher_1.readDeviceKey)(response.data.result.key, keyPair.privateKey);
              return [2, {
                key: deviceKey.subarray(0, 16),
                iv: deviceKey.subarray(16, 32),
                deviceIp,
                sessionCookie
              }];
          }
        });
      });
    };
    var securePassthrough = function(deviceRequest, deviceKey) {
      return __awaiter(void 0, void 0, void 0, function() {
        var encryptedRequest, securePassthroughRequest, response, decryptedResponse;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              encryptedRequest = (0, tplink_cipher_1.encrypt)(deviceRequest, deviceKey);
              securePassthroughRequest = {
                "method": "securePassthrough",
                "params": {
                  "request": encryptedRequest
                }
              };
              return [4, (0, axios_1.default)({
                method: "post",
                url: "http://".concat(deviceKey.deviceIp, "/app?token=").concat(deviceKey.token),
                data: securePassthroughRequest,
                headers: {
                  "Cookie": deviceKey.sessionCookie
                }
              })];
            case 1:
              response = _a.sent();
              (0, tapo_utils_1.checkError)(response.data);
              decryptedResponse = (0, tplink_cipher_1.decrypt)(response.data.result.response, deviceKey);
              (0, tapo_utils_1.checkError)(decryptedResponse);
              return [2, decryptedResponse.result];
          }
        });
      });
    };
    exports.securePassthrough = securePassthrough;
  }
});

// node_modules/tp-link-tapo-connect/dist/tplink-ca-cert.js
var require_tplink_ca_cert = __commonJS({
  "node_modules/tp-link-tapo-connect/dist/tplink-ca-cert.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = "-----BEGIN CERTIFICATE-----\nMIIDBzCCAe+gAwIBAgIQT5x0ma7QnINHCQvhnmzR9zANBgkqhkiG9w0BAQsFADAV\nMRMwEQYDVQQDEwp0cC1saW5rLUNBMCAXDTE4MDExOTA4Mjc1MloYDzIwNjgwMTE5\nMDgzNzUyWjAVMRMwEQYDVQQDEwp0cC1saW5rLUNBMIIBIjANBgkqhkiG9w0BAQEF\nAAOCAQ8AMIIBCgKCAQEAuGG8n5zEUN1j5wuvUz4pAIMurhKHbpfUUu+b2acFHKS6\niU9hNJWvDyhXcihY5Wz6aq9m4D5SZcgW3k31YoNNtrztDjdg2qw7AaX85S99/G0B\nVbIXktrhs34OW19WA/haDwut3dFhLem+gCRRKUXcmuqchZc84dY7JFVfhPcJci4m\nsRjLCFNO0ho9OX+MZwfO4BLaeAqKVoAor6rf4BXVtO0xjYHDKO0fb3AWLLJ4EjGe\nq6YieqPiYlPFEqRm5PrvBXTm0IuQogygyVpK4LHr/K207ZLyV33DxLLbsUgSEJVn\npZUv/WUujXjlIDgxIvyZZCYiXO3dle2/MEvpmZk6JQIDAQABo1EwTzALBgNVHQ8E\nBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUxu2iBRTsef5iNnsADVhM\nJDQWi6kwEAYJKwYBBAGCNxUBBAMCAQAwDQYJKoZIhvcNAQELBQADggEBAB52Majd\n+wo3cb5BsTo63z2Psbbyl4ACMUaw68NxUMy61Oihx3mcLzLJqiIZcKePiHskLqLJ\nF7QfT9TqjvizMjFJVgsLuVubUBXKBzqyN+3KKlQci0PO3mH+ObhyaE7BzV+qrS3P\ndVTgsCWFv8DkgLTRudSWxL7VwVoedc7lRz5EroGgJ33nRGCR0ngcW919tLTARDQO\npULmzulcdWeZgG+0PLX0xjJQIjFEvbOxR1Z+gxMupBz0rWFokmWYrcga8eWiWzjQ\nIa3/ASBVJ69srV77trWlfLumkChbXk9i64NXBKnce0Jmll0Y9OC1nMPqrbQKnzcn\ndSAA4fejD/qMQn0=\n-----END CERTIFICATE-----";
  }
});

// node_modules/tp-link-tapo-connect/dist/api.js
var require_api = __commonJS({
  "node_modules/tp-link-tapo-connect/dist/api.js"(exports) {
    "use strict";
    var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports && exports.__importStar || function(mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null) {
        for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
      }
      __setModuleDefault(result, mod);
      return result;
    };
    var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
      function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
          resolve(value);
        });
      }
      return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }
        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }
        function step(result) {
          result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    };
    var __generator = exports && exports.__generator || function(thisArg, body) {
      var _ = { label: 0, sent: function() {
        if (t[0] & 1) throw t[1];
        return t[1];
      }, trys: [], ops: [] }, f, y, t, g;
      return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
      }), g;
      function verb(n) {
        return function(v) {
          return step([n, v]);
        };
      }
      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
          if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          if (y = 0, t) op = [op[0] & 2, t.value];
          switch (op[0]) {
            case 0:
            case 1:
              t = op;
              break;
            case 4:
              _.label++;
              return { value: op[1], done: false };
            case 5:
              _.label++;
              y = op[1];
              op = [0];
              continue;
            case 7:
              op = _.ops.pop();
              _.trys.pop();
              continue;
            default:
              if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                _ = 0;
                continue;
              }
              if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                _.label = op[1];
                break;
              }
              if (op[0] === 6 && _.label < t[1]) {
                _.label = t[1];
                t = op;
                break;
              }
              if (t && _.label < t[2]) {
                _.label = t[2];
                _.ops.push(op);
                break;
              }
              if (t[2]) _.ops.pop();
              _.trys.pop();
              continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [6, e];
          y = 0;
        } finally {
          f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return { value: op[0] ? op[1] : void 0, done: true };
      }
    };
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.loginDeviceByIp = exports.loginDevice = exports.cloudLogin = void 0;
    var axios_1 = __importDefault(require_axios2());
    var https = __importStar(__require("https"));
    var uuid_1 = (init_esm_node(), __toCommonJS(esm_node_exports));
    var network_tools_1 = require_network_tools();
    var klap_transport_1 = require_klap_transport();
    var secure_passthrough_transport_1 = require_secure_passthrough_transport();
    var tplink_ca_cert_1 = __importDefault(require_tplink_ca_cert());
    var tapo_utils_1 = require_tapo_utils();
    var baseUrl = "https://eu-wap.tplinkcloud.com/";
    var baseTapoCareUrl = "https://euw1-app-tapo-care.i.tplinknbu.com";
    var cloudLogin2 = function(email, password) {
      if (email === void 0) {
        email = process.env.TAPO_USERNAME || void 0;
      }
      if (password === void 0) {
        password = process.env.TAPO_PASSWORD || void 0;
      }
      return __awaiter(void 0, void 0, void 0, function() {
        var loginRequest, response, cloudToken, listDevices, listDevicesByType, tapoCareCloudVideos;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              loginRequest = {
                "method": "login",
                "params": {
                  "appType": "Tapo_Ios",
                  "cloudPassword": password,
                  "cloudUserName": email,
                  "terminalUUID": (0, uuid_1.v4)()
                }
              };
              return [4, (0, axios_1.default)({
                method: "post",
                url: baseUrl,
                data: loginRequest
              })];
            case 1:
              response = _a.sent();
              (0, tapo_utils_1.checkError)(response.data);
              cloudToken = response.data.result.token;
              listDevices = function() {
                return __awaiter(void 0, void 0, void 0, function() {
                  var getDeviceRequest, response2;
                  return __generator(this, function(_a2) {
                    switch (_a2.label) {
                      case 0:
                        getDeviceRequest = {
                          "method": "getDeviceList"
                        };
                        return [4, (0, axios_1.default)({
                          method: "post",
                          url: baseUrl,
                          data: getDeviceRequest,
                          params: {
                            token: cloudToken
                          }
                        })];
                      case 1:
                        response2 = _a2.sent();
                        (0, tapo_utils_1.checkError)(response2.data);
                        return [2, Promise.all(response2.data.result.deviceList.map(function(deviceInfo) {
                          return __awaiter(void 0, void 0, void 0, function() {
                            return __generator(this, function(_a3) {
                              return [2, (0, tapo_utils_1.augmentTapoDevice)(deviceInfo)];
                            });
                          });
                        }))];
                    }
                  });
                });
              };
              listDevicesByType = function(deviceType) {
                return __awaiter(void 0, void 0, void 0, function() {
                  var devices;
                  return __generator(this, function(_a2) {
                    switch (_a2.label) {
                      case 0:
                        return [4, listDevices()];
                      case 1:
                        devices = _a2.sent();
                        return [2, devices.filter(function(d) {
                          return d.deviceType === deviceType;
                        })];
                    }
                  });
                });
              };
              tapoCareCloudVideos = function(deviceId, order, page, pageSize, startTime, endTime) {
                if (order === void 0) {
                  order = "desc";
                }
                if (page === void 0) {
                  page = 0;
                }
                if (pageSize === void 0) {
                  pageSize = 20;
                }
                if (startTime === void 0) {
                  startTime = null;
                }
                if (endTime === void 0) {
                  endTime = null;
                }
                return __awaiter(void 0, void 0, void 0, function() {
                  var response2;
                  return __generator(this, function(_a2) {
                    switch (_a2.label) {
                      case 0:
                        return [4, tplinkCaAxios()({
                          method: "get",
                          url: "".concat(baseTapoCareUrl, "/v1/videos"),
                          params: {
                            deviceId,
                            page,
                            pageSize,
                            order,
                            startTime,
                            endTime
                          },
                          headers: {
                            "authorization": "ut|".concat(cloudToken)
                          }
                        })];
                      case 1:
                        response2 = _a2.sent();
                        checkTapoCareError(response2);
                        return [2, response2.data];
                    }
                  });
                });
              };
              return [2, {
                listDevices,
                listDevicesByType,
                tapoCareCloudVideos
              }];
          }
        });
      });
    };
    exports.cloudLogin = cloudLogin2;
    var loginDevice = function(email, password, device) {
      if (email === void 0) {
        email = process.env.TAPO_USERNAME || void 0;
      }
      if (password === void 0) {
        password = process.env.TAPO_PASSWORD || void 0;
      }
      return __awaiter(void 0, void 0, void 0, function() {
        var localIp;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, (0, network_tools_1.resolveMacToIp)(device.deviceMac)];
            case 1:
              localIp = _a.sent();
              if (!localIp) {
                throw new Error("Local IP of device with Mac address ".concat(device.deviceMac, " not found."));
              }
              return [2, (0, exports.loginDeviceByIp)(email, password, localIp)];
          }
        });
      });
    };
    exports.loginDevice = loginDevice;
    var loginDeviceByIp2 = function(email, password, deviceIp) {
      if (email === void 0) {
        email = process.env.TAPO_USERNAME || void 0;
      }
      if (password === void 0) {
        password = process.env.TAPO_PASSWORD || void 0;
      }
      return __awaiter(void 0, void 0, void 0, function() {
        return __generator(this, function(_a) {
          return [2, (0, klap_transport_1.loginDeviceByIp)(email, password, deviceIp).catch(function(error) {
            console.warn("Failed to login due to ".concat(error, "\nFalling back to legacy login method"));
            return (0, secure_passthrough_transport_1.loginDeviceByIp)(email, password, deviceIp);
          })];
        });
      });
    };
    exports.loginDeviceByIp = loginDeviceByIp2;
    var tplinkCaAxios = function() {
      var httpsAgent = new https.Agent({
        rejectUnauthorized: true,
        ca: tplink_ca_cert_1.default
      });
      return axios_1.default.create({ httpsAgent });
    };
    var checkTapoCareError = function(responseData) {
      var errorCode = responseData === null || responseData === void 0 ? void 0 : responseData.code;
      if (errorCode) {
        throw new Error("Unrecognised Error Code: ".concat(errorCode, " (").concat(responseData["message"], ")"));
      }
    };
  }
});

// node_modules/cli-table3/src/debug.js
var require_debug2 = __commonJS({
  "node_modules/cli-table3/src/debug.js"(exports, module) {
    var messages = [];
    var level = 0;
    var debug = (msg, min) => {
      if (level >= min) {
        messages.push(msg);
      }
    };
    debug.WARN = 1;
    debug.INFO = 2;
    debug.DEBUG = 3;
    debug.reset = () => {
      messages = [];
    };
    debug.setDebugLevel = (v) => {
      level = v;
    };
    debug.warn = (msg) => debug(msg, debug.WARN);
    debug.info = (msg) => debug(msg, debug.INFO);
    debug.debug = (msg) => debug(msg, debug.DEBUG);
    debug.debugMessages = () => messages;
    module.exports = debug;
  }
});

// node_modules/ansi-regex/index.js
var require_ansi_regex = __commonJS({
  "node_modules/ansi-regex/index.js"(exports, module) {
    "use strict";
    module.exports = ({ onlyFirst = false } = {}) => {
      const pattern = [
        "[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)",
        "(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-ntqry=><~]))"
      ].join("|");
      return new RegExp(pattern, onlyFirst ? void 0 : "g");
    };
  }
});

// node_modules/strip-ansi/index.js
var require_strip_ansi = __commonJS({
  "node_modules/strip-ansi/index.js"(exports, module) {
    "use strict";
    var ansiRegex = require_ansi_regex();
    module.exports = (string) => typeof string === "string" ? string.replace(ansiRegex(), "") : string;
  }
});

// node_modules/is-fullwidth-code-point/index.js
var require_is_fullwidth_code_point = __commonJS({
  "node_modules/is-fullwidth-code-point/index.js"(exports, module) {
    "use strict";
    var isFullwidthCodePoint = (codePoint) => {
      if (Number.isNaN(codePoint)) {
        return false;
      }
      if (codePoint >= 4352 && (codePoint <= 4447 || // Hangul Jamo
      codePoint === 9001 || // LEFT-POINTING ANGLE BRACKET
      codePoint === 9002 || // RIGHT-POINTING ANGLE BRACKET
      // CJK Radicals Supplement .. Enclosed CJK Letters and Months
      11904 <= codePoint && codePoint <= 12871 && codePoint !== 12351 || // Enclosed CJK Letters and Months .. CJK Unified Ideographs Extension A
      12880 <= codePoint && codePoint <= 19903 || // CJK Unified Ideographs .. Yi Radicals
      19968 <= codePoint && codePoint <= 42182 || // Hangul Jamo Extended-A
      43360 <= codePoint && codePoint <= 43388 || // Hangul Syllables
      44032 <= codePoint && codePoint <= 55203 || // CJK Compatibility Ideographs
      63744 <= codePoint && codePoint <= 64255 || // Vertical Forms
      65040 <= codePoint && codePoint <= 65049 || // CJK Compatibility Forms .. Small Form Variants
      65072 <= codePoint && codePoint <= 65131 || // Halfwidth and Fullwidth Forms
      65281 <= codePoint && codePoint <= 65376 || 65504 <= codePoint && codePoint <= 65510 || // Kana Supplement
      110592 <= codePoint && codePoint <= 110593 || // Enclosed Ideographic Supplement
      127488 <= codePoint && codePoint <= 127569 || // CJK Unified Ideographs Extension B .. Tertiary Ideographic Plane
      131072 <= codePoint && codePoint <= 262141)) {
        return true;
      }
      return false;
    };
    module.exports = isFullwidthCodePoint;
    module.exports.default = isFullwidthCodePoint;
  }
});

// node_modules/emoji-regex/index.js
var require_emoji_regex = __commonJS({
  "node_modules/emoji-regex/index.js"(exports, module) {
    "use strict";
    module.exports = function() {
      return /\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62(?:\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67|\uDB40\uDC73\uDB40\uDC63\uDB40\uDC74|\uDB40\uDC77\uDB40\uDC6C\uDB40\uDC73)\uDB40\uDC7F|\uD83D\uDC68(?:\uD83C\uDFFC\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68\uD83C\uDFFB|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFE])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFE\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFD])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFC])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83D\uDC68|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D[\uDC66\uDC67])|[\u2695\u2696\u2708]\uFE0F|\uD83D[\uDC66\uDC67]|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|(?:\uD83C\uDFFB\u200D[\u2695\u2696\u2708]|\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708])\uFE0F|\uD83C\uDFFB\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C[\uDFFB-\uDFFF])|(?:\uD83E\uDDD1\uD83C\uDFFB\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFC\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)\uD83C\uDFFB|\uD83E\uDDD1(?:\uD83C\uDFFF\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1(?:\uD83C[\uDFFB-\uDFFF])|\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1)|(?:\uD83E\uDDD1\uD83C\uDFFE\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFF\u200D\uD83E\uDD1D\u200D(?:\uD83D[\uDC68\uDC69]))(?:\uD83C[\uDFFB-\uDFFE])|(?:\uD83E\uDDD1\uD83C\uDFFC\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFD\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)(?:\uD83C[\uDFFB\uDFFC])|\uD83D\uDC69(?:\uD83C\uDFFE\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFD\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFC\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFD-\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFB\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFC-\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D(?:\uD83D[\uDC68\uDC69])|\uD83D[\uDC68\uDC69])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD]))|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|(?:\uD83E\uDDD1\uD83C\uDFFD\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFE\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)(?:\uD83C[\uDFFB-\uDFFD])|\uD83D\uDC69\u200D\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D[\uDC66\uDC67])|(?:\uD83D\uDC41\uFE0F\u200D\uD83D\uDDE8|\uD83D\uDC69(?:\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708]|\uD83C\uDFFB\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\u200D[\u2695\u2696\u2708])|(?:(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)\uFE0F|\uD83D\uDC6F|\uD83E[\uDD3C\uDDDE\uDDDF])\u200D[\u2640\u2642]|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD6-\uDDDD])(?:(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|\u200D[\u2640\u2642])|\uD83C\uDFF4\u200D\u2620)\uFE0F|\uD83D\uDC69\u200D\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08|\uD83D\uDC15\u200D\uD83E\uDDBA|\uD83D\uDC69\u200D\uD83D\uDC66|\uD83D\uDC69\u200D\uD83D\uDC67|\uD83C\uDDFD\uD83C\uDDF0|\uD83C\uDDF4\uD83C\uDDF2|\uD83C\uDDF6\uD83C\uDDE6|[#\*0-9]\uFE0F\u20E3|\uD83C\uDDE7(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEF\uDDF1-\uDDF4\uDDF6-\uDDF9\uDDFB\uDDFC\uDDFE\uDDFF])|\uD83C\uDDF9(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDED\uDDEF-\uDDF4\uDDF7\uDDF9\uDDFB\uDDFC\uDDFF])|\uD83C\uDDEA(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDED\uDDF7-\uDDFA])|\uD83E\uDDD1(?:\uD83C[\uDFFB-\uDFFF])|\uD83C\uDDF7(?:\uD83C[\uDDEA\uDDF4\uDDF8\uDDFA\uDDFC])|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])|\uD83C\uDDF2(?:\uD83C[\uDDE6\uDDE8-\uDDED\uDDF0-\uDDFF])|\uD83C\uDDE6(?:\uD83C[\uDDE8-\uDDEC\uDDEE\uDDF1\uDDF2\uDDF4\uDDF6-\uDDFA\uDDFC\uDDFD\uDDFF])|\uD83C\uDDF0(?:\uD83C[\uDDEA\uDDEC-\uDDEE\uDDF2\uDDF3\uDDF5\uDDF7\uDDFC\uDDFE\uDDFF])|\uD83C\uDDED(?:\uD83C[\uDDF0\uDDF2\uDDF3\uDDF7\uDDF9\uDDFA])|\uD83C\uDDE9(?:\uD83C[\uDDEA\uDDEC\uDDEF\uDDF0\uDDF2\uDDF4\uDDFF])|\uD83C\uDDFE(?:\uD83C[\uDDEA\uDDF9])|\uD83C\uDDEC(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEE\uDDF1-\uDDF3\uDDF5-\uDDFA\uDDFC\uDDFE])|\uD83C\uDDF8(?:\uD83C[\uDDE6-\uDDEA\uDDEC-\uDDF4\uDDF7-\uDDF9\uDDFB\uDDFD-\uDDFF])|\uD83C\uDDEB(?:\uD83C[\uDDEE-\uDDF0\uDDF2\uDDF4\uDDF7])|\uD83C\uDDF5(?:\uD83C[\uDDE6\uDDEA-\uDDED\uDDF0-\uDDF3\uDDF7-\uDDF9\uDDFC\uDDFE])|\uD83C\uDDFB(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDEE\uDDF3\uDDFA])|\uD83C\uDDF3(?:\uD83C[\uDDE6\uDDE8\uDDEA-\uDDEC\uDDEE\uDDF1\uDDF4\uDDF5\uDDF7\uDDFA\uDDFF])|\uD83C\uDDE8(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDEE\uDDF0-\uDDF5\uDDF7\uDDFA-\uDDFF])|\uD83C\uDDF1(?:\uD83C[\uDDE6-\uDDE8\uDDEE\uDDF0\uDDF7-\uDDFB\uDDFE])|\uD83C\uDDFF(?:\uD83C[\uDDE6\uDDF2\uDDFC])|\uD83C\uDDFC(?:\uD83C[\uDDEB\uDDF8])|\uD83C\uDDFA(?:\uD83C[\uDDE6\uDDEC\uDDF2\uDDF3\uDDF8\uDDFE\uDDFF])|\uD83C\uDDEE(?:\uD83C[\uDDE8-\uDDEA\uDDF1-\uDDF4\uDDF6-\uDDF9])|\uD83C\uDDEF(?:\uD83C[\uDDEA\uDDF2\uDDF4\uDDF5])|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD6-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u261D\u270A-\u270D]|\uD83C[\uDF85\uDFC2\uDFC7]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC6B-\uDC6D\uDC70\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDCAA\uDD74\uDD7A\uDD90\uDD95\uDD96\uDE4C\uDE4F\uDEC0\uDECC]|\uD83E[\uDD0F\uDD18-\uDD1C\uDD1E\uDD1F\uDD30-\uDD36\uDDB5\uDDB6\uDDBB\uDDD2-\uDDD5])(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u231A\u231B\u23E9-\u23EC\u23F0\u23F3\u25FD\u25FE\u2614\u2615\u2648-\u2653\u267F\u2693\u26A1\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u2705\u270A\u270B\u2728\u274C\u274E\u2753-\u2755\u2757\u2795-\u2797\u27B0\u27BF\u2B1B\u2B1C\u2B50\u2B55]|\uD83C[\uDC04\uDCCF\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF93\uDFA0-\uDFCA\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF4\uDFF8-\uDFFF]|\uD83D[\uDC00-\uDC3E\uDC40\uDC42-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDD7A\uDD95\uDD96\uDDA4\uDDFB-\uDE4F\uDE80-\uDEC5\uDECC\uDED0-\uDED2\uDED5\uDEEB\uDEEC\uDEF4-\uDEFA\uDFE0-\uDFEB]|\uD83E[\uDD0D-\uDD3A\uDD3C-\uDD45\uDD47-\uDD71\uDD73-\uDD76\uDD7A-\uDDA2\uDDA5-\uDDAA\uDDAE-\uDDCA\uDDCD-\uDDFF\uDE70-\uDE73\uDE78-\uDE7A\uDE80-\uDE82\uDE90-\uDE95])|(?:[#\*0-9\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u261D\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u265F\u2660\u2663\u2665\u2666\u2668\u267B\u267E\u267F\u2692-\u2697\u2699\u269B\u269C\u26A0\u26A1\u26AA\u26AB\u26B0\u26B1\u26BD\u26BE\u26C4\u26C5\u26C8\u26CE\u26CF\u26D1\u26D3\u26D4\u26E9\u26EA\u26F0-\u26F5\u26F7-\u26FA\u26FD\u2702\u2705\u2708-\u270D\u270F\u2712\u2714\u2716\u271D\u2721\u2728\u2733\u2734\u2744\u2747\u274C\u274E\u2753-\u2755\u2757\u2763\u2764\u2795-\u2797\u27A1\u27B0\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE02\uDE1A\uDE2F\uDE32-\uDE3A\uDE50\uDE51\uDF00-\uDF21\uDF24-\uDF93\uDF96\uDF97\uDF99-\uDF9B\uDF9E-\uDFF0\uDFF3-\uDFF5\uDFF7-\uDFFF]|\uD83D[\uDC00-\uDCFD\uDCFF-\uDD3D\uDD49-\uDD4E\uDD50-\uDD67\uDD6F\uDD70\uDD73-\uDD7A\uDD87\uDD8A-\uDD8D\uDD90\uDD95\uDD96\uDDA4\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA-\uDE4F\uDE80-\uDEC5\uDECB-\uDED2\uDED5\uDEE0-\uDEE5\uDEE9\uDEEB\uDEEC\uDEF0\uDEF3-\uDEFA\uDFE0-\uDFEB]|\uD83E[\uDD0D-\uDD3A\uDD3C-\uDD45\uDD47-\uDD71\uDD73-\uDD76\uDD7A-\uDDA2\uDDA5-\uDDAA\uDDAE-\uDDCA\uDDCD-\uDDFF\uDE70-\uDE73\uDE78-\uDE7A\uDE80-\uDE82\uDE90-\uDE95])\uFE0F|(?:[\u261D\u26F9\u270A-\u270D]|\uD83C[\uDF85\uDFC2-\uDFC4\uDFC7\uDFCA-\uDFCC]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66-\uDC78\uDC7C\uDC81-\uDC83\uDC85-\uDC87\uDC8F\uDC91\uDCAA\uDD74\uDD75\uDD7A\uDD90\uDD95\uDD96\uDE45-\uDE47\uDE4B-\uDE4F\uDEA3\uDEB4-\uDEB6\uDEC0\uDECC]|\uD83E[\uDD0F\uDD18-\uDD1F\uDD26\uDD30-\uDD39\uDD3C-\uDD3E\uDDB5\uDDB6\uDDB8\uDDB9\uDDBB\uDDCD-\uDDCF\uDDD1-\uDDDD])/g;
    };
  }
});

// node_modules/string-width/index.js
var require_string_width = __commonJS({
  "node_modules/string-width/index.js"(exports, module) {
    "use strict";
    var stripAnsi = require_strip_ansi();
    var isFullwidthCodePoint = require_is_fullwidth_code_point();
    var emojiRegex = require_emoji_regex();
    var stringWidth = (string) => {
      if (typeof string !== "string" || string.length === 0) {
        return 0;
      }
      string = stripAnsi(string);
      if (string.length === 0) {
        return 0;
      }
      string = string.replace(emojiRegex(), "  ");
      let width = 0;
      for (let i = 0; i < string.length; i++) {
        const code = string.codePointAt(i);
        if (code <= 31 || code >= 127 && code <= 159) {
          continue;
        }
        if (code >= 768 && code <= 879) {
          continue;
        }
        if (code > 65535) {
          i++;
        }
        width += isFullwidthCodePoint(code) ? 2 : 1;
      }
      return width;
    };
    module.exports = stringWidth;
    module.exports.default = stringWidth;
  }
});

// node_modules/cli-table3/src/utils.js
var require_utils2 = __commonJS({
  "node_modules/cli-table3/src/utils.js"(exports, module) {
    var stringWidth = require_string_width();
    function codeRegex(capture) {
      return capture ? /\u001b\[((?:\d*;){0,5}\d*)m/g : /\u001b\[(?:\d*;){0,5}\d*m/g;
    }
    function strlen(str) {
      let code = codeRegex();
      let stripped = ("" + str).replace(code, "");
      let split = stripped.split("\n");
      return split.reduce(function(memo, s) {
        return stringWidth(s) > memo ? stringWidth(s) : memo;
      }, 0);
    }
    function repeat(str, times) {
      return Array(times + 1).join(str);
    }
    function pad(str, len, pad2, dir) {
      let length = strlen(str);
      if (len + 1 >= length) {
        let padlen = len - length;
        switch (dir) {
          case "right": {
            str = repeat(pad2, padlen) + str;
            break;
          }
          case "center": {
            let right = Math.ceil(padlen / 2);
            let left = padlen - right;
            str = repeat(pad2, left) + str + repeat(pad2, right);
            break;
          }
          default: {
            str = str + repeat(pad2, padlen);
            break;
          }
        }
      }
      return str;
    }
    var codeCache = {};
    function addToCodeCache(name, on, off) {
      on = "\x1B[" + on + "m";
      off = "\x1B[" + off + "m";
      codeCache[on] = { set: name, to: true };
      codeCache[off] = { set: name, to: false };
      codeCache[name] = { on, off };
    }
    addToCodeCache("bold", 1, 22);
    addToCodeCache("italics", 3, 23);
    addToCodeCache("underline", 4, 24);
    addToCodeCache("inverse", 7, 27);
    addToCodeCache("strikethrough", 9, 29);
    function updateState(state, controlChars) {
      let controlCode = controlChars[1] ? parseInt(controlChars[1].split(";")[0]) : 0;
      if (controlCode >= 30 && controlCode <= 39 || controlCode >= 90 && controlCode <= 97) {
        state.lastForegroundAdded = controlChars[0];
        return;
      }
      if (controlCode >= 40 && controlCode <= 49 || controlCode >= 100 && controlCode <= 107) {
        state.lastBackgroundAdded = controlChars[0];
        return;
      }
      if (controlCode === 0) {
        for (let i in state) {
          if (Object.prototype.hasOwnProperty.call(state, i)) {
            delete state[i];
          }
        }
        return;
      }
      let info = codeCache[controlChars[0]];
      if (info) {
        state[info.set] = info.to;
      }
    }
    function readState(line) {
      let code = codeRegex(true);
      let controlChars = code.exec(line);
      let state = {};
      while (controlChars !== null) {
        updateState(state, controlChars);
        controlChars = code.exec(line);
      }
      return state;
    }
    function unwindState(state, ret) {
      let lastBackgroundAdded = state.lastBackgroundAdded;
      let lastForegroundAdded = state.lastForegroundAdded;
      delete state.lastBackgroundAdded;
      delete state.lastForegroundAdded;
      Object.keys(state).forEach(function(key) {
        if (state[key]) {
          ret += codeCache[key].off;
        }
      });
      if (lastBackgroundAdded && lastBackgroundAdded != "\x1B[49m") {
        ret += "\x1B[49m";
      }
      if (lastForegroundAdded && lastForegroundAdded != "\x1B[39m") {
        ret += "\x1B[39m";
      }
      return ret;
    }
    function rewindState(state, ret) {
      let lastBackgroundAdded = state.lastBackgroundAdded;
      let lastForegroundAdded = state.lastForegroundAdded;
      delete state.lastBackgroundAdded;
      delete state.lastForegroundAdded;
      Object.keys(state).forEach(function(key) {
        if (state[key]) {
          ret = codeCache[key].on + ret;
        }
      });
      if (lastBackgroundAdded && lastBackgroundAdded != "\x1B[49m") {
        ret = lastBackgroundAdded + ret;
      }
      if (lastForegroundAdded && lastForegroundAdded != "\x1B[39m") {
        ret = lastForegroundAdded + ret;
      }
      return ret;
    }
    function truncateWidth(str, desiredLength) {
      if (str.length === strlen(str)) {
        return str.substr(0, desiredLength);
      }
      while (strlen(str) > desiredLength) {
        str = str.slice(0, -1);
      }
      return str;
    }
    function truncateWidthWithAnsi(str, desiredLength) {
      let code = codeRegex(true);
      let split = str.split(codeRegex());
      let splitIndex = 0;
      let retLen = 0;
      let ret = "";
      let myArray;
      let state = {};
      while (retLen < desiredLength) {
        myArray = code.exec(str);
        let toAdd = split[splitIndex];
        splitIndex++;
        if (retLen + strlen(toAdd) > desiredLength) {
          toAdd = truncateWidth(toAdd, desiredLength - retLen);
        }
        ret += toAdd;
        retLen += strlen(toAdd);
        if (retLen < desiredLength) {
          if (!myArray) {
            break;
          }
          ret += myArray[0];
          updateState(state, myArray);
        }
      }
      return unwindState(state, ret);
    }
    function truncate(str, desiredLength, truncateChar) {
      truncateChar = truncateChar || "\u2026";
      let lengthOfStr = strlen(str);
      if (lengthOfStr <= desiredLength) {
        return str;
      }
      desiredLength -= strlen(truncateChar);
      let ret = truncateWidthWithAnsi(str, desiredLength);
      ret += truncateChar;
      const hrefTag = "\x1B]8;;\x07";
      if (str.includes(hrefTag) && !ret.includes(hrefTag)) {
        ret += hrefTag;
      }
      return ret;
    }
    function defaultOptions() {
      return {
        chars: {
          top: "\u2500",
          "top-mid": "\u252C",
          "top-left": "\u250C",
          "top-right": "\u2510",
          bottom: "\u2500",
          "bottom-mid": "\u2534",
          "bottom-left": "\u2514",
          "bottom-right": "\u2518",
          left: "\u2502",
          "left-mid": "\u251C",
          mid: "\u2500",
          "mid-mid": "\u253C",
          right: "\u2502",
          "right-mid": "\u2524",
          middle: "\u2502"
        },
        truncate: "\u2026",
        colWidths: [],
        rowHeights: [],
        colAligns: [],
        rowAligns: [],
        style: {
          "padding-left": 1,
          "padding-right": 1,
          head: ["red"],
          border: ["grey"],
          compact: false
        },
        head: []
      };
    }
    function mergeOptions(options, defaults) {
      options = options || {};
      defaults = defaults || defaultOptions();
      let ret = Object.assign({}, defaults, options);
      ret.chars = Object.assign({}, defaults.chars, options.chars);
      ret.style = Object.assign({}, defaults.style, options.style);
      return ret;
    }
    function wordWrap(maxLength, input) {
      let lines = [];
      let split = input.split(/(\s+)/g);
      let line = [];
      let lineLength = 0;
      let whitespace;
      for (let i = 0; i < split.length; i += 2) {
        let word = split[i];
        let newLength = lineLength + strlen(word);
        if (lineLength > 0 && whitespace) {
          newLength += whitespace.length;
        }
        if (newLength > maxLength) {
          if (lineLength !== 0) {
            lines.push(line.join(""));
          }
          line = [word];
          lineLength = strlen(word);
        } else {
          line.push(whitespace || "", word);
          lineLength = newLength;
        }
        whitespace = split[i + 1];
      }
      if (lineLength) {
        lines.push(line.join(""));
      }
      return lines;
    }
    function textWrap(maxLength, input) {
      let lines = [];
      let line = "";
      function pushLine(str, ws) {
        if (line.length && ws) line += ws;
        line += str;
        while (line.length > maxLength) {
          lines.push(line.slice(0, maxLength));
          line = line.slice(maxLength);
        }
      }
      let split = input.split(/(\s+)/g);
      for (let i = 0; i < split.length; i += 2) {
        pushLine(split[i], i && split[i - 1]);
      }
      if (line.length) lines.push(line);
      return lines;
    }
    function multiLineWordWrap(maxLength, input, wrapOnWordBoundary = true) {
      let output = [];
      input = input.split("\n");
      const handler = wrapOnWordBoundary ? wordWrap : textWrap;
      for (let i = 0; i < input.length; i++) {
        output.push.apply(output, handler(maxLength, input[i]));
      }
      return output;
    }
    function colorizeLines(input) {
      let state = {};
      let output = [];
      for (let i = 0; i < input.length; i++) {
        let line = rewindState(state, input[i]);
        state = readState(line);
        let temp = Object.assign({}, state);
        output.push(unwindState(temp, line));
      }
      return output;
    }
    function hyperlink(url, text) {
      const OSC = "\x1B]";
      const BEL = "\x07";
      const SEP = ";";
      return [OSC, "8", SEP, SEP, url || text, BEL, text, OSC, "8", SEP, SEP, BEL].join("");
    }
    module.exports = {
      strlen,
      repeat,
      pad,
      truncate,
      mergeOptions,
      wordWrap: multiLineWordWrap,
      colorizeLines,
      hyperlink
    };
  }
});

// node_modules/@colors/colors/lib/styles.js
var require_styles = __commonJS({
  "node_modules/@colors/colors/lib/styles.js"(exports, module) {
    var styles = {};
    module["exports"] = styles;
    var codes = {
      reset: [0, 0],
      bold: [1, 22],
      dim: [2, 22],
      italic: [3, 23],
      underline: [4, 24],
      inverse: [7, 27],
      hidden: [8, 28],
      strikethrough: [9, 29],
      black: [30, 39],
      red: [31, 39],
      green: [32, 39],
      yellow: [33, 39],
      blue: [34, 39],
      magenta: [35, 39],
      cyan: [36, 39],
      white: [37, 39],
      gray: [90, 39],
      grey: [90, 39],
      brightRed: [91, 39],
      brightGreen: [92, 39],
      brightYellow: [93, 39],
      brightBlue: [94, 39],
      brightMagenta: [95, 39],
      brightCyan: [96, 39],
      brightWhite: [97, 39],
      bgBlack: [40, 49],
      bgRed: [41, 49],
      bgGreen: [42, 49],
      bgYellow: [43, 49],
      bgBlue: [44, 49],
      bgMagenta: [45, 49],
      bgCyan: [46, 49],
      bgWhite: [47, 49],
      bgGray: [100, 49],
      bgGrey: [100, 49],
      bgBrightRed: [101, 49],
      bgBrightGreen: [102, 49],
      bgBrightYellow: [103, 49],
      bgBrightBlue: [104, 49],
      bgBrightMagenta: [105, 49],
      bgBrightCyan: [106, 49],
      bgBrightWhite: [107, 49],
      // legacy styles for colors pre v1.0.0
      blackBG: [40, 49],
      redBG: [41, 49],
      greenBG: [42, 49],
      yellowBG: [43, 49],
      blueBG: [44, 49],
      magentaBG: [45, 49],
      cyanBG: [46, 49],
      whiteBG: [47, 49]
    };
    Object.keys(codes).forEach(function(key) {
      var val = codes[key];
      var style = styles[key] = [];
      style.open = "\x1B[" + val[0] + "m";
      style.close = "\x1B[" + val[1] + "m";
    });
  }
});

// node_modules/@colors/colors/lib/system/has-flag.js
var require_has_flag2 = __commonJS({
  "node_modules/@colors/colors/lib/system/has-flag.js"(exports, module) {
    "use strict";
    module.exports = function(flag, argv) {
      argv = argv || process.argv;
      var terminatorPos = argv.indexOf("--");
      var prefix = /^-{1,2}/.test(flag) ? "" : "--";
      var pos = argv.indexOf(prefix + flag);
      return pos !== -1 && (terminatorPos === -1 ? true : pos < terminatorPos);
    };
  }
});

// node_modules/@colors/colors/lib/system/supports-colors.js
var require_supports_colors = __commonJS({
  "node_modules/@colors/colors/lib/system/supports-colors.js"(exports, module) {
    "use strict";
    var os = __require("os");
    var hasFlag = require_has_flag2();
    var env = process.env;
    var forceColor = void 0;
    if (hasFlag("no-color") || hasFlag("no-colors") || hasFlag("color=false")) {
      forceColor = false;
    } else if (hasFlag("color") || hasFlag("colors") || hasFlag("color=true") || hasFlag("color=always")) {
      forceColor = true;
    }
    if ("FORCE_COLOR" in env) {
      forceColor = env.FORCE_COLOR.length === 0 || parseInt(env.FORCE_COLOR, 10) !== 0;
    }
    function translateLevel(level) {
      if (level === 0) {
        return false;
      }
      return {
        level,
        hasBasic: true,
        has256: level >= 2,
        has16m: level >= 3
      };
    }
    function supportsColor(stream) {
      if (forceColor === false) {
        return 0;
      }
      if (hasFlag("color=16m") || hasFlag("color=full") || hasFlag("color=truecolor")) {
        return 3;
      }
      if (hasFlag("color=256")) {
        return 2;
      }
      if (stream && !stream.isTTY && forceColor !== true) {
        return 0;
      }
      var min = forceColor ? 1 : 0;
      if (process.platform === "win32") {
        var osRelease = os.release().split(".");
        if (Number(process.versions.node.split(".")[0]) >= 8 && Number(osRelease[0]) >= 10 && Number(osRelease[2]) >= 10586) {
          return Number(osRelease[2]) >= 14931 ? 3 : 2;
        }
        return 1;
      }
      if ("CI" in env) {
        if (["TRAVIS", "CIRCLECI", "APPVEYOR", "GITLAB_CI"].some(function(sign) {
          return sign in env;
        }) || env.CI_NAME === "codeship") {
          return 1;
        }
        return min;
      }
      if ("TEAMCITY_VERSION" in env) {
        return /^(9\.(0*[1-9]\d*)\.|\d{2,}\.)/.test(env.TEAMCITY_VERSION) ? 1 : 0;
      }
      if ("TERM_PROGRAM" in env) {
        var version2 = parseInt((env.TERM_PROGRAM_VERSION || "").split(".")[0], 10);
        switch (env.TERM_PROGRAM) {
          case "iTerm.app":
            return version2 >= 3 ? 3 : 2;
          case "Hyper":
            return 3;
          case "Apple_Terminal":
            return 2;
        }
      }
      if (/-256(color)?$/i.test(env.TERM)) {
        return 2;
      }
      if (/^screen|^xterm|^vt100|^rxvt|color|ansi|cygwin|linux/i.test(env.TERM)) {
        return 1;
      }
      if ("COLORTERM" in env) {
        return 1;
      }
      if (env.TERM === "dumb") {
        return min;
      }
      return min;
    }
    function getSupportLevel(stream) {
      var level = supportsColor(stream);
      return translateLevel(level);
    }
    module.exports = {
      supportsColor: getSupportLevel,
      stdout: getSupportLevel(process.stdout),
      stderr: getSupportLevel(process.stderr)
    };
  }
});

// node_modules/@colors/colors/lib/custom/trap.js
var require_trap = __commonJS({
  "node_modules/@colors/colors/lib/custom/trap.js"(exports, module) {
    module["exports"] = function runTheTrap(text, options) {
      var result = "";
      text = text || "Run the trap, drop the bass";
      text = text.split("");
      var trap = {
        a: ["@", "\u0104", "\u023A", "\u0245", "\u0394", "\u039B", "\u0414"],
        b: ["\xDF", "\u0181", "\u0243", "\u026E", "\u03B2", "\u0E3F"],
        c: ["\xA9", "\u023B", "\u03FE"],
        d: ["\xD0", "\u018A", "\u0500", "\u0501", "\u0502", "\u0503"],
        e: [
          "\xCB",
          "\u0115",
          "\u018E",
          "\u0258",
          "\u03A3",
          "\u03BE",
          "\u04BC",
          "\u0A6C"
        ],
        f: ["\u04FA"],
        g: ["\u0262"],
        h: ["\u0126", "\u0195", "\u04A2", "\u04BA", "\u04C7", "\u050A"],
        i: ["\u0F0F"],
        j: ["\u0134"],
        k: ["\u0138", "\u04A0", "\u04C3", "\u051E"],
        l: ["\u0139"],
        m: ["\u028D", "\u04CD", "\u04CE", "\u0520", "\u0521", "\u0D69"],
        n: ["\xD1", "\u014B", "\u019D", "\u0376", "\u03A0", "\u048A"],
        o: [
          "\xD8",
          "\xF5",
          "\xF8",
          "\u01FE",
          "\u0298",
          "\u047A",
          "\u05DD",
          "\u06DD",
          "\u0E4F"
        ],
        p: ["\u01F7", "\u048E"],
        q: ["\u09CD"],
        r: ["\xAE", "\u01A6", "\u0210", "\u024C", "\u0280", "\u042F"],
        s: ["\xA7", "\u03DE", "\u03DF", "\u03E8"],
        t: ["\u0141", "\u0166", "\u0373"],
        u: ["\u01B1", "\u054D"],
        v: ["\u05D8"],
        w: ["\u0428", "\u0460", "\u047C", "\u0D70"],
        x: ["\u04B2", "\u04FE", "\u04FC", "\u04FD"],
        y: ["\xA5", "\u04B0", "\u04CB"],
        z: ["\u01B5", "\u0240"]
      };
      text.forEach(function(c) {
        c = c.toLowerCase();
        var chars = trap[c] || [" "];
        var rand = Math.floor(Math.random() * chars.length);
        if (typeof trap[c] !== "undefined") {
          result += trap[c][rand];
        } else {
          result += c;
        }
      });
      return result;
    };
  }
});

// node_modules/@colors/colors/lib/custom/zalgo.js
var require_zalgo = __commonJS({
  "node_modules/@colors/colors/lib/custom/zalgo.js"(exports, module) {
    module["exports"] = function zalgo(text, options) {
      text = text || "   he is here   ";
      var soul = {
        "up": [
          "\u030D",
          "\u030E",
          "\u0304",
          "\u0305",
          "\u033F",
          "\u0311",
          "\u0306",
          "\u0310",
          "\u0352",
          "\u0357",
          "\u0351",
          "\u0307",
          "\u0308",
          "\u030A",
          "\u0342",
          "\u0313",
          "\u0308",
          "\u034A",
          "\u034B",
          "\u034C",
          "\u0303",
          "\u0302",
          "\u030C",
          "\u0350",
          "\u0300",
          "\u0301",
          "\u030B",
          "\u030F",
          "\u0312",
          "\u0313",
          "\u0314",
          "\u033D",
          "\u0309",
          "\u0363",
          "\u0364",
          "\u0365",
          "\u0366",
          "\u0367",
          "\u0368",
          "\u0369",
          "\u036A",
          "\u036B",
          "\u036C",
          "\u036D",
          "\u036E",
          "\u036F",
          "\u033E",
          "\u035B",
          "\u0346",
          "\u031A"
        ],
        "down": [
          "\u0316",
          "\u0317",
          "\u0318",
          "\u0319",
          "\u031C",
          "\u031D",
          "\u031E",
          "\u031F",
          "\u0320",
          "\u0324",
          "\u0325",
          "\u0326",
          "\u0329",
          "\u032A",
          "\u032B",
          "\u032C",
          "\u032D",
          "\u032E",
          "\u032F",
          "\u0330",
          "\u0331",
          "\u0332",
          "\u0333",
          "\u0339",
          "\u033A",
          "\u033B",
          "\u033C",
          "\u0345",
          "\u0347",
          "\u0348",
          "\u0349",
          "\u034D",
          "\u034E",
          "\u0353",
          "\u0354",
          "\u0355",
          "\u0356",
          "\u0359",
          "\u035A",
          "\u0323"
        ],
        "mid": [
          "\u0315",
          "\u031B",
          "\u0300",
          "\u0301",
          "\u0358",
          "\u0321",
          "\u0322",
          "\u0327",
          "\u0328",
          "\u0334",
          "\u0335",
          "\u0336",
          "\u035C",
          "\u035D",
          "\u035E",
          "\u035F",
          "\u0360",
          "\u0362",
          "\u0338",
          "\u0337",
          "\u0361",
          " \u0489"
        ]
      };
      var all = [].concat(soul.up, soul.down, soul.mid);
      function randomNumber(range) {
        var r = Math.floor(Math.random() * range);
        return r;
      }
      function isChar(character) {
        var bool = false;
        all.filter(function(i) {
          bool = i === character;
        });
        return bool;
      }
      function heComes(text2, options2) {
        var result = "";
        var counts;
        var l;
        options2 = options2 || {};
        options2["up"] = typeof options2["up"] !== "undefined" ? options2["up"] : true;
        options2["mid"] = typeof options2["mid"] !== "undefined" ? options2["mid"] : true;
        options2["down"] = typeof options2["down"] !== "undefined" ? options2["down"] : true;
        options2["size"] = typeof options2["size"] !== "undefined" ? options2["size"] : "maxi";
        text2 = text2.split("");
        for (l in text2) {
          if (isChar(l)) {
            continue;
          }
          result = result + text2[l];
          counts = { "up": 0, "down": 0, "mid": 0 };
          switch (options2.size) {
            case "mini":
              counts.up = randomNumber(8);
              counts.mid = randomNumber(2);
              counts.down = randomNumber(8);
              break;
            case "maxi":
              counts.up = randomNumber(16) + 3;
              counts.mid = randomNumber(4) + 1;
              counts.down = randomNumber(64) + 3;
              break;
            default:
              counts.up = randomNumber(8) + 1;
              counts.mid = randomNumber(6) / 2;
              counts.down = randomNumber(8) + 1;
              break;
          }
          var arr = ["up", "mid", "down"];
          for (var d in arr) {
            var index = arr[d];
            for (var i = 0; i <= counts[index]; i++) {
              if (options2[index]) {
                result = result + soul[index][randomNumber(soul[index].length)];
              }
            }
          }
        }
        return result;
      }
      return heComes(text, options);
    };
  }
});

// node_modules/@colors/colors/lib/maps/america.js
var require_america = __commonJS({
  "node_modules/@colors/colors/lib/maps/america.js"(exports, module) {
    module["exports"] = function(colors) {
      return function(letter, i, exploded) {
        if (letter === " ") return letter;
        switch (i % 3) {
          case 0:
            return colors.red(letter);
          case 1:
            return colors.white(letter);
          case 2:
            return colors.blue(letter);
        }
      };
    };
  }
});

// node_modules/@colors/colors/lib/maps/zebra.js
var require_zebra = __commonJS({
  "node_modules/@colors/colors/lib/maps/zebra.js"(exports, module) {
    module["exports"] = function(colors) {
      return function(letter, i, exploded) {
        return i % 2 === 0 ? letter : colors.inverse(letter);
      };
    };
  }
});

// node_modules/@colors/colors/lib/maps/rainbow.js
var require_rainbow = __commonJS({
  "node_modules/@colors/colors/lib/maps/rainbow.js"(exports, module) {
    module["exports"] = function(colors) {
      var rainbowColors = ["red", "yellow", "green", "blue", "magenta"];
      return function(letter, i, exploded) {
        if (letter === " ") {
          return letter;
        } else {
          return colors[rainbowColors[i++ % rainbowColors.length]](letter);
        }
      };
    };
  }
});

// node_modules/@colors/colors/lib/maps/random.js
var require_random = __commonJS({
  "node_modules/@colors/colors/lib/maps/random.js"(exports, module) {
    module["exports"] = function(colors) {
      var available = [
        "underline",
        "inverse",
        "grey",
        "yellow",
        "red",
        "green",
        "blue",
        "white",
        "cyan",
        "magenta",
        "brightYellow",
        "brightRed",
        "brightGreen",
        "brightBlue",
        "brightWhite",
        "brightCyan",
        "brightMagenta"
      ];
      return function(letter, i, exploded) {
        return letter === " " ? letter : colors[available[Math.round(Math.random() * (available.length - 2))]](letter);
      };
    };
  }
});

// node_modules/@colors/colors/lib/colors.js
var require_colors = __commonJS({
  "node_modules/@colors/colors/lib/colors.js"(exports, module) {
    var colors = {};
    module["exports"] = colors;
    colors.themes = {};
    var util = __require("util");
    var ansiStyles = colors.styles = require_styles();
    var defineProps = Object.defineProperties;
    var newLineRegex = new RegExp(/[\r\n]+/g);
    colors.supportsColor = require_supports_colors().supportsColor;
    if (typeof colors.enabled === "undefined") {
      colors.enabled = colors.supportsColor() !== false;
    }
    colors.enable = function() {
      colors.enabled = true;
    };
    colors.disable = function() {
      colors.enabled = false;
    };
    colors.stripColors = colors.strip = function(str) {
      return ("" + str).replace(/\x1B\[\d+m/g, "");
    };
    var stylize = colors.stylize = function stylize2(str, style) {
      if (!colors.enabled) {
        return str + "";
      }
      var styleMap = ansiStyles[style];
      if (!styleMap && style in colors) {
        return colors[style](str);
      }
      return styleMap.open + str + styleMap.close;
    };
    var matchOperatorsRe = /[|\\{}()[\]^$+*?.]/g;
    var escapeStringRegexp = function(str) {
      if (typeof str !== "string") {
        throw new TypeError("Expected a string");
      }
      return str.replace(matchOperatorsRe, "\\$&");
    };
    function build(_styles) {
      var builder = function builder2() {
        return applyStyle.apply(builder2, arguments);
      };
      builder._styles = _styles;
      builder.__proto__ = proto;
      return builder;
    }
    var styles = (function() {
      var ret = {};
      ansiStyles.grey = ansiStyles.gray;
      Object.keys(ansiStyles).forEach(function(key) {
        ansiStyles[key].closeRe = new RegExp(escapeStringRegexp(ansiStyles[key].close), "g");
        ret[key] = {
          get: function() {
            return build(this._styles.concat(key));
          }
        };
      });
      return ret;
    })();
    var proto = defineProps(function colors2() {
    }, styles);
    function applyStyle() {
      var args = Array.prototype.slice.call(arguments);
      var str = args.map(function(arg) {
        if (arg != null && arg.constructor === String) {
          return arg;
        } else {
          return util.inspect(arg);
        }
      }).join(" ");
      if (!colors.enabled || !str) {
        return str;
      }
      var newLinesPresent = str.indexOf("\n") != -1;
      var nestedStyles = this._styles;
      var i = nestedStyles.length;
      while (i--) {
        var code = ansiStyles[nestedStyles[i]];
        str = code.open + str.replace(code.closeRe, code.open) + code.close;
        if (newLinesPresent) {
          str = str.replace(newLineRegex, function(match) {
            return code.close + match + code.open;
          });
        }
      }
      return str;
    }
    colors.setTheme = function(theme) {
      if (typeof theme === "string") {
        console.log("colors.setTheme now only accepts an object, not a string.  If you are trying to set a theme from a file, it is now your (the caller's) responsibility to require the file.  The old syntax looked like colors.setTheme(__dirname + '/../themes/generic-logging.js'); The new syntax looks like colors.setTheme(require(__dirname + '/../themes/generic-logging.js'));");
        return;
      }
      for (var style in theme) {
        (function(style2) {
          colors[style2] = function(str) {
            if (typeof theme[style2] === "object") {
              var out = str;
              for (var i in theme[style2]) {
                out = colors[theme[style2][i]](out);
              }
              return out;
            }
            return colors[theme[style2]](str);
          };
        })(style);
      }
    };
    function init() {
      var ret = {};
      Object.keys(styles).forEach(function(name) {
        ret[name] = {
          get: function() {
            return build([name]);
          }
        };
      });
      return ret;
    }
    var sequencer = function sequencer2(map2, str) {
      var exploded = str.split("");
      exploded = exploded.map(map2);
      return exploded.join("");
    };
    colors.trap = require_trap();
    colors.zalgo = require_zalgo();
    colors.maps = {};
    colors.maps.america = require_america()(colors);
    colors.maps.zebra = require_zebra()(colors);
    colors.maps.rainbow = require_rainbow()(colors);
    colors.maps.random = require_random()(colors);
    for (map in colors.maps) {
      (function(map2) {
        colors[map2] = function(str) {
          return sequencer(colors.maps[map2], str);
        };
      })(map);
    }
    var map;
    defineProps(colors, init());
  }
});

// node_modules/@colors/colors/safe.js
var require_safe = __commonJS({
  "node_modules/@colors/colors/safe.js"(exports, module) {
    var colors = require_colors();
    module["exports"] = colors;
  }
});

// node_modules/cli-table3/src/cell.js
var require_cell = __commonJS({
  "node_modules/cli-table3/src/cell.js"(exports, module) {
    var { info, debug } = require_debug2();
    var utils = require_utils2();
    var Cell = class _Cell {
      /**
       * A representation of a cell within the table.
       * Implementations must have `init` and `draw` methods,
       * as well as `colSpan`, `rowSpan`, `desiredHeight` and `desiredWidth` properties.
       * @param options
       * @constructor
       */
      constructor(options) {
        this.setOptions(options);
        this.x = null;
        this.y = null;
      }
      setOptions(options) {
        if (["boolean", "number", "bigint", "string"].indexOf(typeof options) !== -1) {
          options = { content: "" + options };
        }
        options = options || {};
        this.options = options;
        let content = options.content;
        if (["boolean", "number", "bigint", "string"].indexOf(typeof content) !== -1) {
          this.content = String(content);
        } else if (!content) {
          this.content = this.options.href || "";
        } else {
          throw new Error("Content needs to be a primitive, got: " + typeof content);
        }
        this.colSpan = options.colSpan || 1;
        this.rowSpan = options.rowSpan || 1;
        if (this.options.href) {
          Object.defineProperty(this, "href", {
            get() {
              return this.options.href;
            }
          });
        }
      }
      mergeTableOptions(tableOptions, cells) {
        this.cells = cells;
        let optionsChars = this.options.chars || {};
        let tableChars = tableOptions.chars;
        let chars = this.chars = {};
        CHAR_NAMES.forEach(function(name) {
          setOption(optionsChars, tableChars, name, chars);
        });
        this.truncate = this.options.truncate || tableOptions.truncate;
        let style = this.options.style = this.options.style || {};
        let tableStyle = tableOptions.style;
        setOption(style, tableStyle, "padding-left", this);
        setOption(style, tableStyle, "padding-right", this);
        this.head = style.head || tableStyle.head;
        this.border = style.border || tableStyle.border;
        this.fixedWidth = tableOptions.colWidths[this.x];
        this.lines = this.computeLines(tableOptions);
        this.desiredWidth = utils.strlen(this.content) + this.paddingLeft + this.paddingRight;
        this.desiredHeight = this.lines.length;
      }
      computeLines(tableOptions) {
        const tableWordWrap = tableOptions.wordWrap || tableOptions.textWrap;
        const { wordWrap = tableWordWrap } = this.options;
        if (this.fixedWidth && wordWrap) {
          this.fixedWidth -= this.paddingLeft + this.paddingRight;
          if (this.colSpan) {
            let i = 1;
            while (i < this.colSpan) {
              this.fixedWidth += tableOptions.colWidths[this.x + i];
              i++;
            }
          }
          const { wrapOnWordBoundary: tableWrapOnWordBoundary = true } = tableOptions;
          const { wrapOnWordBoundary = tableWrapOnWordBoundary } = this.options;
          return this.wrapLines(utils.wordWrap(this.fixedWidth, this.content, wrapOnWordBoundary));
        }
        return this.wrapLines(this.content.split("\n"));
      }
      wrapLines(computedLines) {
        const lines = utils.colorizeLines(computedLines);
        if (this.href) {
          return lines.map((line) => utils.hyperlink(this.href, line));
        }
        return lines;
      }
      /**
       * Initializes the Cells data structure.
       *
       * @param tableOptions - A fully populated set of tableOptions.
       * In addition to the standard default values, tableOptions must have fully populated the
       * `colWidths` and `rowWidths` arrays. Those arrays must have lengths equal to the number
       * of columns or rows (respectively) in this table, and each array item must be a Number.
       *
       */
      init(tableOptions) {
        let x = this.x;
        let y = this.y;
        this.widths = tableOptions.colWidths.slice(x, x + this.colSpan);
        this.heights = tableOptions.rowHeights.slice(y, y + this.rowSpan);
        this.width = this.widths.reduce(sumPlusOne, -1);
        this.height = this.heights.reduce(sumPlusOne, -1);
        this.hAlign = this.options.hAlign || tableOptions.colAligns[x];
        this.vAlign = this.options.vAlign || tableOptions.rowAligns[y];
        this.drawRight = x + this.colSpan == tableOptions.colWidths.length;
      }
      /**
       * Draws the given line of the cell.
       * This default implementation defers to methods `drawTop`, `drawBottom`, `drawLine` and `drawEmpty`.
       * @param lineNum - can be `top`, `bottom` or a numerical line number.
       * @param spanningCell - will be a number if being called from a RowSpanCell, and will represent how
       * many rows below it's being called from. Otherwise it's undefined.
       * @returns {String} The representation of this line.
       */
      draw(lineNum, spanningCell) {
        if (lineNum == "top") return this.drawTop(this.drawRight);
        if (lineNum == "bottom") return this.drawBottom(this.drawRight);
        let content = utils.truncate(this.content, 10, this.truncate);
        if (!lineNum) {
          info(`${this.y}-${this.x}: ${this.rowSpan - lineNum}x${this.colSpan} Cell ${content}`);
        } else {
        }
        let padLen = Math.max(this.height - this.lines.length, 0);
        let padTop;
        switch (this.vAlign) {
          case "center":
            padTop = Math.ceil(padLen / 2);
            break;
          case "bottom":
            padTop = padLen;
            break;
          default:
            padTop = 0;
        }
        if (lineNum < padTop || lineNum >= padTop + this.lines.length) {
          return this.drawEmpty(this.drawRight, spanningCell);
        }
        let forceTruncation = this.lines.length > this.height && lineNum + 1 >= this.height;
        return this.drawLine(lineNum - padTop, this.drawRight, forceTruncation, spanningCell);
      }
      /**
       * Renders the top line of the cell.
       * @param drawRight - true if this method should render the right edge of the cell.
       * @returns {String}
       */
      drawTop(drawRight) {
        let content = [];
        if (this.cells) {
          this.widths.forEach(function(width, index) {
            content.push(this._topLeftChar(index));
            content.push(utils.repeat(this.chars[this.y == 0 ? "top" : "mid"], width));
          }, this);
        } else {
          content.push(this._topLeftChar(0));
          content.push(utils.repeat(this.chars[this.y == 0 ? "top" : "mid"], this.width));
        }
        if (drawRight) {
          content.push(this.chars[this.y == 0 ? "topRight" : "rightMid"]);
        }
        return this.wrapWithStyleColors("border", content.join(""));
      }
      _topLeftChar(offset) {
        let x = this.x + offset;
        let leftChar;
        if (this.y == 0) {
          leftChar = x == 0 ? "topLeft" : offset == 0 ? "topMid" : "top";
        } else {
          if (x == 0) {
            leftChar = "leftMid";
          } else {
            leftChar = offset == 0 ? "midMid" : "bottomMid";
            if (this.cells) {
              let spanAbove = this.cells[this.y - 1][x] instanceof _Cell.ColSpanCell;
              if (spanAbove) {
                leftChar = offset == 0 ? "topMid" : "mid";
              }
              if (offset == 0) {
                let i = 1;
                while (this.cells[this.y][x - i] instanceof _Cell.ColSpanCell) {
                  i++;
                }
                if (this.cells[this.y][x - i] instanceof _Cell.RowSpanCell) {
                  leftChar = "leftMid";
                }
              }
            }
          }
        }
        return this.chars[leftChar];
      }
      wrapWithStyleColors(styleProperty, content) {
        if (this[styleProperty] && this[styleProperty].length) {
          try {
            let colors = require_safe();
            for (let i = this[styleProperty].length - 1; i >= 0; i--) {
              colors = colors[this[styleProperty][i]];
            }
            return colors(content);
          } catch (e) {
            return content;
          }
        } else {
          return content;
        }
      }
      /**
       * Renders a line of text.
       * @param lineNum - Which line of text to render. This is not necessarily the line within the cell.
       * There may be top-padding above the first line of text.
       * @param drawRight - true if this method should render the right edge of the cell.
       * @param forceTruncationSymbol - `true` if the rendered text should end with the truncation symbol even
       * if the text fits. This is used when the cell is vertically truncated. If `false` the text should
       * only include the truncation symbol if the text will not fit horizontally within the cell width.
       * @param spanningCell - a number of if being called from a RowSpanCell. (how many rows below). otherwise undefined.
       * @returns {String}
       */
      drawLine(lineNum, drawRight, forceTruncationSymbol, spanningCell) {
        let left = this.chars[this.x == 0 ? "left" : "middle"];
        if (this.x && spanningCell && this.cells) {
          let cellLeft = this.cells[this.y + spanningCell][this.x - 1];
          while (cellLeft instanceof ColSpanCell) {
            cellLeft = this.cells[cellLeft.y][cellLeft.x - 1];
          }
          if (!(cellLeft instanceof RowSpanCell)) {
            left = this.chars["rightMid"];
          }
        }
        let leftPadding = utils.repeat(" ", this.paddingLeft);
        let right = drawRight ? this.chars["right"] : "";
        let rightPadding = utils.repeat(" ", this.paddingRight);
        let line = this.lines[lineNum];
        let len = this.width - (this.paddingLeft + this.paddingRight);
        if (forceTruncationSymbol) line += this.truncate || "\u2026";
        let content = utils.truncate(line, len, this.truncate);
        content = utils.pad(content, len, " ", this.hAlign);
        content = leftPadding + content + rightPadding;
        return this.stylizeLine(left, content, right);
      }
      stylizeLine(left, content, right) {
        left = this.wrapWithStyleColors("border", left);
        right = this.wrapWithStyleColors("border", right);
        if (this.y === 0) {
          content = this.wrapWithStyleColors("head", content);
        }
        return left + content + right;
      }
      /**
       * Renders the bottom line of the cell.
       * @param drawRight - true if this method should render the right edge of the cell.
       * @returns {String}
       */
      drawBottom(drawRight) {
        let left = this.chars[this.x == 0 ? "bottomLeft" : "bottomMid"];
        let content = utils.repeat(this.chars.bottom, this.width);
        let right = drawRight ? this.chars["bottomRight"] : "";
        return this.wrapWithStyleColors("border", left + content + right);
      }
      /**
       * Renders a blank line of text within the cell. Used for top and/or bottom padding.
       * @param drawRight - true if this method should render the right edge of the cell.
       * @param spanningCell - a number of if being called from a RowSpanCell. (how many rows below). otherwise undefined.
       * @returns {String}
       */
      drawEmpty(drawRight, spanningCell) {
        let left = this.chars[this.x == 0 ? "left" : "middle"];
        if (this.x && spanningCell && this.cells) {
          let cellLeft = this.cells[this.y + spanningCell][this.x - 1];
          while (cellLeft instanceof ColSpanCell) {
            cellLeft = this.cells[cellLeft.y][cellLeft.x - 1];
          }
          if (!(cellLeft instanceof RowSpanCell)) {
            left = this.chars["rightMid"];
          }
        }
        let right = drawRight ? this.chars["right"] : "";
        let content = utils.repeat(" ", this.width);
        return this.stylizeLine(left, content, right);
      }
    };
    var ColSpanCell = class {
      /**
       * A Cell that doesn't do anything. It just draws empty lines.
       * Used as a placeholder in column spanning.
       * @constructor
       */
      constructor() {
      }
      draw(lineNum) {
        if (typeof lineNum === "number") {
          debug(`${this.y}-${this.x}: 1x1 ColSpanCell`);
        }
        return "";
      }
      init() {
      }
      mergeTableOptions() {
      }
    };
    var RowSpanCell = class {
      /**
       * A placeholder Cell for a Cell that spans multiple rows.
       * It delegates rendering to the original cell, but adds the appropriate offset.
       * @param originalCell
       * @constructor
       */
      constructor(originalCell) {
        this.originalCell = originalCell;
      }
      init(tableOptions) {
        let y = this.y;
        let originalY = this.originalCell.y;
        this.cellOffset = y - originalY;
        this.offset = findDimension(tableOptions.rowHeights, originalY, this.cellOffset);
      }
      draw(lineNum) {
        if (lineNum == "top") {
          return this.originalCell.draw(this.offset, this.cellOffset);
        }
        if (lineNum == "bottom") {
          return this.originalCell.draw("bottom");
        }
        debug(`${this.y}-${this.x}: 1x${this.colSpan} RowSpanCell for ${this.originalCell.content}`);
        return this.originalCell.draw(this.offset + 1 + lineNum);
      }
      mergeTableOptions() {
      }
    };
    function firstDefined(...args) {
      return args.filter((v) => v !== void 0 && v !== null).shift();
    }
    function setOption(objA, objB, nameB, targetObj) {
      let nameA = nameB.split("-");
      if (nameA.length > 1) {
        nameA[1] = nameA[1].charAt(0).toUpperCase() + nameA[1].substr(1);
        nameA = nameA.join("");
        targetObj[nameA] = firstDefined(objA[nameA], objA[nameB], objB[nameA], objB[nameB]);
      } else {
        targetObj[nameB] = firstDefined(objA[nameB], objB[nameB]);
      }
    }
    function findDimension(dimensionTable, startingIndex, span) {
      let ret = dimensionTable[startingIndex];
      for (let i = 1; i < span; i++) {
        ret += 1 + dimensionTable[startingIndex + i];
      }
      return ret;
    }
    function sumPlusOne(a, b) {
      return a + b + 1;
    }
    var CHAR_NAMES = [
      "top",
      "top-mid",
      "top-left",
      "top-right",
      "bottom",
      "bottom-mid",
      "bottom-left",
      "bottom-right",
      "left",
      "left-mid",
      "mid",
      "mid-mid",
      "right",
      "right-mid",
      "middle"
    ];
    module.exports = Cell;
    module.exports.ColSpanCell = ColSpanCell;
    module.exports.RowSpanCell = RowSpanCell;
  }
});

// node_modules/cli-table3/src/layout-manager.js
var require_layout_manager = __commonJS({
  "node_modules/cli-table3/src/layout-manager.js"(exports, module) {
    var { warn, debug } = require_debug2();
    var Cell = require_cell();
    var { ColSpanCell, RowSpanCell } = Cell;
    (function() {
      function next(alloc, col) {
        if (alloc[col] > 0) {
          return next(alloc, col + 1);
        }
        return col;
      }
      function layoutTable(table) {
        let alloc = {};
        table.forEach(function(row, rowIndex) {
          let col = 0;
          row.forEach(function(cell) {
            cell.y = rowIndex;
            cell.x = rowIndex ? next(alloc, col) : col;
            const rowSpan = cell.rowSpan || 1;
            const colSpan = cell.colSpan || 1;
            if (rowSpan > 1) {
              for (let cs = 0; cs < colSpan; cs++) {
                alloc[cell.x + cs] = rowSpan;
              }
            }
            col = cell.x + colSpan;
          });
          Object.keys(alloc).forEach((idx) => {
            alloc[idx]--;
            if (alloc[idx] < 1) delete alloc[idx];
          });
        });
      }
      function maxWidth(table) {
        let mw = 0;
        table.forEach(function(row) {
          row.forEach(function(cell) {
            mw = Math.max(mw, cell.x + (cell.colSpan || 1));
          });
        });
        return mw;
      }
      function maxHeight(table) {
        return table.length;
      }
      function cellsConflict(cell1, cell2) {
        let yMin1 = cell1.y;
        let yMax1 = cell1.y - 1 + (cell1.rowSpan || 1);
        let yMin2 = cell2.y;
        let yMax2 = cell2.y - 1 + (cell2.rowSpan || 1);
        let yConflict = !(yMin1 > yMax2 || yMin2 > yMax1);
        let xMin1 = cell1.x;
        let xMax1 = cell1.x - 1 + (cell1.colSpan || 1);
        let xMin2 = cell2.x;
        let xMax2 = cell2.x - 1 + (cell2.colSpan || 1);
        let xConflict = !(xMin1 > xMax2 || xMin2 > xMax1);
        return yConflict && xConflict;
      }
      function conflictExists(rows, x, y) {
        let i_max = Math.min(rows.length - 1, y);
        let cell = { x, y };
        for (let i = 0; i <= i_max; i++) {
          let row = rows[i];
          for (let j = 0; j < row.length; j++) {
            if (cellsConflict(cell, row[j])) {
              return true;
            }
          }
        }
        return false;
      }
      function allBlank(rows, y, xMin, xMax) {
        for (let x = xMin; x < xMax; x++) {
          if (conflictExists(rows, x, y)) {
            return false;
          }
        }
        return true;
      }
      function addRowSpanCells(table) {
        table.forEach(function(row, rowIndex) {
          row.forEach(function(cell) {
            for (let i = 1; i < cell.rowSpan; i++) {
              let rowSpanCell = new RowSpanCell(cell);
              rowSpanCell.x = cell.x;
              rowSpanCell.y = cell.y + i;
              rowSpanCell.colSpan = cell.colSpan;
              insertCell(rowSpanCell, table[rowIndex + i]);
            }
          });
        });
      }
      function addColSpanCells(cellRows) {
        for (let rowIndex = cellRows.length - 1; rowIndex >= 0; rowIndex--) {
          let cellColumns = cellRows[rowIndex];
          for (let columnIndex = 0; columnIndex < cellColumns.length; columnIndex++) {
            let cell = cellColumns[columnIndex];
            for (let k = 1; k < cell.colSpan; k++) {
              let colSpanCell = new ColSpanCell();
              colSpanCell.x = cell.x + k;
              colSpanCell.y = cell.y;
              cellColumns.splice(columnIndex + 1, 0, colSpanCell);
            }
          }
        }
      }
      function insertCell(cell, row) {
        let x = 0;
        while (x < row.length && row[x].x < cell.x) {
          x++;
        }
        row.splice(x, 0, cell);
      }
      function fillInTable(table) {
        let h_max = maxHeight(table);
        let w_max = maxWidth(table);
        debug(`Max rows: ${h_max}; Max cols: ${w_max}`);
        for (let y = 0; y < h_max; y++) {
          for (let x = 0; x < w_max; x++) {
            if (!conflictExists(table, x, y)) {
              let opts = { x, y, colSpan: 1, rowSpan: 1 };
              x++;
              while (x < w_max && !conflictExists(table, x, y)) {
                opts.colSpan++;
                x++;
              }
              let y2 = y + 1;
              while (y2 < h_max && allBlank(table, y2, opts.x, opts.x + opts.colSpan)) {
                opts.rowSpan++;
                y2++;
              }
              let cell = new Cell(opts);
              cell.x = opts.x;
              cell.y = opts.y;
              warn(`Missing cell at ${cell.y}-${cell.x}.`);
              insertCell(cell, table[y]);
            }
          }
        }
      }
      function generateCells(rows) {
        return rows.map(function(row) {
          if (!Array.isArray(row)) {
            let key = Object.keys(row)[0];
            row = row[key];
            if (Array.isArray(row)) {
              row = row.slice();
              row.unshift(key);
            } else {
              row = [key, row];
            }
          }
          return row.map(function(cell) {
            return new Cell(cell);
          });
        });
      }
      function makeTableLayout(rows) {
        let cellRows = generateCells(rows);
        layoutTable(cellRows);
        fillInTable(cellRows);
        addRowSpanCells(cellRows);
        addColSpanCells(cellRows);
        return cellRows;
      }
      module.exports = {
        makeTableLayout,
        layoutTable,
        addRowSpanCells,
        maxWidth,
        fillInTable,
        computeWidths: makeComputeWidths("colSpan", "desiredWidth", "x", 1),
        computeHeights: makeComputeWidths("rowSpan", "desiredHeight", "y", 1)
      };
    })();
    function makeComputeWidths(colSpan, desiredWidth, x, forcedMin) {
      return function(vals, table) {
        let result = [];
        let spanners = [];
        let auto = {};
        table.forEach(function(row) {
          row.forEach(function(cell) {
            if ((cell[colSpan] || 1) > 1) {
              spanners.push(cell);
            } else {
              result[cell[x]] = Math.max(result[cell[x]] || 0, cell[desiredWidth] || 0, forcedMin);
            }
          });
        });
        vals.forEach(function(val, index) {
          if (typeof val === "number") {
            result[index] = val;
          }
        });
        for (let k = spanners.length - 1; k >= 0; k--) {
          let cell = spanners[k];
          let span = cell[colSpan];
          let col = cell[x];
          let existingWidth = result[col];
          let editableCols = typeof vals[col] === "number" ? 0 : 1;
          if (typeof existingWidth === "number") {
            for (let i = 1; i < span; i++) {
              existingWidth += 1 + result[col + i];
              if (typeof vals[col + i] !== "number") {
                editableCols++;
              }
            }
          } else {
            existingWidth = desiredWidth === "desiredWidth" ? cell.desiredWidth - 1 : 1;
            if (!auto[col] || auto[col] < existingWidth) {
              auto[col] = existingWidth;
            }
          }
          if (cell[desiredWidth] > existingWidth) {
            let i = 0;
            while (editableCols > 0 && cell[desiredWidth] > existingWidth) {
              if (typeof vals[col + i] !== "number") {
                let dif = Math.round((cell[desiredWidth] - existingWidth) / editableCols);
                existingWidth += dif;
                result[col + i] += dif;
                editableCols--;
              }
              i++;
            }
          }
        }
        Object.assign(vals, result, auto);
        for (let j = 0; j < vals.length; j++) {
          vals[j] = Math.max(forcedMin, vals[j] || 0);
        }
      };
    }
  }
});

// node_modules/cli-table3/src/table.js
var require_table = __commonJS({
  "node_modules/cli-table3/src/table.js"(exports, module) {
    var debug = require_debug2();
    var utils = require_utils2();
    var tableLayout = require_layout_manager();
    var Table2 = class extends Array {
      constructor(opts) {
        super();
        const options = utils.mergeOptions(opts);
        Object.defineProperty(this, "options", {
          value: options,
          enumerable: options.debug
        });
        if (options.debug) {
          switch (typeof options.debug) {
            case "boolean":
              debug.setDebugLevel(debug.WARN);
              break;
            case "number":
              debug.setDebugLevel(options.debug);
              break;
            case "string":
              debug.setDebugLevel(parseInt(options.debug, 10));
              break;
            default:
              debug.setDebugLevel(debug.WARN);
              debug.warn(`Debug option is expected to be boolean, number, or string. Received a ${typeof options.debug}`);
          }
          Object.defineProperty(this, "messages", {
            get() {
              return debug.debugMessages();
            }
          });
        }
      }
      toString() {
        let array = this;
        let headersPresent = this.options.head && this.options.head.length;
        if (headersPresent) {
          array = [this.options.head];
          if (this.length) {
            array.push.apply(array, this);
          }
        } else {
          this.options.style.head = [];
        }
        let cells = tableLayout.makeTableLayout(array);
        cells.forEach(function(row) {
          row.forEach(function(cell) {
            cell.mergeTableOptions(this.options, cells);
          }, this);
        }, this);
        tableLayout.computeWidths(this.options.colWidths, cells);
        tableLayout.computeHeights(this.options.rowHeights, cells);
        cells.forEach(function(row) {
          row.forEach(function(cell) {
            cell.init(this.options);
          }, this);
        }, this);
        let result = [];
        for (let rowIndex = 0; rowIndex < cells.length; rowIndex++) {
          let row = cells[rowIndex];
          let heightOfRow = this.options.rowHeights[rowIndex];
          if (rowIndex === 0 || !this.options.style.compact || rowIndex == 1 && headersPresent) {
            doDraw(row, "top", result);
          }
          for (let lineNum = 0; lineNum < heightOfRow; lineNum++) {
            doDraw(row, lineNum, result);
          }
          if (rowIndex + 1 == cells.length) {
            doDraw(row, "bottom", result);
          }
        }
        return result.join("\n");
      }
      get width() {
        let str = this.toString().split("\n");
        return str[0].length;
      }
    };
    Table2.reset = () => debug.reset();
    function doDraw(row, lineNum, result) {
      let line = [];
      row.forEach(function(cell) {
        line.push(cell.draw(lineNum));
      });
      let str = line.join("");
      if (str.length) result.push(str);
    }
    module.exports = Table2;
  }
});

// node_modules/cli-table3/index.js
var require_cli_table3 = __commonJS({
  "node_modules/cli-table3/index.js"(exports, module) {
    module.exports = require_table();
  }
});

// index.js
var import_tp_link_tapo_connect = __toESM(require_api(), 1);
var import_local_devices = __toESM(require_src2(), 1);
var import_cli_table3 = __toESM(require_cli_table3(), 1);
import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import readline from "readline";
var { cloudLogin, loginDeviceByIp } = import_tp_link_tapo_connect.default;
var __filename = fileURLToPath(import.meta.url);
var __dirname = dirname(__filename);
function showHelp() {
  console.log(`
TapoKeeper
==========

Monitor and control TP-Link Tapo Smart Plugs with real-time power tracking.

USAGE:
  node index.js [OPTIONS]
  npm start -- [OPTIONS]

OPTIONS:
  -h, --help                Show this help message and exit

  -v, --verbose             Enable verbose debug output during network scanning

  -i, --interval <ms>       Set polling interval in milliseconds (default: 5000)
                            Overrides POLL_INTERVAL from .env file
                            Example: --interval 3000

  --dump [format]           Run in dump mode: collect data and save to file then exit.
                            Format can be 'md' (default), 'csv', 'switchon', or 'togglecheck'
                            Does not start interactive mode.
                            Examples:
                              --dump csv
                              --dump switchon (turns on OFF devices, waits 5s, dumps)
                              --dump togglecheck (turns on OFF devices, waits 5s, dumps, turns them back off)
                              --dump togglecheck csv (same as above but CSV format)

  -di, --dump-interval <ms> Set how long to wait before collecting data in dump mode
                            (default: 10000ms, ignored when using switchon or togglecheck)
                            Example: --dump --dump-interval 30000

INTERACTIVE MODE CONTROLS:
  Press 1-9                 Toggle device on/off (no Enter key needed)
  Press d                   Dump current data to markdown file (.md)
  Press c                   Dump current data to CSV file (.csv)
  Press q                   Quit the application
  Ctrl+C                    Force quit

DUMP MODE:
  Saves a report to: tapo-power-<timestamp>.md or .csv
  Report includes device table and summary statistics

  Formats:
    --dump or --dump md       Markdown format (default)
    --dump csv                CSV format
    --dump switchon           Turn on OFF devices, wait 5s, dump to markdown
    --dump switchon csv       Turn on OFF devices, wait 5s, dump to CSV
    --dump togglecheck        Turn on OFF devices, wait 5s, dump, turn them back off
    --dump togglecheck csv    Turn on OFF devices, wait 5s, dump to CSV, turn them back off

CONFIGURATION:
  Create a .env file with the following variables:
    TAPO_EMAIL=your-email@example.com
    TAPO_PASSWORD=your-password
    POLL_INTERVAL=5000
    MANUAL_IPS=MAC1=IP1,MAC2=IP2  (optional, for devices that don't auto-discover)

EXAMPLES:
  # Start with default settings
  npm start

  # Start with 2 second polling interval
  npm start -- --interval 2000

  # Run in verbose mode to debug network issues
  npm start -- --verbose

  # Dump report to markdown after waiting 15 seconds
  npm start -- --dump --dump-interval 15000

  # Dump report to CSV after waiting 15 seconds
  npm start -- --dump csv --dump-interval 15000

  # Turn on OFF devices and dump power consumption to markdown
  npm start -- --dump switchon

  # Turn on OFF devices and dump power consumption to CSV
  npm start -- --dump switchon csv

  # Check power consumption of OFF devices (turns on, dumps, turns back off)
  npm start -- --dump togglecheck

  # Check power consumption of OFF devices and save to CSV
  npm start -- --dump togglecheck csv

  # Combine options
  npm start -- --interval 1000 --verbose

REQUIREMENTS:
  - TP-Link Tapo account credentials
  - Tapo smart plugs on local network (P110, P115, etc.)
  - Node.js 16 or higher

For more information, see README.md or CLAUDE.md
`);
  process.exit(0);
}
function parseArgs() {
  if (process.argv.includes("-h") || process.argv.includes("--help")) {
    showHelp();
  }
  const args = {
    verbose: process.argv.includes("--verbose") || process.argv.includes("-v"),
    dump: process.argv.includes("--dump") || process.argv.includes("-dump"),
    dumpFormat: "md",
    // default to markdown
    dumpSwitchOn: false,
    dumpToggleCheck: false,
    pollInterval: null,
    dumpInterval: null
  };
  const dumpIndex = process.argv.findIndex((arg) => arg === "--dump" || arg === "-dump");
  if (dumpIndex !== -1 && process.argv[dumpIndex + 1]) {
    const nextArg = process.argv[dumpIndex + 1].toLowerCase();
    if (nextArg === "csv" || nextArg === "md" || nextArg === "markdown") {
      args.dumpFormat = nextArg === "csv" ? "csv" : "md";
    } else if (nextArg === "switchon") {
      args.dumpSwitchOn = true;
      if (process.argv[dumpIndex + 2]) {
        const formatArg = process.argv[dumpIndex + 2].toLowerCase();
        if (formatArg === "csv" || formatArg === "md" || formatArg === "markdown") {
          args.dumpFormat = formatArg === "csv" ? "csv" : "md";
        }
      }
    } else if (nextArg === "togglecheck") {
      args.dumpToggleCheck = true;
      if (process.argv[dumpIndex + 2]) {
        const formatArg = process.argv[dumpIndex + 2].toLowerCase();
        if (formatArg === "csv" || formatArg === "md" || formatArg === "markdown") {
          args.dumpFormat = formatArg === "csv" ? "csv" : "md";
        }
      }
    }
  }
  const intervalIndex = process.argv.findIndex((arg) => arg === "--interval" || arg === "-i");
  if (intervalIndex !== -1 && process.argv[intervalIndex + 1]) {
    args.pollInterval = parseInt(process.argv[intervalIndex + 1]);
  }
  const dumpIntervalIndex = process.argv.findIndex((arg) => arg === "--dump-interval" || arg === "-di");
  if (dumpIntervalIndex !== -1 && process.argv[dumpIntervalIndex + 1]) {
    args.dumpInterval = parseInt(process.argv[dumpIntervalIndex + 1]);
  }
  return args;
}
var cmdArgs = parseArgs();
var config = {
  email: process.env.TAPO_EMAIL,
  password: process.env.TAPO_PASSWORD,
  pollInterval: cmdArgs.pollInterval || parseInt(process.env.POLL_INTERVAL || "5000"),
  manualIps: {},
  verbose: cmdArgs.verbose,
  dump: cmdArgs.dump,
  dumpFormat: cmdArgs.dumpFormat,
  dumpSwitchOn: cmdArgs.dumpSwitchOn,
  dumpToggleCheck: cmdArgs.dumpToggleCheck,
  dumpInterval: cmdArgs.dumpInterval || 1e4
  // Default 10 seconds for dump mode
};
try {
  const envContent = readFileSync(join(__dirname, ".env"), "utf-8");
  const envVars = envContent.split("\n").reduce((acc, line) => {
    const [key, ...values] = line.split("=");
    if (key && values.length) {
      acc[key.trim()] = values.join("=").trim();
    }
    return acc;
  }, {});
  config.email = config.email || envVars.TAPO_EMAIL;
  config.password = config.password || envVars.TAPO_PASSWORD;
  if (!cmdArgs.pollInterval) {
    config.pollInterval = parseInt(envVars.POLL_INTERVAL || config.pollInterval);
  }
  if (envVars.MANUAL_IPS) {
    const pairs = envVars.MANUAL_IPS.split(",").map((p) => p.trim()).filter((p) => p);
    pairs.forEach((pair) => {
      const [mac, ip] = pair.split("=").map((s) => s.trim());
      if (mac && ip) {
        config.manualIps[mac.toUpperCase().replace(/[:-]/g, "")] = ip;
      }
    });
  }
} catch (err) {
}
if (process.env.MANUAL_IPS) {
  const pairs = process.env.MANUAL_IPS.split(",").map((p) => p.trim()).filter((p) => p);
  pairs.forEach((pair) => {
    const [mac, ip] = pair.split("=").map((s) => s.trim());
    if (mac && ip) {
      config.manualIps[mac.toUpperCase().replace(/[:-]/g, "")] = ip;
    }
  });
}
if (!config.email || !config.password) {
  console.error("Error: TAPO_EMAIL and TAPO_PASSWORD must be set");
  console.error("Either set environment variables or create a .env file (see .env.example)");
  process.exit(1);
}
var cloudApi = null;
var localDeviceCache = null;
var deviceClients = {};
var autoRefreshInterval = null;
function generateMarkdownTable(powerInfos) {
  let markdown = `# TapoKeeper Power Report

`;
  markdown += `Generated: ${(/* @__PURE__ */ new Date()).toLocaleString()}

`;
  markdown += `| # | Device Name | Model | Status | Current Power | Today | This Month | IP Address |
`;
  markdown += `|---|-------------|-------|--------|---------------|-------|------------|------------|
`;
  powerInfos.forEach((info, idx) => {
    markdown += `| ${idx + 1} | ${info.name} | ${info.model} | ${info.status} | ${info.currentPower} | ${info.todayEnergy} | ${info.monthEnergy} | ${info.ip} |
`;
  });
  const onlineDevices = powerInfos.filter((d) => d.status === "ON" || d.status === "OFF");
  const activeDevices = powerInfos.filter((d) => d.status === "ON");
  const totalPower = powerInfos.filter((d) => d.currentPower !== "N/A").reduce((sum, d) => {
    const watts = parseFloat(d.currentPower);
    return sum + (isNaN(watts) ? 0 : watts);
  }, 0);
  markdown += `
## Summary

`;
  markdown += `- **Total Devices**: ${powerInfos.length}
`;
  markdown += `- **Online**: ${onlineDevices.length}
`;
  markdown += `- **Active (ON)**: ${activeDevices.length}
`;
  markdown += `- **Total Power Consumption**: ${totalPower.toFixed(2)} W
`;
  return markdown;
}
async function savePowerData(format = "md") {
  if (!currentDevices || currentDevices.length === 0) {
    console.log("\nNo device data available to save");
    return;
  }
  const content = format === "csv" ? generateCSV(currentDevices) : generateMarkdownTable(currentDevices);
  const extension = format === "csv" ? "csv" : "md";
  const filename = `tapo-power-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.${extension}`;
  const { writeFileSync } = await import("fs");
  writeFileSync(join(__dirname, filename), content);
  console.log(`
Power data saved to ${filename}`);
  setTimeout(() => displayPowerStats(), 1e3);
}
function generateCSV(powerInfos) {
  let csv = `# TapoKeeper Power Report - Generated: ${(/* @__PURE__ */ new Date()).toLocaleString()}
`;
  csv += `#,Device Name,Model,Status,Current Power,Today,This Month,IP Address
`;
  powerInfos.forEach((info, idx) => {
    const name = info.name.includes(",") ? `"${info.name}"` : info.name;
    csv += `${idx + 1},${name},${info.model},${info.status},${info.currentPower},${info.todayEnergy},${info.monthEnergy},${info.ip}
`;
  });
  const onlineDevices = powerInfos.filter((d) => d.status === "ON" || d.status === "OFF");
  const activeDevices = powerInfos.filter((d) => d.status === "ON");
  const totalPower = powerInfos.filter((d) => d.currentPower !== "N/A").reduce((sum, d) => {
    const watts = parseFloat(d.currentPower);
    return sum + (isNaN(watts) ? 0 : watts);
  }, 0);
  csv += `
# Summary
`;
  csv += `# Total Devices: ${powerInfos.length}
`;
  csv += `# Online: ${onlineDevices.length}
`;
  csv += `# Active (ON): ${activeDevices.length}
`;
  csv += `# Total Power Consumption: ${totalPower.toFixed(2)} W
`;
  return csv;
}
async function scanForTapoDevices(targetMacs, localDevicesData) {
  if (config.verbose) console.log("Attempting direct IP scan for Tapo devices...");
  const macToIp = {};
  const subnets = /* @__PURE__ */ new Set();
  localDevicesData.forEach((device) => {
    if (device.ip) {
      const subnet = device.ip.substring(0, device.ip.lastIndexOf("."));
      subnets.add(subnet);
    }
  });
  if (subnets.size === 0) {
    const os = await import("os");
    const interfaces = os.networkInterfaces();
    const localIp = Object.values(interfaces).flat().find((iface) => iface && iface.family === "IPv4" && !iface.internal)?.address;
    if (localIp) {
      const subnet = localIp.substring(0, localIp.lastIndexOf("."));
      subnets.add(subnet);
    }
  }
  if (subnets.size === 0) {
    if (config.verbose) console.log("Could not determine subnets to scan");
    return macToIp;
  }
  const subnetsToScan = Array.from(subnets).slice(0, 5);
  if (config.verbose) console.log(`Scanning ${subnetsToScan.length} subnet(s): ${subnetsToScan.join(", ")}`);
  const batchSize = 50;
  let foundCount = 0;
  for (const subnet of subnetsToScan) {
    if (config.verbose) console.log(`Scanning ${subnet}.x...`);
    for (let batchStart = 1; batchStart <= 254; batchStart += batchSize) {
      const batchPromises = [];
      for (let i = batchStart; i < batchStart + batchSize && i <= 254; i++) {
        const ip = `${subnet}.${i}`;
        batchPromises.push(
          (async () => {
            try {
              const deviceClient = await Promise.race([
                loginDeviceByIp(config.email, config.password, ip),
                new Promise(
                  (_, reject) => setTimeout(() => reject(new Error("timeout")), 1500)
                )
              ]);
              const deviceInfo = await deviceClient.getDeviceInfo();
              const mac = deviceInfo.mac?.replace(/[:-]/g, "").toUpperCase();
              if (mac && targetMacs.includes(mac)) {
                if (config.verbose) console.log(`Found Tapo device at ${ip} with MAC ${mac}`);
                macToIp[mac] = ip;
                foundCount++;
              }
              return { ip, mac };
            } catch (err) {
              return null;
            }
          })()
        );
      }
      await Promise.all(batchPromises);
      if (foundCount >= targetMacs.length) {
        if (config.verbose) console.log(`Found all ${targetMacs.length} devices, stopping scan`);
        break;
      }
    }
    if (foundCount >= targetMacs.length) break;
  }
  if (config.verbose) console.log(`Direct scan found ${foundCount} of ${targetMacs.length} Tapo devices`);
  return macToIp;
}
async function getDevicePowerInfo(device, macToIpMap) {
  const timeoutMs = 1e4;
  try {
    const normalizedMac = device.deviceMac.replace(/[:-]/g, "").toUpperCase();
    const deviceIp = macToIpMap[normalizedMac];
    if (!deviceIp) {
      throw new Error("Device not found on local network");
    }
    const deviceClient = await Promise.race([
      loginDeviceByIp(config.email, config.password, deviceIp),
      new Promise(
        (_, reject) => setTimeout(() => reject(new Error("Connection timeout")), timeoutMs)
      )
    ]);
    deviceClients[device.alias] = deviceClient;
    const deviceInfo = await deviceClient.getDeviceInfo();
    let energyUsage = null;
    try {
      energyUsage = await deviceClient.getEnergyUsage();
    } catch (err) {
    }
    return {
      name: deviceInfo.nickname || device.alias || "Unknown",
      model: deviceInfo.model || device.deviceModel || "Unknown",
      status: deviceInfo.device_on ? "ON" : "OFF",
      currentPower: energyUsage?.current_power ? `${(energyUsage.current_power / 1e3).toFixed(2)} W` : "N/A",
      todayEnergy: energyUsage?.today_energy ? `${(energyUsage.today_energy / 1e3).toFixed(3)} kWh` : "N/A",
      monthEnergy: energyUsage?.month_energy ? `${(energyUsage.month_energy / 1e3).toFixed(3)} kWh` : "N/A",
      ip: deviceIp,
      alias: device.alias
    };
  } catch (err) {
    return {
      name: device.alias || "Unknown",
      model: device.deviceModel || "Unknown",
      status: "OFFLINE",
      currentPower: "N/A",
      todayEnergy: "N/A",
      monthEnergy: "N/A",
      ip: macToIpMap[device.deviceMac.replace(/[:-]/g, "").toUpperCase()] || "Not found",
      error: err.message,
      alias: device.alias
    };
  }
}
async function displayPowerStats() {
  try {
    if (!cloudApi) {
      cloudApi = await cloudLogin(config.email, config.password);
    }
    const devices = await cloudApi.listDevices();
    if (devices.length === 0) {
      console.clear();
      console.log("No devices found in your Tapo account.");
      return;
    }
    if (!localDeviceCache || Date.now() - localDeviceCache.timestamp > 3e5) {
      let macToIpMap = {};
      let localNetworkDevices = [];
      if (Object.keys(config.manualIps).length > 0) {
        macToIpMap = { ...config.manualIps };
      }
      try {
        localNetworkDevices = await (0, import_local_devices.default)({ skipNameResolution: true });
        localNetworkDevices.forEach((device) => {
          if (device.mac && device.mac !== "dynamic") {
            const normalizedMac = device.mac.replace(/[:-]/g, "").toUpperCase();
            if (!macToIpMap[normalizedMac]) {
              macToIpMap[normalizedMac] = device.ip;
            }
          }
        });
      } catch (err) {
        if (config.verbose) console.log(`Local device discovery failed: ${err.message}`);
      }
      const targetMacs = devices.map((d) => d.deviceMac.replace(/[:-]/g, "").toUpperCase());
      const foundMacs = Object.keys(macToIpMap);
      const missingMacs = targetMacs.filter((mac) => !foundMacs.includes(mac));
      if (missingMacs.length > 0) {
        if (config.verbose) console.log(`${missingMacs.length} device(s) not found via ARP scan, starting direct IP scan...`);
        const scanPromise = scanForTapoDevices(missingMacs, localNetworkDevices);
        const timeout = new Promise((resolve) => setTimeout(() => resolve({}), 1e4));
        const scannedDevices = await Promise.race([scanPromise, timeout]);
        Object.keys(scannedDevices).forEach((mac) => {
          if (!macToIpMap[mac]) {
            macToIpMap[mac] = scannedDevices[mac];
          }
        });
        if (Object.keys(scannedDevices).length < missingMacs.length) {
          scanPromise.then((fullResults) => {
            Object.keys(fullResults).forEach((mac) => {
              if (!localDeviceCache.map[mac]) {
                localDeviceCache.map[mac] = fullResults[mac];
              }
            });
          });
        }
      }
      localDeviceCache = { map: macToIpMap, timestamp: Date.now() };
    }
    const powerInfoPromises = devices.map((device) => getDevicePowerInfo(device, localDeviceCache.map));
    const powerInfos = await Promise.all(powerInfoPromises);
    if (config.dump && !config.dumpSwitchOn && !config.dumpToggleCheck) {
      const content = config.dumpFormat === "csv" ? generateCSV(powerInfos) : generateMarkdownTable(powerInfos);
      const extension = config.dumpFormat === "csv" ? "csv" : "md";
      const filename = `tapo-power-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.${extension}`;
      const { writeFileSync } = await import("fs");
      writeFileSync(join(__dirname, filename), content);
      console.log(`Power data saved to ${filename}`);
      process.exit(0);
    }
    console.clear();
    console.log("TapoKeeper");
    console.log(`Polling interval: ${config.pollInterval}ms
`);
    const table = new import_cli_table3.default({
      head: ["#", "Device Name", "Model", "Status", "Current Power", "Today", "This Month", "IP Address"],
      colWidths: [4, 20, 15, 10, 15, 12, 12, 18]
    });
    powerInfos.forEach((info, idx) => {
      table.push([
        idx + 1,
        info.name,
        info.model,
        info.status,
        info.currentPower,
        info.todayEnergy,
        info.monthEnergy,
        info.ip
      ]);
    });
    console.log(table.toString());
    console.log(`
Last updated: ${(/* @__PURE__ */ new Date()).toLocaleString()}`);
    console.log("\nControls: [1-" + powerInfos.length + "] toggle device | [d] dump to .md | [c] dump to .csv | [q] quit");
  } catch (err) {
    console.error("Error:", err.message);
    if (err.message.includes("Invalid credentials")) {
      console.error("\nPlease check your TAPO_EMAIL and TAPO_PASSWORD in .env file");
      process.exit(1);
    }
  }
}
async function toggleDevice(deviceAlias, turnOn) {
  const client = deviceClients[deviceAlias];
  if (!client) {
    console.log("Device not connected");
    return;
  }
  try {
    if (turnOn) {
      await client.turnOn();
    } else {
      await client.turnOff();
    }
    await displayPowerStats();
  } catch (err) {
    console.log("Error controlling device:", err.message);
  }
}
async function turnOnOffDevices(powerInfos) {
  const offDevices = powerInfos.filter((info) => info.status === "OFF");
  if (config.verbose) {
    console.log(`Checking device status...`);
    console.log(`Found ${offDevices.length} device(s) that are OFF`);
  }
  if (offDevices.length === 0) {
    if (config.verbose) console.log("All devices are already ON");
    return;
  }
  let successCount = 0;
  let failCount = 0;
  const promises = offDevices.map(async (deviceInfo) => {
    const client = deviceClients[deviceInfo.alias];
    if (client) {
      try {
        await client.turnOn();
        successCount++;
        if (config.verbose) console.log(`  \u2713 ${deviceInfo.name} turned on`);
      } catch (err) {
        failCount++;
        if (config.verbose) console.log(`  \u2717 ${deviceInfo.name} failed: ${err.message}`);
      }
    } else {
      failCount++;
      if (config.verbose) console.log(`  \u2717 ${deviceInfo.name} no client available`);
    }
  });
  await Promise.all(promises);
  if (config.verbose) console.log(`Turned on ${successCount} device(s)${failCount > 0 ? `, ${failCount} failed` : ""}`);
}
if (!config.dump && process.stdin.isTTY) {
  readline.emitKeypressEvents(process.stdin);
  process.stdin.setRawMode(true);
}
var currentDevices = [];
if (!config.dump) {
  process.stdin.on("keypress", async (str, key) => {
    if (key.ctrl && key.name === "c") {
      console.log("\nExiting...");
      process.exit(0);
    }
    if (key.name === "q") {
      console.log("\nExiting...");
      process.exit(0);
    }
    if (key.name === "d") {
      await savePowerData("md");
      return;
    }
    if (key.name === "c") {
      await savePowerData("csv");
      return;
    }
    const deviceNum = parseInt(str);
    if (!isNaN(deviceNum) && deviceNum >= 1 && deviceNum <= currentDevices.length) {
      const device = currentDevices[deviceNum - 1];
      const currentStatus = device.status === "ON";
      console.log(`
Turning ${currentStatus ? "OFF" : "ON"} ${device.name}...`);
      await toggleDevice(device.alias, !currentStatus);
    }
  });
}
var originalDisplayPowerStats = displayPowerStats;
displayPowerStats = async function() {
  await originalDisplayPowerStats();
  const devices = await cloudApi.listDevices();
  const powerInfoPromises = devices.map((device) => getDevicePowerInfo(device, localDeviceCache.map));
  const powerInfos = await Promise.all(powerInfoPromises);
  currentDevices = powerInfos.map((info, idx) => ({
    ...info,
    number: idx + 1
  }));
};
await displayPowerStats();
if (config.dump) {
  if (config.dumpToggleCheck) {
    const offDevices = currentDevices.filter((info) => info.status === "OFF");
    if (config.verbose) {
      console.log(`ToggleCheck mode: Found ${offDevices.length} device(s) that are OFF`);
    }
    if (offDevices.length > 0) {
      await turnOnOffDevices(currentDevices);
      if (config.verbose) console.log("Waiting 5 seconds for power data to stabilize...");
      await new Promise((resolve) => setTimeout(resolve, 5e3));
      if (config.verbose) console.log("Refreshing device data...");
      const devices = await cloudApi.listDevices();
      const powerInfoPromises = devices.map((device) => getDevicePowerInfo(device, localDeviceCache.map));
      const powerInfos = await Promise.all(powerInfoPromises);
      const content = config.dumpFormat === "csv" ? generateCSV(powerInfos) : generateMarkdownTable(powerInfos);
      const extension = config.dumpFormat === "csv" ? "csv" : "md";
      const filename = `tapo-power-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.${extension}`;
      const { writeFileSync } = await import("fs");
      writeFileSync(join(__dirname, filename), content);
      console.log(`Power data saved to ${filename}`);
      if (config.verbose) console.log(`Turning back off ${offDevices.length} device(s)...`);
      let successCount = 0;
      let failCount = 0;
      const promises = offDevices.map(async (deviceInfo) => {
        const client = deviceClients[deviceInfo.alias];
        if (client) {
          try {
            await client.turnOff();
            successCount++;
            if (config.verbose) console.log(`  \u2713 ${deviceInfo.name} turned back off`);
          } catch (err) {
            failCount++;
            if (config.verbose) console.log(`  \u2717 ${deviceInfo.name} failed: ${err.message}`);
          }
        } else {
          failCount++;
          if (config.verbose) console.log(`  \u2717 ${deviceInfo.name} no client available`);
        }
      });
      await Promise.all(promises);
      if (config.verbose) console.log(`Turned off ${successCount} device(s)${failCount > 0 ? `, ${failCount} failed` : ""}`);
    } else {
      if (config.verbose) console.log("All devices are already ON, dumping current state");
      const devices = await cloudApi.listDevices();
      const powerInfoPromises = devices.map((device) => getDevicePowerInfo(device, localDeviceCache.map));
      const powerInfos = await Promise.all(powerInfoPromises);
      const content = config.dumpFormat === "csv" ? generateCSV(powerInfos) : generateMarkdownTable(powerInfos);
      const extension = config.dumpFormat === "csv" ? "csv" : "md";
      const filename = `tapo-power-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.${extension}`;
      const { writeFileSync } = await import("fs");
      writeFileSync(join(__dirname, filename), content);
      console.log(`Power data saved to ${filename}`);
    }
    process.exit(0);
  } else if (config.dumpSwitchOn) {
    await turnOnOffDevices(currentDevices);
    if (config.verbose) console.log("Waiting 5 seconds for power data to stabilize...");
    await new Promise((resolve) => setTimeout(resolve, 5e3));
    if (config.verbose) console.log("Refreshing device data...");
    const devices = await cloudApi.listDevices();
    const powerInfoPromises = devices.map((device) => getDevicePowerInfo(device, localDeviceCache.map));
    const powerInfos = await Promise.all(powerInfoPromises);
    const content = config.dumpFormat === "csv" ? generateCSV(powerInfos) : generateMarkdownTable(powerInfos);
    const extension = config.dumpFormat === "csv" ? "csv" : "md";
    const filename = `tapo-power-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.${extension}`;
    const { writeFileSync } = await import("fs");
    writeFileSync(join(__dirname, filename), content);
    console.log(`Power data saved to ${filename}`);
    process.exit(0);
  } else {
    if (config.verbose) console.log(`Waiting ${config.dumpInterval}ms before collecting data...`);
    await new Promise((resolve) => setTimeout(resolve, config.dumpInterval));
    await displayPowerStats();
  }
} else {
  autoRefreshInterval = setInterval(displayPowerStats, config.pollInterval);
}
